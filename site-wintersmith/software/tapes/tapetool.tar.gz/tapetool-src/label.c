#include <stdio.h>
#include <ftt.h>
#include "convert.h"
#include "tapetool.h"
#include "util.h"


int ReadLabel(void)
{
   char data[MAX_BLOCK_SIZE];
   int res;
   int labelType;

   if (verbose)
     fprintf(stderr, "Label Parser:\n");
   
   // need to read the header block
   if ((res = ftt_read(d, data, MAX_BLOCK_SIZE)) == -1)
     {
	fprintf(stderr, "Error reading header block\n");
	return -1;
     }

   // Make sure we don't start at a data block or something
   if (res != 80)
     {
	fprintf(stderr, "Tape was not positioned at a label\n");
	return -2;
     }

   // Detect ANSI versus IBM header types (IBM is in EBCDIC)
   labelType = DetectHeaderType(data);
   if (labelType == FTT_UNKNOWN_HEADER)
     {	     
	HexDump(data, res);
	fprintf(stderr, "Unsupported/undetected header type\n");
	return -3;
     }
   
   // Read all headers from this block
   while (res == 80)
     {
	if (labelType == FTT_IBM_HEADER)
	  EBCDIC_to_ASCII(data, res);
	
	if (verbose > 1)
	  HexDump(data, res);
	
	switch (*((long *) data))
	  {
	     // For more information, see
	     // http://www.loc.gov/marc/specifications/specexchtape1.html
	     // Or search for ANSI specification HDR1 VOL1 HDR2 ... etc.
	   case 0x314c4f56:  // VOL1
	     printf("Label:  %s\n", GetString(data, 0, 4));
	     printf("Volume ID:  %s\n", GetString(data, 4, 6));
	     printf("Accessibility:  %s\n", GetString(data, 10, 1));
	     if (HasData(data, 11, 26))
	       printf("Unused1:  %s\n", GetString(data, 11, 26));
	     printf("Owner ID:  %s\n", GetString(data, 37, 14));
	     if (HasData(data, 51, 28))
	       printf("Unused2:  %s\n", GetString(data, 51, 38));
	     printf("Label Version:  %s\n", GetString(data, 79, 1));
	     printf("\n");
	     break;
	   case 0x31524448:  // HDR1
	   case 0x31564F45:  // EOV1
	   case 0x31464F45:  // EOF1
	     printf("Label:  %s\n", GetString(data, 0, 4));
	     printf("File ID:  %s\n", GetString(data, 4, 17));
	     printf("File Set ID:  %s\n", GetString(data, 21, 6));
	     printf("File Section Number:  %s\n", GetString(data, 27, 4));
	     printf("File Sequence Number:  %s\n", GetString(data, 31, 4));
	     printf("Generation Number:  %s\n", GetString(data, 35, 4));
	     printf("Generation Number Version:  %s\n", GetString(data, 35, 2));
	     printf("Creation Date:  %s\n", GetString(data, 41, 6));
	     printf("Expiration Date:  %s\n", GetString(data, 47, 6));
	     printf("Accessibility:  %s\n", GetString(data, 53, 1));
	     printf("Block Count:  %s\n", GetString(data, 54, 6));
	     printf("System Code:  %s\n", GetString(data, 60, 13));
	     if (HasData(data, 73, 7))
	       printf("Unused3:  %s\n", GetString(data, 73, 7));
	     printf("\n");
	     break;
	   case 0x32524448:  // HDR2
	   case 0x32564F45:  // EOV2
	   case 0x32464F45:  // EOF2
	     printf("Label:  %s\n", GetString(data, 0, 4));
	     printf("Record Format:  %s\n", GetString(data, 4, 1));
	     printf("Block Length:  %s\n", GetString(data, 5, 5));
	     printf("Record Length:  %s\n", GetString(data, 10, 5));
	     if (data[15] >= '0' && data[15] <= '5')
	       {
		  printf("Recording Density:  %c\n", data[15]);
		  printf("Continuation Flag:  %c\n", data[16]);
		  if (HasData(data, 17, 34))
		    printf("Unused4:  %s\n", GetString(data, 17, 34));
	       }
	     else
	       {
		  if (HasData(data, 15, 35))
		    printf("Unused5:  %s\n", GetString(data, 15, 35));
	       }
	     printf("Buffer Offset:  %s\n", GetString(data, 50, 2));
	     if (HasData(data, 52, 28))
	       printf("Unused6:  %s\n", GetString(data, 52, 28));
	     printf("\n");
	     break;
	   default:
	     printf("Unknown section:  %lx\n", *((long *) data));
	     printf("\n");
	  }
	
	if ((res = ftt_read(d, data, MAX_BLOCK_SIZE)) == -1)
	  {
	     fprintf(stderr, "Error reading header block.\n");
	     return 1;
	  }
     }
   
   return 0;
}
