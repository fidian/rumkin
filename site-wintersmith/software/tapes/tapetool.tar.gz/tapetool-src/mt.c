/* Emulation of the mt binary -- just the rewind, eject, and status functions
 * 
 * This removes dependance upon the mt package, making the tools portable
 * to windows
 */

#include <stdio.h>
#include <ftt.h>
#include "tapetool.h"

int MT_Status(void)
{
   // Return 0 if there is a tape in the drive
   int status;
   
   status = ftt_status(d, 0);
   if (verbose)
     {
	if (status & FTT_ABOT)
	  fprintf(stderr, "FTT_ABOT -- At beginning of tape\n");
	if (status & FTT_AEOT)
	  fprintf(stderr, "FTT_AEOT -- At end of tape\n");
	if (status & FTT_AEW)
	  fprintf(stderr, "FTT_AEW -- At early warning mark near EOT\n");
	if (status & FTT_PROT)
	  fprintf(stderr, "FTT_PROT -- Write protected tape\n");
        if (status & FTT_ONLINE)
	  fprintf(stderr, "FTT_ONLINE -- Tape is loaded and is online\n");
	if (status & FTT_BUSY)
	  fprintf(stderr, "FTT_BUSY -- Tape is busy and not responding\n");
     }
   if (status & FTT_ONLINE)
     return 0;
   return 1;
}


int MT_Eject(void)
{
   if (! ftt_unload(d))
     return 0;
   
   fprintf(stderr, "Error unloading tape.");
   return 1;
}


int MT_Rewind(void)
{
   if (! ftt_rewind(d))
     return 0;
   
   fprintf(stderr, "Error rewinding tape.");
   return 1;
}
