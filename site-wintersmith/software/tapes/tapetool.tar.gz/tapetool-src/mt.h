int MT_Status(void);
int MT_Eject(void);
int MT_Rewind(void);
