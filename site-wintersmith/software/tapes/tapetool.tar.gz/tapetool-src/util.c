#include <stdio.h>
#include <string.h>
#include <ftt.h>


void HexDump(char *data, int len)
{
   int i = 0, j;
   char HexCodes[] = "0123456789ABCDEF";
   char printline[80];

/*
NNNN   XX XX XX XX  XX XX XX XX  XX XX XX XX  XX XX XX XX   CCCCCCCCCCCCCCCC
*/
   
   for (i = 0; i < len; i += 16)
     {
	sprintf(printline, "%4x   ", i);
	
	for (j = 0; j < 16; j ++)
	  {
	     if (i + j < len)
	       {
		  sprintf(&printline[strlen(printline)], "%c%c ",
			  HexCodes[(data[i + j] >> 4) & 0x0F],
			  HexCodes[data[i + j] & 0x0F]);
	       }
	     else
	       {
		  strcat(printline, "   ");
	       }
	     if (j % 4 == 0)
	       strcat(printline, " ");
	  }

	strcat(printline, " ");
	
	for (j = 0; j < 16; j ++)
	  {
	     if (i + j < len)
	       {
		  if (data[i + j] >= ' ' && data[i + j] <= '~')
		    sprintf(&printline[strlen(printline)], "%c", data[i + j]);
		  else
		    strcat(printline, ".");
	       }
	  }

	printf("%s\n", printline);
     }
}


int DetectHeaderType(char *data)
{
   // Detect ANSI versus IBM header types (IBM is in EBCDIC)
   switch (*((long *) data))
     {
      case 0x314c4f56:  // VOL1
      case 0x31524448:  // HDR1
      case 0x31564F45:  // EOV1
      case 0x31464F45:  // EOF1
      case 0x32524448:  // HDR2
      case 0x32564F45:  // EOV2
      case 0x32464F45:  // EOF2
	return FTT_ANSI_HEADER;

      case 0xF1D3D6E5:  // VOL1
      case 0xF1D9C4C8:  // HDR1
      case 0xF1E5D6C5:  // EOV1
      case 0xF1C6D6C5:  // EOF1
      case 0xF2D9C4C8:  // HDR2
      case 0xF2E5D6C5:  // EOV2
      case 0xF2C6D6C5:  // EOF2
	return FTT_IBM_HEADER;

      default:
	return FTT_UNKNOWN_HEADER;
     }
}


char *GetString(char *data, int start, int len) 
{
   static char String[80];
   int i;
   
   for (i = 0; i < len; i ++)
     String[i] = data[start + i];
   
   String[i] = '\0';
   
   return String;
}


int ReadBlock(ftt_descriptor d, char *data, int BlockLength, int BlocksRead)
{
   int res;
   //fprintf(stderr, "\rReading block %ld", BlocksRead);
   //fflush(stderr);
   
   //res = ftt_read(d, data, BlockLength);
   res = ftt_retry(d, 4, ftt_read, data, BlockLength);
   return res;
}


int HasData(char *data, int start, int len)
{
   while (len --)
     {
	if (data[start ++] != ' ')
	  return 1;
     }
   return 0;
}
