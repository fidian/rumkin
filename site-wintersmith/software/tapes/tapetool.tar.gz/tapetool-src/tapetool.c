#include <unistd.h>
#include <stdio.h>
#include <getopt.h>
#include <ftt.h>
#include <stdlib.h>
#include "download.h"
#include "dump.h"
#include "label.h"
#include "mark.h"
#include "salvage.h"
#include "scan.h"
#include "mt.h"

#define ACTION_NONE 0
#define ACTION_LABEL 1
#define ACTION_SCAN 2
#define ACTION_MARK 3
#define ACTION_SALVAGE 4
#define ACTION_DUMP 5
#define ACTION_DOWNLOAD 6
#define ACTION_STATUS 7
#define ACTION_EJECT 8
#define ACTION_REWIND 9


int verbose;  // Verbosity level
char *tape_dev;  // Pointer to tape device string
ftt_descriptor d;  // Tape device descriptor


int main(int argc, char **argv)
{
   int c;
   static struct option long_options[] =
     {
	  {"download", 2, 0, 0},
	  {"header", 1, 0, 0},  // extra parameter for --download
	  {"footer", 1, 0, 0},  // extra parameter for --download
	  {"dump", 2, 0, 0},
	  {"device", 1, 0, 'd'},
	  {"eject", 0, 0, 0},
	  {"help", 0, 0, 'h'},
	  {"label", 0, 0, 0},
	  {"mark", 2, 0, 0},
	  {"rewind", 0, 0, 0},
	  {"salvage", 2, 0, 0},
	  {"scan", 0, 0, 0},
	  {"status", 0, 0, 0},
	  {"verbose", 0, 0, 'v'},
	  {0, 0, 0, 0}
     };
   int option_index;
   char tape_device[] = "/dev/st0";
   int ReturnCode = 0;
   int action = ACTION_NONE;
   int Marks = 1;
   char *filename = NULL, *header_filename = NULL, *footer_filename = NULL;
   
   tape_dev = tape_device;
   
   // Get options
   while ((c = getopt_long(argc, argv, "d:hv", long_options, &option_index)) 
	  != -1)
     {
	switch (c)
	  {
	   case 0:
	     if (! strcmp(long_options[option_index].name, "header"))
	       {
		  header_filename = optarg;
		  break;
	       }
	     if (! strcmp(long_options[option_index].name, "footer"))
	       {
		  footer_filename = optarg;
		  break;
	       }
	     if (action != ACTION_NONE)
	       {
		  fprintf(stderr, "You can only specify one action.\n");
		  return 1;
	       }
	     if (! strcmp(long_options[option_index].name, "label"))
	       action = ACTION_LABEL;
	     else if (! strcmp(long_options[option_index].name, "scan"))
	       action = ACTION_SCAN;
	     else if (! strcmp(long_options[option_index].name, "status"))
	       action = ACTION_STATUS;
	     else if (! strcmp(long_options[option_index].name, "rewind"))
	       action = ACTION_REWIND;
	     else if (! strcmp(long_options[option_index].name, "eject"))
	       action = ACTION_EJECT;
	     else if (! strcmp(long_options[option_index].name, "salvage"))
	       {
		  action = ACTION_SALVAGE;
		  if (optarg && strcmp(optarg, "-"))
		    filename = optarg;
	       }
	     else if (! strcmp(long_options[option_index].name, "dump"))
	       {
		  action = ACTION_DUMP;
		  if (optarg && strcmp(optarg, "-"))
		    filename = optarg;
	       }
	     else if (! strcmp(long_options[option_index].name, "download"))
	       {
		  action = ACTION_DOWNLOAD;
		  if (optarg && strcmp(optarg, "-"))
		    filename = optarg;
	       }
	     else if (! strcmp(long_options[option_index].name, "mark"))
	       {
		  action = ACTION_MARK;
		  if (optarg && atoi(optarg)) 
		    Marks = atoi(optarg);
	       }
	     else
	       {
		  fprintf(stderr, "Improper action!\n");
		  return 1;
	       }
	     break;
	     
	   case 'd':
	     // Specify tape device
	     if (optarg)
	       tape_dev = optarg;
	     else
	       {
		  fprintf(stderr, "-d option used without specifying a device!\n");
		  return 1;
	       }
	     break;
	     
	   case 'v':
	     if (verbose < 2)
	       verbose ++;
	     break;
	     
	   case '?':
	     if (optopt >= ' ' && optopt <= '~')
	       fprintf(stderr, "Unknown option '-%c'.\n", optopt);
	     else
	       fprintf(stderr, "Unknown option character '\\x%x'.\n", optopt);
	     fprintf(stderr, "Try using --help for help\n");
	     return 1;
	     
	   case 'h':
	     fprintf(stderr, "Options:\n");
	     fprintf(stderr, " -d DEVICE       Specify alternate tape device (default is %s)\n", tape_device);
	     fprintf(stderr, " -v              Verbose output (-vv is very verbose)\n");
	     fprintf(stderr, "\n");
	     fprintf(stderr, "Actions:  (You gotta specify only one)\n");
	     fprintf(stderr, " --download[=X]  Download tape to stdout (or to file X, if specified)\n");
	     fprintf(stderr, "   --header=X    When using --download, specify a file to dump\n");
	     fprintf(stderr, "   --footer=X    the header and/or footer to\n");
	     fprintf(stderr, " --dump[=X]      Dump the data at the current tape position to stdout\n");
	     fprintf(stderr, "                 To dump to a file, specify it as --dump=filename\n");
	     fprintf(stderr, " --eject         Eject tape from tape drive\n");
	     fprintf(stderr, " --label         Scan and print the label at the current tape position.\n");
	     fprintf(stderr, " --mark[=X]      Skip ahead/behind X marks (default = 1)\n");
	     fprintf(stderr, "                 To skip backwards, use --mark=-X\n");
	     fprintf(stderr, " --rewind        Rewind the tape\n");
	     fprintf(stderr, " --salvage[=X]   Save as much data as possible and send to stdout.\n");
	     fprintf(stderr, "                 To save to a file, specify it as --salvage=filename\n");
	     fprintf(stderr, " --scan          Scan entire tape, print block structure\n");
	     fprintf(stderr, " --status        Returns status of tape drive (0 = tape in)\n");
	     return 1;
	     
	   default:
	     fprintf(stderr, "?? getopt returned char code 0x%x ??\n", c);
	  }
     }
   
   if (verbose)
     {
	if (verbose > 1)
	  fprintf(stderr, "Very verbose\n");
        else
	  fprintf(stderr, "Verbose\n");
	
	fprintf(stderr, "Using device %s\n", tape_dev);
     }
   
   if (verbose)
     fprintf(stderr, "Opening tape device %s read only\n", tape_dev);

   if (action == ACTION_NONE)
     {
	fprintf(stderr, "No action specified.  Refer to --help\n");
	return 1;
     }
   
   d = ftt_open(tape_dev, FTT_RDONLY);
   
   if (d == 0)
     {
	fprintf(stderr, "Error opening the tape device %s\n", tape_dev);
	return -1;
     }
   
   // Insert stuff here
   if (action == ACTION_LABEL)
     ReturnCode = ReadLabel();
   else if (action == ACTION_SCAN)
     ReturnCode = ScanTape();
   else if (action == ACTION_MARK)
     ReturnCode = GoToMark(Marks);
   else if (action == ACTION_SALVAGE)
     ReturnCode = SalvageData(filename);
   else if (action == ACTION_DUMP)
     ReturnCode = Dump(filename);
   else if (action == ACTION_DOWNLOAD)
     ReturnCode = DownloadTape(filename, header_filename, footer_filename);
   else if (action == ACTION_STATUS)
     ReturnCode = MT_Status();
   else if (action == ACTION_EJECT)
     ReturnCode = MT_Eject();
   else if (action == ACTION_REWIND)
     ReturnCode = MT_Rewind();
   
   ftt_close(d);

   if (verbose > 1)
     fprintf(stderr, "Return code %d\n", ReturnCode);
   
   return ReturnCode;
}
