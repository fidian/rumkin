#include <stdio.h>
#include <stdlib.h>
#include <ftt.h>
#include "convert.h"
#include "tapetool.h"
#include "util.h"


#define CLOSEFP(fp) if (fp != NULL && fp != stdout) fclose(fp);


int DownloadTape(char *filename, char *header_filename, char *footer_filename)
{
   char data[MAX_BLOCK_SIZE];
   int res;
   int labelType;
   char VolumeID[7];
   char FileID[18];
   char FileSetID[7];
   char CreateDate[7];
   char RecordFormat = '\000';
   int SectionNum = 0;
   int BlockLength = 0;
   int RecordLength = 0;
   int BufferOnset = 0;
   FILE *fp = NULL, *header_fp = NULL, *footer_fp = NULL;
   long BlocksRead = 0;
   long blockBytesRead;
   unsigned long long BytesRead = 0;
   
   
   // Open the required files, starting with the main data stream
   if (filename != NULL)
     fp = fopen(filename, "wb");
   else  
     fp = stdout;
   if (! fp)
     {
	fprintf(stderr, "Error opening file:  %s", filename);
	return -20;
     }
   
   // Header
   if (header_filename != NULL)
     {
	header_fp = fopen(header_filename, "wb");
	if (! header_fp)
	  {
	     CLOSEFP(fp);
	     fprintf(stderr, "Error opening header file:  %s", 
		     header_filename);
	     return -21;
	  }
     }
   else
     header_fp = NULL;
   
   
   // Footer
   if (footer_filename != NULL)
     {
	footer_fp = fopen(footer_filename, "wb");
	if (! footer_fp)
	  {
	     CLOSEFP(fp);
	     CLOSEFP(header_fp);
	     fprintf(stderr, "Error opening footer file:  %s",
		     footer_filename);
	     return -21;
	  }
     }
   else
     footer_fp = NULL;
   
   
   // Start at the beginning
   if (ftt_rewind(d) == -1)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Error rewinding tape\n");
	return -1;
     }
   
   // need to read the header block
   if ((res = ftt_read(d, data, MAX_BLOCK_SIZE)) == -1)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Error reading header block\n");
	return -2;
     }
   
   // Detect ANSI versus IBM header types (IBM is in EBCDIC)
   labelType = DetectHeaderType(data);
   if (labelType == FTT_UNKNOWN_HEADER)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	HexDump(data, res);
	fprintf(stderr, "Unsupported/undetected header type\n");
	return -3;
     }
   
   while (res == 80)
     {
	if (labelType == FTT_IBM_HEADER)
	  EBCDIC_to_ASCII(data, res);

	if (header_fp != NULL)
	  fwrite(data, 1, res, header_fp);

	if (verbose > 1)
	  HexDump(data, res);
	
	switch (*((long *) data))
	  {
	     // See notes in label.c for more information
	   case 0x314c4f56:  // VOL1
	     strcpy(VolumeID, GetString(data, 4, 6));
	     break;
	   case 0x31524448:  // HDR1
	     strcpy(FileID, GetString(data, 4, 17));
	     strcpy(FileSetID, GetString(data, 21, 6));
	     SectionNum = atoi(GetString(data, 27, 4));
	     strcpy(CreateDate, GetString(data, 41, 6));
	     break;
	   case 0x32524448:  // HDR2
	     RecordFormat = data[4];
	     BlockLength = atoi(GetString(data, 5, 5));
	     RecordLength = atoi(GetString(data, 10, 5));
	     BufferOnset = atoi(GetString(data, 50, 2));
	     break;
	   default:
	     printf("Unknown section:  %lx\n", *((long *) data));
	     printf("\n");
	  }
	
	if ((res = ftt_read(d, data, MAX_BLOCK_SIZE)) == -1)
	  {
	     CLOSEFP(fp);
	     CLOSEFP(header_fp);
	     CLOSEFP(footer_fp);
	     fprintf(stderr, "Error reading header block\n");
	     return -3;
	  }
     }
   
   // Gobble up the rest of the data
   while (res > 0)
     {
	if (header_fp != NULL)
	  fwrite(data, 1, res, fp);
	
	res = ftt_read(d, data, MAX_BLOCK_SIZE);
     }
   
   // Check for errors
   if (res < 0)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Error reading misc blocks until tape mark\n");
	return -3;
     }
   
   if (verbose > 1)
     {
	fprintf(stderr, "Volume ID:  %s\n", VolumeID);
	fprintf(stderr, "File ID:  %s\n", FileID);
	fprintf(stderr, "File Set ID:  %s\n", FileSetID);
	fprintf(stderr, "Section Number:  %d\n", SectionNum);
	fprintf(stderr, "Create Date:  %s\n", CreateDate);
	fprintf(stderr, "Record Format:  %c\n", RecordFormat);
	fprintf(stderr, "Block Length:  %d\n", BlockLength);
	fprintf(stderr, "Record Length:  %d\n", RecordLength);
	fprintf(stderr, "Buffer Onset:  %d\n", BufferOnset);
     }
	
   // Check to make sure data is how we require it to be
   if (BufferOnset != 0)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Buffer Onset is not zero\n");
	return -4;
     }
   if (RecordFormat != 'F' && RecordFormat != 'V')
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Record Format is not F nor V\n");
	return -5;
     }
   
   // Write tape data to destination file
   res = ftt_read(d, data, MAX_BLOCK_SIZE);
   while (res > 0)
     {
	BytesRead += (unsigned long) res;
	BlocksRead ++;
	fwrite(data, 1, res, fp);
	res = ftt_read(d, data, MAX_BLOCK_SIZE);
	if (res < 0)
	  {
	     CLOSEFP(fp);
	     CLOSEFP(header_fp);
	     CLOSEFP(footer_fp);
	     fprintf(stderr, "Problem reading data!  Perhaps use --salvage\n");
	     return -9;
	  }
     }
   
   if (verbose)
     fprintf(stderr, "Bytes Downloaded:  %llu\n", BytesRead);
   
   if (verbose > 1)
     fprintf(stderr, "Downloaded %ld blocks\n", BlocksRead);
   
   if (fp != stdout)
     fclose(fp);
   
   // Verify read with footer block
   
   if ((res = ftt_read(d, data, MAX_BLOCK_SIZE)) == -1)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Error reading footer block\n");
	return -10;
     }
   
   if (res != 80)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Error getting 80 bytes for footer.  Got %d bytes instead.",
		res);
	return -11;
     }

   if (labelType == FTT_IBM_HEADER)
     EBCDIC_to_ASCII(data, res);
   
   if (footer_fp != NULL)
     fwrite(data, 1, res, footer_fp);
   
   if (*((long *) data) != 0x31564F45 && *((long *) data) != 0x31464F45)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
	fprintf(stderr, "Footer is not EOV1 and is not EOF1\n");
	if (verbose > 1)
	  fprintf(stderr, "Footer is %c%c%c%c\n", data[0], data[1],
		  data[2], data[3]);
	return -12;
     }
   
   blockBytesRead = atol(GetString(data, 54, 6));
   if (verbose)
     fprintf(stderr, "%s Block Count:  %ld\n", GetString(data, 0, 4), 
	     blockBytesRead);
   if (BlocksRead != blockBytesRead)
     {
	CLOSEFP(fp);
	CLOSEFP(header_fp);
	CLOSEFP(footer_fp);
        fprintf(stderr, "Block count of %ld does not match my count of %ld\n",
	        blockBytesRead, BlocksRead);
	if (ftt_rewind(d) == -1)
	  {
	     fprintf(stderr, "... and an error occured during the tape rewind!");
	     return -15;
	  }
	return -14;
     }

   // Dump the rest of the footer to file
   res = ftt_read(d, data, MAX_BLOCK_SIZE);
   while (res > 0)
     {
	if (labelType == FTT_IBM_HEADER)
	  EBCDIC_to_ASCII(data, res);
	
	if (footer_fp != NULL)
	  fwrite(data, 1, res, footer_fp);

	res = ftt_read(d, data, MAX_BLOCK_SIZE);
     }
   
   CLOSEFP(fp);
   CLOSEFP(header_fp);
   CLOSEFP(footer_fp);

   if (ftt_unload(d) == -1)
     {
	fprintf(stderr, "Error unloading tape");
	return -16;
     }
   
   if (verbose)
     fprintf(stderr, "Tape download successful.");
   
   return 0;
}
