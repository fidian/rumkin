#include <stdio.h>
#include <stdlib.h>
#include <ftt.h>
#include "convert.h"
#include "tapetool.h"
#include "util.h"


int SalvageData(char *filename)
{
   char data[MAX_BLOCK_SIZE];
   int res;
   int labelType;
   char RecordFormat;
   int BlockLength = 0;
   FILE *fp;
   long BlocksRead = 0;
   char *p;
   long blockBytesRead;
   int GoodBlocks = 0, BadBlocks = 0;
   
   RecordFormat = '\000';
   
   // All of the tapes we get from Target's tape library have just
   // one file.  The file is possibly spread over multiple tapes.
  
   if (ftt_rewind(d) == -1)
     {
	fprintf(stderr, "Error rewinding tape\n");
	return -1;
     }   
   
   // need to read the header block
   if ((res = ftt_read(d, data, MAX_BLOCK_SIZE)) == -1)
     {
	fprintf(stderr, "Error reading header block\n");
	return -7;
     }
   
   // Detect ANSI versus IBM header types (IBM is in EBCDIC)
   labelType = DetectHeaderType(data);
   if (labelType == FTT_UNKNOWN_HEADER)
     {
	HexDump(data, res);
	fprintf(stderr, "Unsupported/undetected header type\n");
	return -3;
     }
   
   while (res == 80)
     {
	if (labelType == FTT_IBM_HEADER)
	  EBCDIC_to_ASCII(data, res);

	if (verbose > 1)
	  HexDump(data, res);
	
	// See notes in label.c for more information
	if (*((long *) data) == 0x32524448) // HDR2
	  {
	     RecordFormat = data[4];
	  }
	
	if ((res = ftt_read(d, data, MAX_BLOCK_SIZE)) == -1)
	  {
	     fprintf(stderr, "Error reading header block\n");
	     return -8;
	  }
     }
   
   if (RecordFormat == '\000')
     {
	fprintf(stderr, "Record format not found in tape header\n");
	return -5;
     }
  
   if (RecordFormat != 'F' && RecordFormat != 'V')
     {
	fprintf(stderr, "Record Format is not F nor V\n");
	return -6;
     }
   
   // Open target file
   if (filename != NULL)
     fp = fopen(filename, "wb");
   else  
     fp = stdout;
   if (! fp)
     {
	fprintf(stderr, "Error opening file:  %s", filename);
	return -2;
     }
   
   // Write file to destination file

   if (RecordFormat == 'F')
     {
	res = ReadBlock(d, data, BlockLength, BlocksRead);
	BlocksRead ++;
	while (res != 0)
	  {
	     if (res > 0)
	       {
		  // Good block
		  GoodBlocks ++;
		  fwrite(data, 1, res, fp);
	       }
	     else
	       {
		  // Bad block
		  BadBlocks ++;
		  p = ftt_get_error(&res);
		  fprintf(stderr, "\n");
		  fprintf(stderr, "Error:  %s\n", ftt_ascii_error[res]);
		  fprintf(stderr, "Error String:  %s\n", p);
		  fprintf(stderr, "Bad block -- # %ld\n", BlocksRead);
		  
		  if (res == FTT_EUNRECOVERED) 
		    {
		       fprintf(stderr, "Unable to recover more from the tape.\n");
		       ftt_rewind(d);
		       ftt_unload(d);
		       ftt_close(d);
		       return -1;
		    }
		  
		  memset(data, '\0', BlockLength);
		  fwrite(data, 1, BlockLength, fp);
		  
		  fprintf(stderr, "Attempting to skip bad block\n");
		  
		  ftt_rewind(d);
		  ftt_skip_fm(d, 1);
		  ftt_skip_rec(d, BlocksRead);
	       }
	     res = ReadBlock(d, data, BlockLength, BlocksRead);
	     BlocksRead ++;
	  }
     }
   else
     {
	fprintf(stderr, 
		"I am not able to salvage variable-length records yet.\n");
     }

   if (fp != stderr)
     fclose(fp);
   
   fprintf(stderr, "\nDone salvaging data.\n");

   fprintf(stderr, "\n");
   fprintf(stderr, "Good blocks:  %10d\n", GoodBlocks);
   fprintf(stderr, "Bad blocks:   %10d\n", BadBlocks);
   fprintf(stderr, "Total blocks found with salvage:  %10d\n",
	   GoodBlocks + BadBlocks);
   
   res = ftt_read(d, data, MAX_BLOCK_SIZE);
   
   if (res == -1)
     {
	fprintf(stderr, "\nError reading footer block.  ");
	fprintf(stderr, "Can't verify totals.\n");
        return -2;
     }
   
   if (res != 80)
     {
	fprintf(stderr, "\nError getting 80 bytes for footer.  ");
	fprintf(stderr, "Got %d bytes instead.\n", res);
	return -3;
     }

   if (labelType == FTT_IBM_HEADER)
     EBCDIC_to_ASCII(data, res);
   
   if (*((long *) data) != 0x31564F45 && *((long *) data) != 0x31464F45)
     {
	fprintf(stderr, "\nFooter is not EOV1 and is not EOF1.  ");
	fprintf(stderr, "Can't verify block count.\n");
	return -4;
     }
   
   blockBytesRead = atol(GetString(data, 54, 6));

   fprintf(stderr, "Total blocks according to tape:   %10ld\n",
	   blockBytesRead);
   
   ftt_rewind(d);
   ftt_unload(d);
   
   return 0;
}
