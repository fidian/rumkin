void HexDump(char *data, int len);
int DetectHeaderType(char *data);
char *GetString(char *data, int start, int len);
int ReadBlock(ftt_descriptor d, char *data, int BlockLength, int BlocksRead);
int HasData(char *data, int start, int len);
