void EBCDIC_to_ASCII(char *src, unsigned int len);
