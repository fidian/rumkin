int ScanTape(void);
