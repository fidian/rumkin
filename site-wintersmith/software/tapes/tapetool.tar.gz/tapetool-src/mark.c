#include <stdio.h>
#include <ftt.h>
#include "tapetool.h"


int GoToMark(int Marks)
{
   if (verbose)
     fprintf(stderr, "Moving %d marks\n", Marks);
   
   if (ftt_skip_fm(d, Marks) == -1)
     {
	fprintf(stderr, "Error skipping to file mark\n");
	return 1;
     }
   
   return 0;
}
