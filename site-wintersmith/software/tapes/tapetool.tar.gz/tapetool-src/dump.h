int Dump(char *filename);
