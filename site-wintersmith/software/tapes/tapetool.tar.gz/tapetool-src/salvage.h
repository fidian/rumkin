int SalvageData(char *filename);
