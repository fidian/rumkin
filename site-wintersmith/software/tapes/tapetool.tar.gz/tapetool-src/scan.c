#include <stdio.h>
#include <ftt.h>
#include "convert.h"
#include "tapetool.h"


int ScanTape(void)
{
   char data[MAX_BLOCK_SIZE];
   int res;
   int OldSize;
   int Count;
   
   printf("Size\tBlocks\n");

   if (ftt_rewind(d) == -1)
     {
	fprintf(stderr, "Error rewinding tape\n");
	return 1;
     }

   OldSize = -1;
   Count = 0;
   res = ftt_read(d, data, MAX_BLOCK_SIZE);
   while (res != -1)
     {
	if (OldSize != res)
	  {
	     if (OldSize > 0)
	       printf("%d\t%d\n", OldSize, Count);
	     Count = 0;
	     OldSize = res;
	  }
	if (res == 0)
	  {
	     printf("---- Tape mark ----\n");
	     if (Count == 1)
	       res = -1;  // force abort
	  }
	
	Count ++;
	
	if (res != -1)
	  res = ftt_read(d, data, MAX_BLOCK_SIZE);
     }
   
   if (res != -1)
     printf("%d\t%d\n", OldSize, Count);
   
   ftt_close(d);
   
   return 0;
}
