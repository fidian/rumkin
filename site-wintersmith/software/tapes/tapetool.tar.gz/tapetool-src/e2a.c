#include <stdio.h>
#include "convert.h"

int main(void)
{
   char Data[32768];
   size_t bytes;
   
   while ((bytes = fread(Data, 1, 32768, stdin)) > 0)
     {
	EBCDIC_to_ASCII(Data, (unsigned int) bytes);
	fwrite(Data, 1, bytes, stdout);
     }
   return 0;
}
