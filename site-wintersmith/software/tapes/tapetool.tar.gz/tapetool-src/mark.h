int GoToMark(int Marks);
