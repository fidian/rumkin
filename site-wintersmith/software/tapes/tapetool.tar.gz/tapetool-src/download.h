int DownloadTape(char *filename, char *header_filename, 
		 char *footer_filename);
