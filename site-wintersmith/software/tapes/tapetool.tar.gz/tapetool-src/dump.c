#include <stdio.h>
#include <ftt.h>
#include "tapetool.h"


int Dump(char *filename)
{
   char data[MAX_BLOCK_SIZE];
   int res;
   FILE *fp;
   
   if (filename != NULL)
     fp = fopen(filename, "wb");
   else
     fp = stdout;
   
   if (! fp)
     {
	fprintf(stderr, "Error opening file %s\n", filename);
	return 38;
     }
   
   if (verbose)
     fprintf(stderr, "Downloading tape to %s\n", (fp == stdout)? "stdout" :
	     filename);
   
   res = ftt_read(d, data, MAX_BLOCK_SIZE);
   
   while (res > 0)
     {
	fwrite(data, 1, res, fp);
	res = ftt_read(d, data, MAX_BLOCK_SIZE);
     }
   
   if (fp != stdout)
     fclose(fp);
   
   return 0;
}
