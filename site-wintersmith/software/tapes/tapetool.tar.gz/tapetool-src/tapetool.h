extern int verbose;  // Verbosity level
extern char *tape_dev;  // Pointer to tape device string
extern ftt_descriptor d;

#define MAX_BLOCK_SIZE 32768
