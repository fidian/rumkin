int ReadLabel(void);
