/* SUD h0_DeCrypt h0crpv Decrypt using Blowfish

Synopsis:

     #include "h0crpt.h"
     void h0_DeCrypt(
        const cryptWord32 *pad,
        const cryptWord32 *pIn,
        cryptWord32 *pOut);

Description:

     Perform decryption of an 8-byte data block (aligned as two unsigned
     32-bit integers), using the Blowfish algorithm. For a complete
     discussion, see the preamble to @h0_CryptInitPad@.

     Programmer: Hrvoje Lukatela, 1998. This code is in the public domain;
     there are no restrictions on its use or distribution, and no guarantees,
     either explicit or implied.

     For updates, consult: http://www.geodyssey.com/cryptography.html

Arguments:

     pad:      Pointer to an array of @H0_CRYPT_PAD_LENGTH@ (32-bit)
               integers, values given, work-area previously initialized
               by @h0_CryptInitPad@.

     pIn:      Pointer to given ciphertext: an array of
               @H0_CRYPT_BLOCK_LENGTH@ integers, data to be decrypted.

     pOut:     Pointer to returned plaintext: a memory block of the same
               size as that pointed to by ~pIn~, location to which the
               decrypted data will be written. Note that it is possible to
               decrypt in-situ, by making ~pOut~ equal to ~pIn~.

See Also:

     h0_CryptInitPad, h0_EnCrypt
EUD */

#include    "h0crpt.h"

void h0_DeCrypt(const cryptWord32 *pad,
                const cryptWord32 *pIn,
                cryptWord32 *pOut) {

   cryptWord32 xL, xR;
/* -------------------------------------------------------------------------- */
   xL = pIn[0];                                             /* get input data */
   xR = pIn[1];

   FR(pad, 17, xL, xR);                          /* reverse 16 Feistel rounds */
   FR(pad, 16, xR, xL);
   FR(pad, 15, xL, xR);
   FR(pad, 14, xR, xL);
   FR(pad, 13, xL, xR);
   FR(pad, 12, xR, xL);
   FR(pad, 11, xL, xR);
   FR(pad, 10, xR, xL);
   FR(pad,  9, xL, xR);
   FR(pad,  8, xR, xL);
   FR(pad,  7, xL, xR);
   FR(pad,  6, xR, xL);
   FR(pad,  5, xL, xR);
   FR(pad,  4, xR, xL);
   FR(pad,  3, xL, xR);
   FR(pad,  2, xR, xL);

   pOut[1] = xL ^ (pad + P_OFFST)[1];                      /* put output data */
   pOut[0] = xR ^ (pad + P_OFFST)[0];
   return;
   }
/* -------------------------------------------------------------------------- */
