/* SUD h0_EnCrypt h0crpu Encrypt using Blowfish

Synopsis:

     #include "h0crpt.h"
     void h0_EnCrypt(
        const cryptWord32 *pad,
        const cryptWord32 *pIn,
        cryptWord32 *pOut);

Description:

     Perform encryption of an 8-byte data block (aligned as two unsigned
     32-bit integers), using the Blowfish algorithm. For a complete
     discussion, see the preamble to @h0_CryptInitPad@.

     Programmer: Hrvoje Lukatela, 1998. This code is in the public domain;
     there are no restrictions on its use or distribution, and no guarantees,
     either explicit or implied.

     For updates, consult: http://www.geodyssey.com/cryptography.html

Arguments:

     pad:      Pointer to an array of @H0_CRYPT_PAD_LENGTH@ (32-bit)
               integers, values given, work-area previously initialized
               by @h0_CryptInitPad@.

     pIn:      Pointer to given plaintext: an array of
               @H0_CRYPT_BLOCK_LENGTH@ integers, data to be encrypted.

     pOut:     Pointer to returned ciphertext: a memory block of the same
               size as that pointed to by ~pIn~, location to which the
               encrypted data will be written. Note that it is possible to
               encrypt in-situ, by making ~pOut~ equal to ~pIn~.

See Also:

     h0_CryptInitPad, h0_DeCrypt
EUD */

#include    "h0crpt.h"

void h0_EnCrypt(const cryptWord32 *pad,
                const cryptWord32 *pIn,
                cryptWord32 *pOut) {

   cryptWord32 xL, xR;
/* -------------------------------------------------------------------------- */
   xL = pIn[0];                                             /* get input data */
   xR = pIn[1];

   FR(pad,  0, xL, xR);                          /* perform 16 Feistel rounds */
   FR(pad,  1, xR, xL);
   FR(pad,  2, xL, xR);
   FR(pad,  3, xR, xL);
   FR(pad,  4, xL, xR);
   FR(pad,  5, xR, xL);
   FR(pad,  6, xL, xR);
   FR(pad,  7, xR, xL);
   FR(pad,  8, xL, xR);
   FR(pad,  9, xR, xL);
   FR(pad, 10, xL, xR);
   FR(pad, 11, xR, xL);
   FR(pad, 12, xL, xR);
   FR(pad, 13, xR, xL);
   FR(pad, 14, xL, xR);
   FR(pad, 15, xR, xL);

   pOut[1] = xL ^ (pad + P_OFFST)[16];                     /* put output data */
   pOut[0] = xR ^ (pad + P_OFFST)[17];
   return;
   }
/* -------------------------------------------------------------------------- */
