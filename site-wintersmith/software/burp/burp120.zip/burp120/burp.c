/* =========================================================================
 *               BURP: (Blowfish.Updated.Re-entrant.Project)
 *     Blowfish based, command-line file encryption/decryption program.
 * =========================================================================
 *               Programmer: Hrvoje Lukatela, 1998, 2002.
 *    This code is in the public domain; there are no restrictions on its
 *    use or distribution, and no guarantees, either explicit or implied.
 * =========================================================================
 *  Full documentation of BURP features and operation is in BURP.TXT file.
 *  New versions of this program can be found at http://www.geodyssey.com/
 * ========================================================================= */

#define PGM_VERSION 1.2    /* NB: odd .x fraction number: test/beta versions */

#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <stdarg.h>
#include <time.h>

/* "console" line entry via stdin (with echo), always present. */
static int getLine(char *, int);

/* Version (BRVR_...) must be defined on the compiler command line.
 * It should be one of the following:
 *
 * BRVR_BEUX32 : Unix workstations, big-endian
 * BRVR_INTLX  : Intel Linux
 * BRVR_OS2    : OS/2
 * BRVR_WIN32  : Win32
 * BRVR_DOS16  : 16-bit DOS
 *
 * If none of the above apply, create a new "version" by revising the
 * "porting notes" below in the preamble and define the constants that
 * control integer width, byte order and non-echo console line input.
 */

#if defined BRVR_BEUX32
#define H0_W32_BYTE_ORDER_0123
#define H0_W32_BYTE_ORDER_DEFINED
#if !defined _POSIX_SOURCE
#define _POSIX_SOURCE
#endif

#elif defined BRVR_INTLX
#if !defined _POSIX_SOURCE
#define _POSIX_SOURCE
#endif

#elif defined BRVR_OS2
#if !defined _OS2
#define _OS2
#endif

#elif defined BRVR_WIN32
#if !defined _WIN32
#define _WIN32
#endif

#elif defined BRVR_DOS16                            /* 16-bit DOS */
#if !defined _MSDOS
#define _MSDOS
#define INT16_ENV
#endif

#else
#error "No platform/version defined - see BRVR_... in burp.c"
#endif

/* Porting note: echo-suppression
   ------------------------------
   Non-echo console i/o is impemented in two variants: DOS/Windows, and
   POSIX "termios" facility. If the program is ported to an environment
   that provides neither, it could default to a simple stdio console,
   and no echo-supression will be possible. Before compiling, ensure
   an appropriate define (e.g., _POSIX_SOURCE, _WIN32, etc.) is either
   defined by the compiler, or specified explicitly above.
 */
#if defined _POSIX_SOURCE                      /* ...for POSIX */
#include <termios.h>
#include <fcntl.h>
static void promptWait(char *);
static int openConsole();
static void closeConsole(int);
static int getNoEchoLine(int, char *, int, int);
#define osFileNameCompare(a, b) strcmp(a, b)
#define POSIX_CONSOLE_PTIN

#elif defined _WIN32                         /* ...for Windows */
#include <conio.h>
#include <io.h>                              /* for 'access()' */
static void promptWait(char *);
#define openConsole() 0
#define closeConsole(i)
static int getNoEchoLine(int, char *, int, int);
#define osFileNameCompare(a, b) stricmp(a, b)
#define WDOS_CONSOLE_PTIN

#elif defined _OS2                               /* ...for OS2 */
#include <conio.h>
#include <io.h>                              /* for 'access()' */
static void promptWait(char *);
#define openConsole() 0
#define closeConsole(i)
static int getNoEchoLine(int, char *, int, int);
#define osFileNameCompare(a, b) stricmp(a, b)
#define WDOS_CONSOLE_PTIN

#elif defined _MSDOS                          /* ...for MS-DOS */
#include <conio.h>
#include <io.h>                              /* for 'access()' */
static void promptWait(char *);
#define openConsole() 0
#define closeConsole(i)
static int getNoEchoLine(int, char *, int, int);
#define osFileNameCompare(a, b) stricmp(a, b)
#define WDOS_CONSOLE_PTIN

#else                            /* other, no echo-suppression */
static void promptWait(char *);
#define openConsole() 0
#define closeConsole(i)
#define getNoEchoLine(a, b, c, d) -1    /* dummy, never called */
#define osFileNameCompare(a, b) fileNameCompare(const char *, const char *)
#define STDIN_PTIN
#endif

#define NORMAL_ECHO         -1
#define CONSOLE_UNDEFINED   -1
#define CONSOLE_READ_ERROR  -1

/* Porting note: integer-width
   ---------------------------
   If compiling on a 16-bit integer environment, INT16_ENV must be defined
   by this point, otherwise the code will default to 32-bit integers. */
/* #define INT16_ENV */

#if defined INT16_ENV
typedef unsigned long int cryptWord32;
#define H0_CRYPTWORD32_DEFINED
typedef unsigned long int fileSizeInt;
#else
typedef unsigned int fileSizeInt;
#endif

/* Porting note: byte-order
   ------------------------
   If the byte-order ("endian") issues are ignored, BURP will work correctly,
   but the cyphertext will be ENDIAN/PLATFORM SPECIFIC! This is an extremely
   undesirable situation. The defines in h0crpt.h will default to little
   (i.e., Intel) endian and 32-bit natural integer (see above). To change
   for compiling on big endian (i.e., Motorola) environments, define:
#define H0_W32_BYTE_ORDER_0123
#define H0_W32_BYTE_ORDER_DEFINED
   (BEFORE the following include...)
 */

#include "h0crpt.h"

#if defined H0_W32_BYTE_ORDER_3210             /* more endian-dependent stuff */
#define order4Bytes(buf, nw32)         /* On LittleEndian (Intel) compile out */
#elif defined H0_W32_BYTE_ORDER_0123            /* Big endian (i.e. Motorola) */
static void order4Bytes(unsigned char *buf, int nw32) {
   cryptWord32 t;
   do {
      t = (cryptWord32)((unsigned)buf[3] << 8 | buf[2]) << 16 | ((unsigned)buf[1] << 8 | buf[0]);
      *(cryptWord32 *) buf = t;
      buf += 4;
      } while (--nw32);
   }
#endif

static void usage(char *, char *);
static int  clineOption(int , char **, char **);
static char *clineFileName(int, char **);
static int  stripQuotes(char *);
static void errorExit(int, char *, ...);
static int  getString(char *, int *, int, int, int);
static void getClockByte(unsigned char *, int *);
static void ruboutFile(char *, fileSizeInt);
static int  getCryptBlock(int, int, int, int, FILE *, char *);
static int  putCryptBlock(int, FILE *, char *, int);
static int  fileNameCompare(const char *, const char *);

#define H0_CRYPT_BLOCK_BYTES ((int)(H0_CRYPT_BLOCK_LENGTH * sizeof(cryptWord32))) /* ..in chars */
#define HASH_INTS                4
#define HASH_BYTES              16

#define MAX_KEY_BYTES           16
#define MIN_KEY_BYTES            8

#define MAX_PSPR_BYTES         256
#define MIN_PSPR_BYTES          32

#define SCREEN_LINES            25

#define I_ENCR                   1
#define I_DECR                   2

#define RAND_INTS                8
#define RAND_BYTES    (RAND_INTS * sizeof(cryptWord32))
#define READ_OK                  4             /* To test for read permission */
#define WRITE_OK                 2            /* To test for write permission */
#define EXIST_OK                 0              /* To test for file existence */

#define LINE_LENGTH            256
#define CON_BUF_LENGTH         512

static char consoleBuffer[CON_BUF_LENGTH + 2];
static char *progname;
static int fd;

#define myMin(a, b)      (((a) < (b)) ? (a) : (b))

int main(int argc, char **argv) {

   char     fnA[FILENAME_MAX + 2];
   char     fnB[FILENAME_MAX + 2];
   FILE    *inFp, *outFp;

   cryptWord32 cryptBlock[H0_CRYPT_BLOCK_LENGTH];
   cryptWord32 prevBlock[H0_CRYPT_BLOCK_LENGTH];

   fileSizeInt    nBytes;
   int            istat, k, n, m, nlns, nxt;
   int            insitu, iecho, iencr, incon, outcon, ihash, keylen, iFlpy;
   char           passPhrase[LINE_LENGTH + 2];
   char           passPhraseConfirm[LINE_LENGTH + 2];
   unsigned char  key[MAX_KEY_BYTES + 2];
   cryptWord32    pad[H0_CRYPT_PAD_LENGTH];
   cryptWord32   *pu;
   cryptWord32    randArr[RAND_INTS];                /* random stuff, as ints */
   unsigned char *prb;                                        /* ... as bytes */
   int            ixrb;                                /* byte index in above */
   cryptWord32    hash[HASH_INTS];                     /* hashed random bytes */
   cryptWord32    fr[H0_CRYPT_BLOCK_LENGTH];           /* feedback "register" */
   int            optch;
   char          *optval;
   char          *progfullname;
   char          *pa;
/* -------------------------------------------------------------------------- */
   progfullname = (char *)malloc(strlen(argv[0]) + 1);
   strcpy(progfullname, argv[0]);

   randArr[0] = (int)argv;      /* assume we'll want some random bytes for IV */
   randArr[1] = time(NULL);                           /* best of all is timer */
   pu = (cryptWord32 *)malloc(1);
   if (pu) {
      if (*pu) randArr[2] = *pu;      /* if yes, heap junk, if no, stack junk */
      free(pu);
      }
   getClockByte(NULL, NULL);                 /* initialize clock byte sampler */
   prb = (unsigned char *)randArr;
   ixrb = 3 * sizeof(int);        /* 3 ints filled, rest picked, byte by byte */
   getClockByte(prb, &ixrb);                /* from clock; get first of those */

   fprintf(stderr, "%s: file crypto, V:%.2f (http://www.geodyssey.com/)\n", progfullname, PGM_VERSION);
   if ((int)(PGM_VERSION * 10.0)%2) fprintf(stderr, "WARNING: beta release version for TEST USE ONLY!\n");
   pa = strrchr(progfullname, '.');
   if (pa) *pa = '\0';
   pa = strrchr(progfullname, '\\');
   if (pa) progname = pa + 1;
   else progname = progfullname;
   *passPhrase = '\0';   /* must be entered on the command line, or we prompt */
   iencr = 0;                                       /* must enter either flag */
   incon = outcon = 0;                         /* input/output to the console */
   iecho = '#';                                             /* "masking" echo */
   ihash = 1;                                  /* assume pass-phrase, not key */
   insitu = 0;                           /* assume different input and output */
   iFlpy = 0;                                   /* no puuse for floppy change */
   nlns = 0;           /* setting default lines for "more-like" screen output */
   fd = CONSOLE_UNDEFINED;          /* no special echo-less console is opened */
   if (iencr == I_ENCR) getClockByte(prb, &ixrb);
   *fnA = *fnB = '0';
   nBytes = 0;

   while ((optch = clineOption(argc, argv, &optval)) != -1) {    /* get flags */
      switch (optch) {
         case 'd':                                                 /* decrypt */
         if (iencr) errorExit(__LINE__, "Both -e and -d flags given.\n");
         iencr = I_DECR;
         if (*optval == 's') outcon = 1;
         else if (*optval == 'o') errorExit(__LINE__, "Plaintext can not overlay ciphertext.\n");
         break;
         case 'c': iecho = NORMAL_ECHO; break;                  /* clear echo */
         case 'f': iFlpy = 1; break;               /* pause for floppy change */
         case 'e':                                                 /* encrypt */
         if (iencr) errorExit(__LINE__, "Both -e and -d flags given.\n");
         iencr = I_ENCR;
         if (*optval == 'k') incon = 1;
         else if (*optval == 'o') insitu = 1;
         break;
         case 'k': ihash = 0;                                    /* key given */
         case 'p': strncpy(passPhrase, optval, LINE_LENGTH); break; /* passphrase given */
         case 'h': case '?': usage(progname, NULL); break;
         case 'l': nlns = atoi(optval); break;           /* screen line count */
         default: usage(progname, "unexpected option");
         }
      if (iencr == I_ENCR) getClockByte(prb, &ixrb);
      }
   if (argc < 2) usage(progname, NULL);
   if (iencr == 0) errorExit(__LINE__, "Neither -e(ncrypt) nor -d(ecrypt) flag given...\n");
   if (nlns == 0) nlns = SCREEN_LINES;

#ifdef STDIN_PTIN           /* compiled on platform without echo-less console */
   if (iecho > NORMAL_ECHO) fprintf(stderr, "WARNING: this version can not supress console echo!\n");
   iecho = NORMAL_ECHO;
#endif

   pa = clineFileName(argc, argv);                /* must get first file name */
   if (pa == NULL) errorExit(__LINE__, "No file name given\n");
   strcpy(fnA, pa);
   pa = clineFileName(argc, argv);
   if (incon || outcon || insitu) {     /* only one file name should be given */
      if (pa) {                                    /* second file name given? */
         if (incon) errorExit(__LINE__, "Reading from keyboard, two file names given\n");
         else if (outcon) errorExit(__LINE__, "Writing to screen, two file names given\n");
         else if (insitu) errorExit(__LINE__, "Overlay flag, two file names given\n");
         }
      }
   else {
      if (pa == NULL) errorExit(__LINE__, "Second file name missing\n");
      strcpy(fnB, pa);
      }
   if (iencr == I_ENCR) getClockByte(prb, &ixrb);

   if (iFlpy) {                 /* Must pause for program/data floppy change? */
      promptWait("Insert data disk and press any key to continue...\n");
      if (iencr == I_ENCR) getClockByte(prb, &ixrb);
      }

/* Before we start messing with crypto-magic, check file access/permissions.  */

   if (incon || outcon) {            /* reading keyboard or writing to screen */
      if (iencr == I_ENCR) {            /* encrypting from keyboard to file 1 */
         if ((access(fnA, EXIST_OK) == 0) && (access(fnA, WRITE_OK))) errorExit(__LINE__, "No write access, %s\n", fnA);
         }
      else if (iencr == I_DECR) {         /* decrypting from file 1 to screen */
         if (access(fnA, READ_OK)) errorExit(__LINE__, "No file or no read access, %s\n", fnA);
         }
      }
   else if (insitu) {                                  /* reading/writing fnA */
      if (access(fnA, READ_OK | WRITE_OK)) errorExit(__LINE__, "No file or no read/write access, %s\n", fnA);
      }
   else {                                 /* reading from fnA, writing to fnB */
      if (access(fnA, READ_OK)) errorExit(__LINE__, "No file or no read access, %s\n", fnA);
      if ((access(fnB, EXIST_OK) == 0) && (access(fnB, WRITE_OK))) errorExit(__LINE__, "No write access, %s\n", fnB);
      if (fileNameCompare(fnA, fnB) == 0) errorExit(__LINE__, "File names equal, %s %s\n", fnA, fnB);
      }
   if (iencr == I_ENCR) getClockByte(prb, &ixrb);

   if (*passPhrase == '\0') {         /* prompt to get the key or pass-phrase */
      if (iecho != NORMAL_ECHO) {             /* non-echo console is required */
         fd = openConsole();
         if (fd == CONSOLE_UNDEFINED) errorExit(__LINE__, "Error: unable to open console, quitting\n");
         }
      for (;;) {
         fprintf(stderr, "\renter key or pass-phrase=>");
         fflush(stderr);              /* some compilers do not if no line end */
         if (iecho == NORMAL_ECHO)  n = getLine(passPhrase, LINE_LENGTH);
         else n = getNoEchoLine(fd, passPhrase, LINE_LENGTH, iecho);
         if (n == CONSOLE_READ_ERROR) {
            memset(passPhrase, '\0', LINE_LENGTH);
            memset(passPhraseConfirm, '\0', LINE_LENGTH);
            errorExit(__LINE__, "Error reading console, quitting\n");
            }
         n = stripQuotes(passPhrase);
         if (iencr == I_ENCR) getClockByte(prb, &ixrb);
         if (n < 1) {
            memset(passPhrase, '\0', LINE_LENGTH);
            memset(passPhraseConfirm, '\0', LINE_LENGTH);
            errorExit(__LINE__, "Null key or pass-phrase, quitting\n");
            }
         fprintf(stderr, "\r   re-enter (to confirm)=>");
         fflush(stderr);              /* some compilers do not if no line end */
         if (iecho == NORMAL_ECHO)  m = getLine(passPhraseConfirm, LINE_LENGTH);
         else m = getNoEchoLine(fd, passPhraseConfirm, LINE_LENGTH, iecho);
         if (m == CONSOLE_READ_ERROR) {
            memset(passPhrase, '\0', LINE_LENGTH);
            memset(passPhraseConfirm, '\0', LINE_LENGTH);
            errorExit(__LINE__, "Error reading console, quitting\n");
            }
         m = stripQuotes(passPhraseConfirm);
         if (iencr == I_ENCR) getClockByte(prb, &ixrb);
         if (m == 0) {
            memset(passPhrase, '\0', LINE_LENGTH);
            memset(passPhraseConfirm, '\0', LINE_LENGTH);
            errorExit(__LINE__, "Null key or pass-phrase, quitting\n");
            }
         if ((m != n) || strcmp(passPhrase, passPhraseConfirm)) {
            fprintf(stderr, "\rTwo strings differ, try again...\n");
            continue;
            }
         if (n < MIN_KEY_BYTES) {
            memset(passPhrase, '\0', LINE_LENGTH);
            memset(passPhraseConfirm, '\0', LINE_LENGTH);
            errorExit(__LINE__, "Key must be at least %d characters long\n", MIN_KEY_BYTES);
            }
         if (n > MAX_KEY_BYTES) {
            if (n < MIN_PSPR_BYTES) {
               memset(passPhrase, '\0', LINE_LENGTH);
               memset(passPhraseConfirm, '\0', LINE_LENGTH);
               errorExit(__LINE__, "Pass-phrase must be at least %d characters long\n", MIN_PSPR_BYTES);
               }
            ihash = 1;
            }
         else ihash = 0;
         memset(passPhraseConfirm, '\0', LINE_LENGTH);
         break;
         }
      if (fd != CONSOLE_UNDEFINED) {
         closeConsole(fd);
         fd = CONSOLE_UNDEFINED;
         }
      }
   else {                         /* key or pass-phrase from the command line */
      n = strlen(passPhrase);
/*    fprintf(stderr, "pass-phrase from cmln\n", key, n);*/
      if ((ihash) && (n < MIN_PSPR_BYTES)) {
         memset(passPhrase, '\0', LINE_LENGTH);
         errorExit(__LINE__, "Pass-phrase must be at least %d characters long\n", MIN_PSPR_BYTES);
         }
      if (n < MIN_KEY_BYTES) {
         memset(passPhrase, '\0', LINE_LENGTH);
         errorExit(__LINE__, "Key must be at least %d characters long\n", MIN_KEY_BYTES);
         }
      if (iencr == I_ENCR) getClockByte(prb, &ixrb);
      }

   if (ihash) {              /* pass-phrase was entered, hash it into the key */
      istat = h0_HashBytes((unsigned char *)passPhrase, strlen(passPhrase), key);
      memset(passPhrase, '\0', LINE_LENGTH);        /* obliterate pass-phrase */
      if (istat) {
         memset(key, '\0', MAX_KEY_BYTES);           /* obliterate the key... */
         errorExit(__LINE__, "Unexpected pass-phrase hash error?\n");
         }
      keylen = MAX_KEY_BYTES;
      }
   else {
      memcpy(key, passPhrase, n);
      keylen = n;
      }

   if ((keylen < MIN_KEY_BYTES) || (keylen > MAX_KEY_BYTES)) errorExit(__LINE__, "Unexpected key length error %d\n", keylen);
/* for (n = 0; n < keylen; n++) fprintf(stderr, ".%03u", key[n]); fprintf(stderr, ". [%d]\n", keylen);*/
   if (iencr == I_ENCR) getClockByte(prb, &ixrb);

   istat = h0_CryptInitPad(pad, key, keylen);    /* initialize P.S. tables... */
   memset(key, '\0', MAX_KEY_BYTES);             /* ...and obliterate the key */
   errorExit(-1, (char *)pad);    /* from now on, error exit must rub out pad */
   if (istat) errorExit(__LINE__, "Unexpected pad initialization error?\n");
/* if (h0_CryptTestPad(pad)) fprintf(stderr, "See [AC] p.339\n");*/

   inFp = outFp = NULL;                            /* ready to open the files */
   if (incon || outcon) {            /* reading keyboard or writing to screen */
      if (iencr == I_ENCR) {            /* encrypting from keyboard to file A */
         outFp = fopen(fnA, "wb");
         if (outFp == NULL) errorExit(__LINE__, "Can't open %s for writing?\n", fnA);
         strcpy(fnB, fnA);                    /* fnB is now where we write to */
         strcpy(fnA, "keyboard");               /* and fnA where we read from */
         errorExit(-2, (char *)outFp); /* from now on, error exit must remove */
         errorExit(-3, (char *)fnB);   /* file and rub out its content if any */
         }
      else if (iencr == I_DECR) {         /* decrypting from file A to screen */
         inFp = fopen(fnA, "rb");
         if (inFp == NULL) errorExit(__LINE__, "Can't open %s for reading?\n", fnA);
         strcpy(fnB, "screen");
         putCryptBlock(0, NULL, NULL, nlns);  /* initialize for screen output */
         }
      }
   else if (insitu) {                                  /* reading/writing fnA */
      inFp = fopen(fnA, "rb+");
      if (inFp == NULL) errorExit(__LINE__, "Can't open %s for update?\n", fnA);
      outFp = inFp;
      strcpy(fnB, fnA);
      errorExit(-2, (char *)outFp);    /* from now on, error exit must remove */
      errorExit(-3, (char *)fnB);      /* file and rub out its content if any */
      }
   else {                                 /* reading from fnA, writing to fnB */
      inFp = fopen(fnA, "rb");
      if (inFp == NULL) errorExit(__LINE__, "Can't open %s for reading?\n", fnA);
      outFp = fopen(fnB, "wb");
      if (outFp == NULL) errorExit(__LINE__, "Can't open %s for writing?\n", fnB);
      errorExit(-2, (char *)outFp);    /* from now on, error exit must remove */
      errorExit(-3, (char *)fnB);      /* file and rub out its content if any */
      }

   if (iencr == I_ENCR) {                                       /* encrypting */
      fprintf(stderr, "Encrypting from %s to %s\n", fnA, fnB);
/*    fprintf(stderr, "Must get %d clock random bytes:\n", RAND_BYTES - ixrb);*/
      while (ixrb < RAND_BYTES) getClockByte(prb, &ixrb);/* more random bytes */
/*    for (n = 0; n < RAND_BYTES; n++) fprintf(stderr, "%u.", prb[n]); fprintf(stderr, "\n");*/
      istat = h0_HashBytes(prb, RAND_BYTES, (unsigned char *)hash); /* put initialization vector into feedback register */
      if (istat) errorExit(__LINE__, "Unexpected I.V. hash error?\n");
/*    for (n = 0; n < 8; n++) printf("%02X", ((unsigned char *)hash)[n]); printf("\n");*/
/*    fprintf(stderr, "hashed bytes: %#x %#x %#x %#x\n", hash[0], hash[1], hash[2], hash[3]);*/
      fr[0] = hash[0];                    /* we will eat 8 random bytes now...*/
      fr[1] = hash[1];                          /* ...and leave 8 for dessert */

      if ((incon) && (iecho != NORMAL_ECHO)) {
         fd = openConsole();                  /* input from echoless keyboard */
         if (fd == CONSOLE_UNDEFINED) errorExit(__LINE__, "Error: unable to open console, quitting\n");
         }
      getCryptBlock(incon, fd, iecho, insitu, inFp, NULL);   /* initialize reader */
      k = putCryptBlock(0, outFp, (char *)fr, H0_CRYPT_BLOCK_BYTES); /* write IV */
      if (k < H0_CRYPT_BLOCK_BYTES) errorExit(__LINE__, "Error writing to %s\n", fnB);
      nBytes = 0;
      while (n = getCryptBlock(incon, fd, iecho, insitu, inFp, (char *)cryptBlock)) {
         nBytes += n;
         cryptBlock[0] ^= fr[0]; cryptBlock[1] ^= fr[1];          /* chain... */
         order4Bytes((unsigned char *)cryptBlock, 2);  /* (on BigEndian only) */
         h0_EnCrypt(pad, cryptBlock, cryptBlock);            /* ...encrypt... */
         order4Bytes((unsigned char *)cryptBlock, 2);  /* (on BigEndian only) */
         memcpy(fr, cryptBlock, H0_CRYPT_BLOCK_BYTES);    /* ...save to chain */
         k = putCryptBlock(0, outFp, (char *)cryptBlock, H0_CRYPT_BLOCK_BYTES); /* write */
         if (k < H0_CRYPT_BLOCK_BYTES) errorExit(__LINE__, "Error writing to %s\n", fnB);
         if (n < H0_CRYPT_BLOCK_BYTES) break;       /* must be the last block */
         }
      if (n) {
/*       fprintf(stderr, "padding %d\n", n);*/
         k = putCryptBlock(0, outFp, (char *)(hash + 2), n);
         if (k < n) errorExit(__LINE__, "Error writing to %s\n", fnB);
         }
      if (fd != CONSOLE_UNDEFINED) {
         closeConsole(fd);
         fd = CONSOLE_UNDEFINED;
         }
      }
   else if (iencr == I_DECR) {                                  /* decrypting */
      fprintf(stderr, "Decrypting from %s to %s\n", fnA, fnB);
      getCryptBlock(incon, 0, iecho, insitu, inFp, NULL);   /* initialize reader */
      n = getCryptBlock(0, 0, iecho, insitu, inFp, (char *)fr); /* get initialization vector */
      if (n < H0_CRYPT_BLOCK_BYTES) errorExit(__LINE__, "Error reading from %s\n", fnA);
/*    fprintf(stderr, "feedback register: %#x %#x\n", fr[0], fr[1]);*/

      nxt = nBytes = 0;
      while (n = getCryptBlock(0, 0, iecho, insitu, inFp, (char *)cryptBlock)) {
         if (nxt) {           /* output n bytes of previously decrypted block */
            k = putCryptBlock(outcon, outFp, (char *)prevBlock, n);
            if (k < n) errorExit(__LINE__, "Error writing to %s\n", fnB);
            nBytes += k;
            }
         else nxt = 1;
         if (n < H0_CRYPT_BLOCK_BYTES) break;             /* last short block */
         order4Bytes((unsigned char *)cryptBlock, 2);  /* (on BigEndian only) */
         h0_DeCrypt(pad, cryptBlock, prevBlock);
         order4Bytes((unsigned char *)cryptBlock, 2);  /* (on BigEndian only) */
         order4Bytes((unsigned char *)prevBlock, 2);   /* (on BigEndian only) */
         prevBlock[0] ^= fr[0];
         prevBlock[1] ^= fr[1];
         memcpy(fr, cryptBlock, H0_CRYPT_BLOCK_BYTES);
         }
      if (nxt && (n == 0)) {                   /* no padding was necessary... */
         k = putCryptBlock(outcon, outFp, (char *)prevBlock, H0_CRYPT_BLOCK_BYTES);
         if (k < H0_CRYPT_BLOCK_BYTES) errorExit(__LINE__, "Error writing to %s\n", fnB);
         nBytes += k;
         }
      }

/* fprintf(stderr, "processing done, closing files.\n"); */

   if (inFp) fclose(inFp);
   if ((outFp) && (!insitu)) fclose(outFp);
   if ((*fnB) && (nBytes == 0)) remove(fnB);

   memset(prevBlock, '\0', H0_CRYPT_BLOCK_BYTES);
   memset(cryptBlock, '\0', H0_CRYPT_BLOCK_BYTES);
   memset(consoleBuffer, '\0', CON_BUF_LENGTH);

   fprintf(stderr, "%s done, %lu characters/bytes", progfullname, (long)nBytes);
   if (iencr == I_ENCR) fprintf(stderr, " encrypted\n");
   else if (iencr == I_DECR) fprintf(stderr, " decrypted\n");

   return(0);
   }
/* ========================================================================== */
static void usage(char *progname, char *msg) {
   if (msg) fprintf (stderr, "Error: %s\n", msg);
   fprintf (stderr, "Usage summary: %s [options] file1.abc [file2.xyz] [options]\n", progname);
   fprintf (stderr, " file1.abc: name of first (usually input) file.\n");
   fprintf (stderr, " file2.xyz: optional, name of second (usually output) file.\n");
   fprintf (stderr, "Options:\n");
/* fprintf (stderr, " -k=\"key\" use key, don't prompt for one.\n");*/
/* fprintf (stderr, " -p=\"pass phrase\" use p.p., don't prompt for one.\n");*/
   fprintf (stderr, " -c  clear echo.\n");
   fprintf (stderr, " -d  to decrypt and write to a new file.\n");
   fprintf (stderr, " -ds to decrypt and write to the screen.\n");
   fprintf (stderr, " -e  to encrypt and write to a new file.\n");
   fprintf (stderr, " -eo to encrypt and overlay same file.\n");
   fprintf (stderr, " -ek to encrypt keyboard input.\n");
   fprintf (stderr, " -f  to pause for data floppy disk.\n");
   fprintf (stderr, " -h  to print this usage help and exit.\n");
   fprintf (stderr, " -l=nn to change screen output line count.\n");
   exit(1);
   }
/* ========================================================================== */
static int clineOption(int argc, char **argv, char **optval) {
   static int next_cls = 1;              /* sigle line use (once per program) */
   static char nullchar = '\0';      /* so invoker gets null-string, not NULL */
/* -------------------------------------------------------------------------- */
   int ifl, ivl;
   char *pa;
   ifl = ivl = 0;
   if (optval) *optval = &nullchar;
   while (next_cls < argc) {
      pa = argv[next_cls++];
      if (*pa == '-') {                  /* Burp now requires Unix style flag */
         ifl = *(pa + 1);
         if (ifl) ivl = *(pa + 2);
         if (ivl == '=') {                              /* style is /f=xyz... */
            ivl = *(pa + 3);
            if (optval && ivl) *optval = pa + 3;
            }
         else {                                          /* style is /fxyz... */
            if (optval && ivl) *optval = pa + 2;
            }
         return(ifl);
         }
      }
   return(-1);
   }
/* ========================================================================== */
/* return the pointer of the next non-flag command line string  */
static char *clineFileName(int argc, char **argv) {
   static int next_cls = 1;      /* sigle line use (once per program) */
   char *fnm = NULL;
/* -------------------------------------------------------------------------- */
   while (next_cls < argc) {
      fnm = argv[next_cls];
      next_cls++;
      if (*fnm == '-') continue;
      return(fnm);
      }
   return(NULL);
   }
/* ========================================================================== */
static int  stripQuotes(char *s) {
   int i, l;
/* -------------------------------------------------------------------------- */
   l = strlen(s);
   if ((l < 2) || (*s != '"') || (s[l - 1] != '"')) return(l);
   s[l - 1] = '\0';
   for (i = 0; s[i]; i++) s[i] = s[i+1];
   return(l - 2);
   }
/* ========================================================================== */
static void errorExit(int ln, char *fmt, ...) {
   static cryptWord32 *padRub;
   static FILE *fpRub;
   static char fnRub[FILENAME_MAX + 2];
   fileSizeInt fo;
   va_list p_arg;
/* -------------------------------------------------------------------------- */
   if (fd != CONSOLE_UNDEFINED) {
      closeConsole(fd);
      fd = CONSOLE_UNDEFINED;
      }
   if (ln < 0) {
      if (ln == -1) padRub = (cryptWord32 *)fmt;
      else if (ln == -2) fpRub = (FILE *)fmt;
      else if (ln == -3) strcpy(fnRub, fmt);
      return;
      }
   va_start(p_arg, fmt);
   fprintf(stderr, "%s(%d) error: ", progname, ln);
   vfprintf(stderr, fmt, p_arg);
   va_end(p_arg);

   memset(consoleBuffer, '\0', CON_BUF_LENGTH);
   if (padRub) {
      memset(padRub, '\0', H0_CRYPT_PAD_LENGTH);
/*    fprintf(stderr, "pad obliterated\n");*/
      }
   if (fpRub) {
      fo = ftell(fpRub);
      fclose(fpRub);
/*    fprintf(stderr, "file with %d bytes of hot junk closed\n", fo);*/
      }
   else fo = 0;
   if (*fnRub) {
      ruboutFile(fnRub, fo);
      }
   exit(1);
   }
/* ========================================================================== */
/* There's very little entropy in this. But it is concatenated with a few more
   random words (most notably the timer), crypto-hashed, and the purpose of it
   is only to make IV and cryptotext padding bytes not (readily?) recognizable
   as something produced by this program... */
static void getClockByte(unsigned char *pa, int *ixrb) {
   static long i0, ix;
   long        i, ic;
/* -------------------------------------------------------------------------- */
   if (pa == NULL) {
      i0 = ix = clock();
      return;
      }
   if (*ixrb >= RAND_BYTES) return;
   for (i = 0; i < 100000; i++) {    /* just in case clock return is constant */
      if (clock() == ix) continue;
      ic = clock();
      pa[*ixrb] = (unsigned char)(ic - i0);
      *ixrb += 1;
      ix = ic;
      return;
      }
   ic = time(NULL);
   pa[*ixrb] = (unsigned char)ic;
   *ixrb += 1;
   }
/* ========================================================================== */
static void ruboutFile(char *fn,                /* file is closed, but has... */
                       fileSizeInt fo) {     /* ...fo bytes of hot junk in it */
   fileSizeInt n;
   unsigned int l;
   unsigned short m;
   static FILE *fpRub;
   if (fo) {
/*    fprintf(stderr, "Erasing %d characters of incomplete output in file %s\n", fn);*/
      if ((fpRub = fopen(fn, "wb")) == NULL) {
         fprintf(stderr, "Warning: Unable to rub out incomplete output file %s\n", fn);
         remove(fn);
         return;
         }
      n = 0;                                     /* first pass: write all 1's */
      m = 0xffff;
      while (n < fo) {
         l = fwrite(&m, sizeof(short), 1, fpRub);
         if (l) n += l;
         else n = fo;
         }
      fclose(fpRub);
/*    fprintf(stderr, "wrote %d bytes of 1's\n", fo);*/
      if ((fpRub = fopen(fn, "wb")) == NULL) {
         fprintf(stderr, "Warning: Unable to rub out incomplete output file %s\n", fn);
         remove(fn);
         return;
         }
      n = 0;                         /* second pass: write pseudo-random junk */
      srand(time(0));
      while (n < fo) {
         m = (unsigned short)rand();
         l = fwrite(&m, sizeof(short), 1, fpRub);
         if (l) n += l;
         else n = fo;
         }
      fclose(fpRub);
/*    fprintf(stderr, "wrote %d bytes of random bytes\n", fo);*/
      if ((fpRub = fopen(fn, "wb")) == NULL) {
         fprintf(stderr, "Warning: Unable to rub out incomplete output file %s\n", fn);
         remove(fn);
         return;
         }
      n = 0;                                     /* third pass: write all 0's */
      m = 0;
      while (n < fo) {
         l = fwrite(&m, sizeof(short), 1, fpRub);
         if (l) n += l;
         else n = fo;
         }
/*    fprintf(stderr, "wrote %d bytes of 0's\n", fo);*/
      fclose(fpRub);    /* under W95/NT this still leaves the stuff in cache! */
      }
   remove(fn);               /* and our overwrite might be quitely discarded! */
   return;
   }
/* ========================================================================== */
/* Returns number of bytes placed into the invoker's buffer...                */
static int getCryptBlock(int incon,                         /* from keyboard? */
                   int fd,            /* console file descriptor, if required */
                   int iecho,                    /* if above, how do we echo? */
                   int insitu,                          /* update input file? */
                   FILE *inFp,                   /* file, if reading from one */
                   char *buff) {        /* returned input data, NULL to init. */
   int  i, n;
   char typedLine[CON_BUF_LENGTH + 4];                /* always room for \n\0 */
   fileSizeInt fa;
   static int ncb;                       /* number of bytes in console buffer */
   static int conInputEnd;
   static cryptWord32 nextBlock[H0_CRYPT_BLOCK_LENGTH];
   static fileSizeInt nextBlockBytes;
   static fileSizeInt nextReadAddr;
/* -------------------------------------------------------------------------- */
   if (buff == NULL) {                               /* initialize the reader */
      if (incon) {                             /* signal empty console buffer */
         conInputEnd = 0;
         ncb = 0;
         fprintf(stderr, "Enter plaintext. (Empty line ends input)\n");
         }
      else {                        /* make first file block "delivery ready" */
         memset(nextBlock, '\0', H0_CRYPT_BLOCK_BYTES);
         nextBlockBytes = fread(nextBlock, 1, H0_CRYPT_BLOCK_BYTES, inFp);
         if (insitu) {
            nextReadAddr = nextBlockBytes;
            if (nextBlockBytes) fseek(inFp, 0, SEEK_SET);
            }
         }
      return(0);
      }

   if (incon) {                                   /* reading from the console */
      while ((conInputEnd == 0) && (ncb < H0_CRYPT_BLOCK_BYTES)) {
/*       conInputEnd = getString(typedLine, &n, CON_BUF_LENGTH, iecho, 0); */
         if (iecho == NORMAL_ECHO)  n = getLine(typedLine, CON_BUF_LENGTH);
         else n = getNoEchoLine(fd, typedLine, CON_BUF_LENGTH, iecho);
         if (n == CONSOLE_READ_ERROR) {
            memset(typedLine, '\0', CON_BUF_LENGTH);
            errorExit(__LINE__, "Error reading console, quitting\n");
            }
         if (n < 1) conInputEnd = 1;
         else memcpy(consoleBuffer + ncb, typedLine, n);
         memset(typedLine, '\0', CON_BUF_LENGTH);
         if (n) {
            ncb += n;
            consoleBuffer[ncb++] = '\n';
            }
         if (conInputEnd) break;
         }
      memset(buff, '\0', H0_CRYPT_BLOCK_BYTES);
      if (ncb < 1) return(0);
      n = myMin(ncb, H0_CRYPT_BLOCK_BYTES);
      memcpy(buff, consoleBuffer, n);
      for (i = 0; i + n < ncb; i++) consoleBuffer[i] = consoleBuffer[i + n];
      ncb -= n;
      return(n);
      }
   else {
      fa = 0;
      n = nextBlockBytes;
      if (n == 0) return(0);
      if (nextBlockBytes < H0_CRYPT_BLOCK_BYTES) memset(buff, '\0', H0_CRYPT_BLOCK_BYTES);
      memcpy(buff, nextBlock, nextBlockBytes);
      if (insitu) {
         fa = ftell(inFp);        /* we want to leave it positioned for write */
         fseek(inFp, nextReadAddr, SEEK_SET);            /* position for read */
         }
      nextBlockBytes = fread(nextBlock, 1, H0_CRYPT_BLOCK_BYTES, inFp); /* get next */
      if (insitu) {
         nextReadAddr += nextBlockBytes;
         if (nextBlockBytes) fseek(inFp, fa, SEEK_SET);  /* leave position as it was before the read */
         }
/*    fprintf(stderr, " in:0x%08x 0x%08x %d\n", *(cryptWord32 *)(buff), *(cryptWord32 *)(buff + 4), n);*/
      return(n);
      }
   }
/* ========================================================================== */
static int putCryptBlock(int outcon,                    /* decrypt to screen? */
                   FILE *outFp,                    /* file, if writing to one */
                   char *buff,                         /* given data to write */
                   int n) {                                 /* how many bytes */
   int        m;
   static int lMax, lNbr;
/* -------------------------------------------------------------------------- */
   if (buff == NULL) {                           /* initialize the line count */
      lMax = n;                    /* max lines that can be written to screen */
      lNbr = 0;
      return(0);
      }
/* fprintf (stderr, "writing %d bytes\n", n);*/
   if (outcon) {                  /* writing to the screen, "DOS" conventions */
      for (m = 0; m < n; m++) {
         if (buff[m] == '\n') fputc('\r', stderr);
         if (fputc(buff[m], stderr) == EOF) return(0);      /* can't write to screen? */
         if (buff[m] == '\n') {                                /* new line... */
            lNbr++;
            if ((lNbr + 1) == lMax) {
               lNbr = 0;
               promptWait("-- More --\r");
               fputs("          \r", stderr);
               }
            }
         }
      }
   else {
      m = fwrite(buff, 1, n, outFp);                   /* writing to the file */
/*    fprintf(stderr, "out:0x%08x 0x%08x %d\n", *(cryptWord32 *)(buff), *(cryptWord32 *)(buff + 4), m);*/
      }
   return(m);
   }
/* ========================================================================== */
/* case-insensitive string comparison, used to compare file names. */
static int fileNameCompare(const char *strA, const char *strB) {
   int ia, ib;
   do {
      if (((ia = (unsigned char)(*(strA++))) >= 'A') && (ia <= 'Z')) ia -= ('A' - 'a');
      if (((ib = (unsigned char)(*(strB++))) >= 'A') && (ib <= 'Z')) ib -= ('A' - 'a');
      } while (ia && (ia == ib));
   return(ia - ib);
   }
/* ========================================================================== */
#define ALARM    7
#define BS       8
#define LF      10
#define CR      13
#define ESC     27
#define SP      32
#define DEL    127
/* ordinary stdin line input - normal echo or platform with no echo-less con. */
static int getLine(char *strbuf,                 /* returned string + 2 bytes */
                   int maxlen) {   /* max chars requested, buffer is one more */
   int l;
/* -------------------------------------------------------------------------- */
   *strbuf = '\0';
   if (fgets(strbuf, maxlen + 2, stdin) == NULL) return(0);
   l = (strlen(strbuf));
   if ((l > 0) && ((strbuf[l-1] == CR) || (strbuf[l-1] == LF))) strbuf[--l] = '\0';
   return(l);
   }
/* ========================================================================== */
#ifdef POSIX_CONSOLE_PTIN     /* non-echo console line entry in POSIX/termios */
/* ========================================================================== */
static void promptWait(char *prompt) {         /* no console needs to be open */
   fprintf(stderr, prompt);
   getchar();
   }
/* ========================================================================== */
static int openConsole() {
   int fd;
/* -------------------------------------------------------------------------- */
   fd = open("/dev/tty", O_RDWR);
   if (fd == -1) fd = fileno(stdin);
/* printf("Console fd %d (%d)\n", fd, fileno(stdin)); */
   if (fd == -1) return(fd);
   return(fd);
   }
/* ========================================================================== */
static void closeConsole(int fd) {
   if (fd != fileno(stdin)) close(fd);
   }
/* ========================================================================== */
/* rub-out last char. in the buffer and, if echoed, remove it from the screen */
static int rubout(int fd, int echo, char *strbuf, int i) {
   char es, bs;
/* -------------------------------------------------------------------------- */
   if (i < 1) {
      putc(ALARM, stderr);
      return(0);
      }
   strbuf[--i] = '\0';
   if (echo) {
      es = ' ';                                          /* space rubout char */
      bs = BS;                                       /* backspace rubout char */
      write(fd, &bs, 1);
      write(fd, &es, 1);
      write(fd, &bs, 1);
      }
   return(i);
   }
/* ========================================================================== */
/* returns number of characters entered before [return], -1 for error...      */
static int getNoEchoLine(int fd,                   /* console file descriptor */
                         char *strbuf,                     /* returned string */
                         int maxlen,          /* maximum characters requested */
                         int echo) {                      /* 0:none n:echo'n' */
   int i, n;
   char c, ec, es, nc;
   struct termios oldFlags, newFlags;
/* -------------------------------------------------------------------------- */
   tcgetattr(fd, &oldFlags);
   newFlags = oldFlags;
   newFlags.c_lflag &= ~(ECHO | ICANON);
   newFlags.c_lflag |= ECHONL;
   newFlags.c_cc[VTIME] = 0;
   newFlags.c_cc[VMIN] = 1;
   if (tcsetattr(fd, TCSAFLUSH, &newFlags)) return(-1);
   tcgetattr(fd, &newFlags);
   if (newFlags.c_lflag & ECHO) {                     /* did we supress echo? */
      tcsetattr(fd, TCSANOW, &oldFlags);                      /* restore mode */
      return(-2);                                               /* and return */
      }
   ec = (char)echo;                                      /* masking echo char */
   es = ' ';                                               /* space echo char */
   nc = '\n';
   i = 0;                                               /* input buffer index */
   while (i < maxlen) {         /* N.B.: buffer must be maxlen + 1 (for \'0') */
      n = read(fd, &c, 1);
/*    fprintf(stderr, "%d[%d]\n", i, c); */
      if ((c == CR) || (c == LF)) break;                         /* line done */
      if ((c < ' ') || (c > '~')) {
         if ((c == BS) || (c == DEL)) {                 /* backspace one char */
            i = rubout(fd, echo, strbuf, i);
            }
         if (c == ESC) {                              /* clear input, restart */
            while (i) i = rubout(fd, echo, strbuf, i);
            tcflush(fd, TCIFLUSH);                  /* kill control sequences */
            }
         continue;
         }
      strbuf[i++] = c;                              /* we have next character */
      if (echo) {                                   /* echo masking character */
         if (c == SP) write(fd, &es, 1); /* but keep blanks for "orientation" */
         else write(fd, &ec, 1);
         }
      }
   strbuf[i] = '\0';                                      /* terminate string */
   write(fd, &nc, 1);                           /* write new-line in any case */
   tcflush(fd, TCIFLUSH);                                     /* just in case */
   tcsetattr(fd, TCSANOW, &oldFlags);                         /* restore mode */
   return(i);                                                   /* and return */
   }

/* ========================================================================== */
#elif defined WDOS_CONSOLE_PTIN    /* non-echo concole line entry DOS/Windows */
/* ========================================================================== */
static void promptWait(char *prompt) {
   while (kbhit()) getch();                          /* flush keyboard buffer */
   fprintf(stderr, prompt);
   getch();
   }
/* ========================================================================== */
/* rub-out last char. in the buffer and, if echoed, remove it from the screen */
static int rubout(int echo, char *strbuf, int i) {
   if (i < 1) {
      putc(ALARM, stderr);
      return(0);
      }
   strbuf[--i] = '\0';
   if (echo) {
      putch(BS);
      putch(SP);
      putch(BS);
      }
   return(i);
   }
/* ========================================================================== */
static int getNoEchoLine(int fd,                   /* console file descriptor */
                         char *strbuf,                     /* returned string */
                         int maxlen,          /* maximum characters requested */
                         int echo) {                      /* 0:none n:echo'n' */
   int i, c;
/* -------------------------------------------------------------------------- */
   fd = fd;                                                         /* unwarn */
   i = 0;                                               /* input buffer index */
   while (i < maxlen) {         /* N.B.: buffer must be maxlen + 1 (for \'0') */
      c = getch();
      if (c == EOF) return(-1);
/*    fprintf(stderr, "%d[%d]\n", i, c); */
      if ((c == CR) || (c == LF)) break;                         /* line done */
      if ((c < ' ') || (c > '~')) {
         if ((c == BS) || (c == DEL)) {                 /* backspace one char */
            i = rubout(echo, strbuf, i);
            }
         if (c == ESC) {                              /* clear input, restart */
            while (i) i = rubout(echo, strbuf, i);
            }
         continue;
         }
      strbuf[i++] = (char)c;                        /* we have next character */
      if (echo) {                                   /* echo masking character */
         if (c == SP) putch(SP);         /* but keep blanks for "orientation" */
         else putch(echo);
         }
      }
   strbuf[i] = '\0';                                      /* terminate string */
   putch(LF);                                               /* write new-line */
   return(i);                                                   /* and return */
   }
/* ========================================================================== */
#else                                /* platforms with no 'echo-less' console */
/* ========================================================================== */
static void promptWait(char *prompt) {
   fprintf(stderr, prompt);
   getchar();
   }
/* ========================================================================== */
#endif
/* ========================================================================== */
/* include crypto functions: */
#include "h0crpt.c"
#include "h0crpu.c"
#include "h0crpv.c"
#include "h0hash.c"
/* ========================================================================== */
