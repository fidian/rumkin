/* stricmp.c: case-insensitive string comparison variant of strcmp() */
int stricmp(const char *strA, const char *strB) {
   int ia, ib;
   do {
      if (((ia = (unsigned char)(*(strA++))) >= 'A') && (ia <= 'Z')) ia -= ('A' - 'a');
      if (((ib = (unsigned char)(*(strB++))) >= 'A') && (ib <= 'Z')) ib -= ('A' - 'a');
      } while (ia && (ia == ib));
   return(ia - ib);
   }
