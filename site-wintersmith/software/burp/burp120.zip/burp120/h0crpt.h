/* H0CRPT.H : Blowfish and MD5-hash header. This Blowfish implementation is
   based on code published in Dr. Dobb's, September 1995. The only change of
   any significance is that the pad space is allocated by the invoker, in
   order to make the functions re-entrant. It assumes unsigned char of 8 bits,
   unsigned int of 32 bits, and little endian (Intel) byte order. Byte order
   modifications are required only if the encrypted (binary) data is moved
   between environments with different endian order. The MD5 hash function
   is based on public-domain code distributed with PGP.

   Programmer: Hrvoje Lukatela, 1998. This code is in the public domain;
   there are no restrictions on its use or distribution, and no guarantees,
   either explicit or implied.

   For updates, consult: http://www.geodyssey.com/cryptography.html
 */

#ifndef H0CRPT_INCLUDED
#define H0CRPT_INCLUDED

/* Following defines and prototypes represent the application interface.      */
/* (They may be defined in an appropriate application header file).           */
#ifndef H0_CRYPT_API
#define H0_CRYPT_API                          /* To signal API is now defined */
#define H0_CRYPT_MAX_KEY_LENGTH    56                  /* unsigned characters */
#define H0_CRYPT_PAD_LENGTH      1042                    /* unsigned integers */
#define H0_CRYPT_BLOCK_LENGTH       2                    /* unsigned integers */

#ifndef H0_W32_BYTE_ORDER_DEFINED
#define H0_W32_BYTE_ORDER_3210                    /* little endian is default */
#define H0_W32_BYTE_ORDER_DEFINED
#endif

#ifndef H0_CRYPTWORD32_DEFINED
typedef unsigned int cryptWord32;               /* 32-bit compiler is default */
#define H0_CRYPTWORD32_DEFINED
#endif

int  h0_CryptInitPad(cryptWord32 *, const unsigned char *, int);
int  h0_CryptTestPad(const cryptWord32 *);
void h0_EnCrypt(const cryptWord32 *, const cryptWord32 *, cryptWord32 *);
void h0_DeCrypt(const cryptWord32 *, const cryptWord32 *, cryptWord32 *);
int  h0_HashBytes(const unsigned char *, int, unsigned char *);
#endif

/* Internal defines, used by the code in h0crpt.c, h0crpu.c, h0crpv.c and     */
/* h0hash.c.  By convention, Blowfish assumes little endian byte order.       */

#if defined   H0_W32_BYTE_ORDER_3210            /* Little endian (e.g. Intel) */
union wordChars {
   cryptWord32 w;
   struct {
      unsigned char c3;
      unsigned char c2;
      unsigned char c1;
      unsigned char c0;
      } c;
   };
#elif defined H0_W32_BYTE_ORDER_0123            /* Big endian (e.g. Motorola) */
union wordChars {
   cryptWord32 w;
   struct {
      unsigned char c0;
      unsigned char c1;
      unsigned char c2;
      unsigned char c3;
      } c;
   };
#else
#error "H0CRPT.H: undefined endian (byte order)"
#endif

#define P_LNGTH        18
#define S_LNGTH       256

#define P_OFFST       (0)
#define S0_OFFST      (P_LNGTH)
#define S1_OFFST      (P_LNGTH + S_LNGTH)
#define S2_OFFST      (P_LNGTH + S_LNGTH + S_LNGTH)
#define S3_OFFST      (P_LNGTH + S_LNGTH + S_LNGTH + S_LNGTH)
#define T_LNGTH       (P_LNGTH + S_LNGTH + S_LNGTH + S_LNGTH + S_LNGTH)

#define FR(p, n, l, r) l ^= (p + P_OFFST)[n]; \
                    r ^= (((p + S0_OFFST)[l >> 24] \
                         + (p + S1_OFFST)[(l >> 16) & 0x00ff]) \
                         ^ (p + S2_OFFST)[(l >> 8) & 0x00ff]) \
                         + (p + S3_OFFST)[l & 0x00ff]

#endif
