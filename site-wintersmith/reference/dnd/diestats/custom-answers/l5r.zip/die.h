int roll(int sides);
