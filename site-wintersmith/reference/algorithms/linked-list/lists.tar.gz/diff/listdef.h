typedef struct node {
   struct node *diff;
   
   int data;
} node;
