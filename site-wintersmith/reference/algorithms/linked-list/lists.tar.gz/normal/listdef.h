typedef struct node {
   struct node *prev;
   struct node *next;
   
   int data;
} node;
