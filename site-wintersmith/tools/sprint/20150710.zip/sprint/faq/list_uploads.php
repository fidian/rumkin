<?php
/* Sprint File Uploader
 * 
 * Copyright (C) 2003-2007 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for legal information
 * See http://rumkin.com/tools/sprint/ for more information about these tools
 */

?>

<p>I do not provide a way for people to view what others have uploaded
recently.  This is to help keep my site kid-friendly.  People upload
naughty pictures and things to my site and I don't have any way to filter
out that content from minors.  To prevent that stuff from slipping out
too much, I do not have a gallery of recent uploads.</p>

<p>Of course, people post requests and recent uploads in the shoutbox
at the bottom of the page.  There's not much I can do about that besides
blocking that on my entire site, but I get lots of good feedback from
there, so I won't be doing that lightheartedly.</p>