mysqldump sprint Category
mysqldump -d sprint File
mysqldump -d sprint FileDesc
mysqldump -d sprint FileCategory
mysqldump -d sprint FileThumb
mysqldump -d sprint Phones