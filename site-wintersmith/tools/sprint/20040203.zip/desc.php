<?PHP
/* Sprint File Uploader
 *
 * Copyright (C) 2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for legal information
 * See http://rumkin.com/tools/sprint/ for more information about these tools
 */

include('utils.inc');
DumpDescriptionFile();
