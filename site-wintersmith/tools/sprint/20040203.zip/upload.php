<?PHP
/* Sprint File Uploader
 *
 * Copyright (C) 2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for legal information
 * See http://rumkin.com/tools/sprint/ for more information about these tools
 */

include '../../functions.inc';
include 'phones.inc';

StandardHeader(array('title' => 'Sprint PCS Vision File Uploader',
		     'topic' => 'sprint',
		     'page' => 'sprint'));

?>
<p>This file uploader will let you upload various files to your Sprint PCS
phone.  You can only upload the following types of files -- if you try
something else, your phone will not let you download the file.  
Experiencing problems?  Have suggestions?
Email me -- link at the bottom of the page.</p>

<ul>
<li><b>Images:</b> <a href="#jpg">jpg</a>, <a href="#jpg">jpeg</a>, 
<a href="#png">png</a>, <a href="#wbmp">wbmp</a>, <a href="#pmd">pmd</a>,
<a href="#cmx">cmx</a></li>
<li><b>Sounds:</b> <a href="#mid">mid</a>, <a href="#mid">midi</a>, 
<a href="#qcp">qcp</a></li>
<li><b>Midlets:</b> <a href="#jar">jar</a>, <a href="#jad">jad</a></li>
</ul>

<p>For the Phone Number, either enter your phone number, or enter an email
address.  If you use anything except the Samsung N400, you can just use
your phone number.  Otherwise, use your <i>username</i>@sprintpcs.com 
email address.</p>


<h2>Upload Images, Sounds, Etc.</h2>

<form method=post action="upload2.php" enctype="multipart/form-data">
<input type=hidden name=MAX_FILE_SIZE value=500000>
<table align=center border=1 cellpading=5 cellspacing=0>
<tr>
  <th>Phone Number</td>
  <td><input type=text name="sendto"></td>
</tr>
<tr>
  <th>Description</th>
  <td><input type=text name="desc"> &lt;-- The file will be called this</td>
</tr>
<tr>
  <th>Filename</th>
  <td><input type=file name="fn" size=50></td>
</tr>
<tr>
  <td colspan=2 align=center><input type=submit value="Upload File"></td>
</tr>
</table>
</form>

<h2>Upload Java Midlets</h2>

<form method=post action="upload2.php" enctype="multipart/form-data">
<input type=hidden name=MAX_FILE_SIZE value=500000>
<table align=center border=1 cellpading=5 cellspacing=0>
<tr>
  <th>Phone Number</td>
  <td><input type=text name="sendto"></td>
</tr>
<tr>
  <th>Description</th>
  <td><input type=text name="desc"> &lt;-- Only used in the notification</td>
</tr>
<tr>
  <th>JAD File</th>
  <td><input type=file name="jad" size=50></td>
</tr>
<tr>
  <th>JAR File</th>
  <td><input type=file name="jar" size=50></td>
</tr>
<tr>
  <th>Folder</th>
  <td><select name="fldr">
    <option value="default">Default Folder
    <option value="Applications">Applications
    <option value="Games">Games
    <option value="Others">Others
    <option value="userdef">Other (specify) --&gt;
    </select> <input type=text name=userdeffldr>
  </td>
<tr>
  <td colspan=2 align=center><input type=submit value="Upload Midlet"></td>
</tr>
</table>
</form>



<h2>Phones that Work with This</h2>

<p>These phones will work with this upload facility.</p>

<ul>
<?PHP

   $Models = array();
   foreach ($Phones as $k => $v)
   {
      $Models[] = $v['Model'];
   }
   sort($Models);
   foreach ($Models as $v)
   {
      echo '<li>' . htmlspecialchars($v) . "</li>\n";
   }
?>
</ul>

<h2>More Information on File Formats</h2>

<p><a name="jpg"><b>jpg, jpeg:</b></a>  Images that are usually
photographs.  Great format.  Life is good.  Best compression comes from 
photo-realistic images, but too much compression will produce visible 
distortions (artifacts).</p>

<p><a name="png"><b>png:</b></a>  Designed to replace "gif" due to
some big corporation (Unisys) being, um, irritating about a software 
patent.  A good file format to pick for your phone or your web site.</p>

<p><a name="wbmp"><b>wbmp:</b></a>  Wireless BMP files -- not the same as a
Windows BMP file.  A Windows BMP file can be converted into a wbmp file with
WapTiger's <a href="http://www.waptiger.de/download/">bmp2wbmp</a> utility,
or you can use their <a href="http://www.waptiger.de/bmp2wbmp">online
form</a>.</p>

<p><a name="pmd"><b>pmd:</b></a>  These are animations.  To create them, you
need either KTPIC or auAM.  More information on these formats is available
on the web.</p>

<p><a name="cmx"><b>cmx:</b></a>  These are screen savers that may work on some
phones.  There are several "cmx" extensions out there -- the one you want is
the Qualcomm CMS (Compact Media Extensions) format (<a
href="http://www.cdmatech.com/solutions/products/cmx.html">info</a>).</p>

<p><a name="mid"><b>mid, midi:</b></a>  Sound files, usually synthesized
instruments.  Great for the small size and the awesome use of polyphonic 
speakers.  <a href="http://www.anvilstudio.com/">AnvilStudio</a> is free and
will let you edit midi files.</p>

<p><a name="qcp"><b>qcp:</b></a>  Highly compressed audio.  You can compress any
sound instead of having just specific instruments.  The format is made by
Qualcomm PureVoice (<a
href="http://www.cdmatech.com/solutions/products/purevoice.jsp">info</a>)
and you can convert wav files into qcp format with their <a
href="http://www.cdmatech.com/solutions/products/purevoice_download.html">converter</a>.</p>

<p><a name="jar"><b>jar:</b></a>  Java Midlet program.  This is the compiled
Java program.</p>

<p><a name="jad"><b>jad:</b></a>  Java Midlet descriptor.  This gives
information about the Java program, such as which category the program
should go into.</p>

<h2>Privacy Information</h2>

<p>I do not collect phone numbers and email addresses submitted with this
program.  However, that information does go into my mailserver's logs.  I
never go into there unless there is a problem with my server.  Additionally,
your information will never be given to anyone without a warrant or other
ways of forcing me to give up that information.  However, if you feel that
there is still a security risk, you can email me or just use another
<a href="http://www.sprintusers.com/focus/">tool</a>.</p>

<?PHP

StandardFooter();