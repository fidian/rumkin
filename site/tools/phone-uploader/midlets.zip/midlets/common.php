<?php

include("unzip.php");

function getScriptName() {
    $parts = explode("/", $_SERVER["SCRIPT_NAME"]);
    return $parts[count($parts) - 1];
}

function getProtocol() {
    return $_SERVER['SERVER_PORT'] === 443 ? "https" : "http";
}

function getJarUrl() {
    $protocol = getProtocol();
    $host = $_SERVER['HTTP_HOST'];
    $jarUrl = str_replace(getScriptName() . "/", "jar.php/", $_SERVER['PHP_SELF']);
    $jarUrl = str_replace(".jad", ".jar", $jarUrl);

    return "$protocol://$host$jarUrl";
}

function getJarFile() {
    $parts = explode(getScriptName() . "/", $_SERVER['PHP_SELF']);
    $jad = $parts[count($parts) - 1];
    $jar = str_replace(".jad", ".jar", $jad);

    return $jar;
}

function getJarFileDescriptor() {
    $jarFile = getJarFile();
    $data = unzip($jarFile, "META-INF/MANIFEST.mf", true);
    $data = str_replace("\r\n", "\n", $data);
    $data = str_replace("\r", "\n", $data);
    $data = str_replace("\n ", "", $data);  // 72-character "continuation line"
    $lines = explode("\n", "$data");
    $didIcon = false;
    $didName = false;
    $altIcon = false;
    $altName = false;
    $final = array();
    array_push($final, "MIDlet-Jar-URL: " . getJarUrl());
    array_push($final, "MIDlet-Jar-Size: " . filesize(getJarFile()));

    foreach ($lines as $line) {
        if (strtolower(substr($line, 0, 7)) === 'midlet-') {
            // Parse MIDlet-1 but also make sure to output that line
            if (strtolower(substr($line, 0, 9)) === "midlet-1:") {
                $x = explode(",", $line);
                $altName = trim($x[0]);
                if (stristr($x[1], ".png")) {
                    $altIcon = trim($x[1]);
                }
            }

            // Convoluted way of saying "skip jar-size, jar-url"
            if (stristr($line, "midlet-jar-size:") === false && stristr($line, "midlet-jar-url:") === false) {
                array_push($final, $line);

                /* Spit out the icon and name fields if we find them, but also record that we wrote them. */
                if (stristr($line, "midlet-icon:") !== false) {
                    $didIcon = true;
                }

                if (stristr($line, "midlet-name:") !== false) {
                    $didName = true;
                }
            }
        }
    }

    if ($didName === false && $altName) {
        array_push($final, "MIDlet-Name: $altName");
    }

    if ($didIcon === false && $altIcon) {
        array_push($final, "MIDlet-Icon: $altIcon");
    }

    return implode("\n", $final);
}

function cleansePhone($phone) {
    return preg_replace('[^0-9]', '', $phone);
}

function isValidPhone($phone) {
    $phone = cleansePhone($phone);

    return preg_match('/^[2-9][0-9][0-9][2-9][0-9]{6}$/', $phone) !== false;
}

function sendEmail($address, $subject, $body) {
    // If you are setting the From address, configure these variables.
    /*
    $emailFrom = 'fidian@rumkin.com';
    $emailFromFull = '"Tyler Akins" <$emailFrom>';
     */

    $headers = array(
        'Date: ' . date('r'),
        'Return-Path: ' . $emailFromFull,
        'Message-Id: <' . date('YmdHis') . '.' . uniqid() . '@' . $_SERVER['HTTP_HOST'] . '>',
        // Setting the "From" address causes problems
        // 'From: ' . $emailFromFull,
        'X-IP-Address-for-web-form: ' . $_SERVER['REMOTE_ADDR'],
        'X-URL: ' . getProtocol() . '://' . $_SERVER['HTTP_HOST'] . $_SERVER['SCRIPT_NAME']
    );
    $headers = implode("\r\n", $headers);

    // If you do set the From address, you'll potentially need code like this.
    /*
    if (strtoupper(substr(PHP_OS, 0, 3)) === 'WIN') {
        // Windows uses an INI setting
        ini_set('sendmail_from', $emailFrom);
        mail($address, $subject, $body, $headers);
        ini_restore('sendmail_from');
    } else {
        // Linux/Unix uses sendmail arguments
        mail($address, $subject, $body, $headers); //, "-f '$emailFrom'");
    }
     */

    // If you are not setting the From address, this will work fine.
    mail($address, $subject, $body, $headers);
}
