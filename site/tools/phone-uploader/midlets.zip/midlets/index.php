<html><head><title>Download Java MIDlets</title></head><body>

<?php

include('common.php');

$files = array();
$files['Samsung-M800-EX'] = 'Pocket Express 1.2.26 for Samsung M800';
$files['mgmaps'] = 'MGMaps - Mapping app';
$files['mgmaps-sprint'] = 'MGMaps - Mapping app for Sprint GPS';

function err($msg) {
    echo "<p><b style=\"color: red\">" . $msg . "</b></p>";
}

function ok($msg) {
    echo "<p><b style=\"color: green\">" . $msg . "</b></p>";
}

function sendFile($fn, $phone) {
    if (!$phone) {
        err("You must specify a phone number");
        return;
    }

    if (!isValidPhone($phone)) {
        err("Invalid phone number. Please include all 10 digits. US phone numbers only.");
        return;
    }

    if (!$files[$fn]) {
        err("Invalid file.");
    }

    $phone = cleansePhone($phone);
    $url = getJarUrl();
    $url = str_replace('index.php', '', $url);
    $url = $url . 'jad.php/' . $fn . '.jad';
    sendEmail($phone . "@messaging.sprintpcs.com", $files[$fn], $url);

    ok("Sent $fn to $phone via Sprint's Email to SMS gateway.");
}

if ($_POST['filename']) {
    sendFile($_POST['filename'], $_POST['phoneNumber']);
}

?>

<form method="post">
<?php

foreach ($files as $filename => $desc) {
    echo "<p>";
    echo "<input type=\"radio\" name=\"filename\" value=\"" . $filename . "\"> ";
    echo "<a href=\"jad.php/" . $filename . ".jad\">" . $filename . "</a>";
    echo " - " . htmlspecialchars($desc);
    echo "</p>\n";
}

?>

<p>Send a link to the above file to this <i>Sprint</i> phone number: <input type="text" name="phoneNumber"><input type="submit"></p>

</form>

</body></html>
