<?php

header('Cache-Control: no-store, no-cache, must-revalidate');
header('Content-Type: application/java-archive');

/* Use URLs like ..../jad.php/jar-file.jar */
include('common.php');
$jar = getJarFile();
header('Content-Length: ' . filesize($jar));
echo file_get_contents($jar);
