<?php

Header('Cache-Control: no-store, no-cache, must-revalidate');
header('Content-Type: text/vnd.sun.j2me.app-descriptor');

/* Use URLs like ..../jad.php/jar-file.jar */
include('common.php');

$jarUrl = getJarUrl();
echo getJarFileDescriptor();
