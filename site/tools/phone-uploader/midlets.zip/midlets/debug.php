<html><head><title>Debug</title></head>
<body>

<?php

include('common.php');

?>
<p>When going to the URL .../debug.php, this should show the same URL. When going to .../debug.php/file.jad it should show .../jar.php/file.jar.</p>

<p><b><?php echo getJarUrl() ?></b></p>

<p>When using .../debug.php/file.jad, this is the JAR file detected.</p>

<p><b><?php echo getJarFile() ?></b></p>

<p>This is the JAR file's descriptor.</p>

<p><b><pre><?php echo htmlspecialchars(getJarFileDescriptor()) ?></pre></b></p>

<p>Test POST parameters: <form method="post"><input type="text" placeholder="Phone Number" name="phoneNumber"><input type="submit"></form></p>

<?php

if ($_POST['phoneNumber']) {
    $phone = cleansePhone($_POST['phoneNumber']);
?>

    <p><b>Phone: <?php
    echo $phone;

    if (isValidPhone($phone)) {
        echo " (valid)";
    }
}
?></b></p>

<p>Test sending email: <form method="post"><input type="text" placeholder="Email address" name="email"><input type="submit"></form></p>

<?php

if ($_POST['email']) {
    $date = date(DATE_ATOM);
    sendEmail($_POST['email'], "Test email", "This is a test email to ensure things work. $date");
    echo "<p><b>Sent email: $date</b></p>";
}

?>

<p>Additional debugging info that may be helpful when figuring out why something above does not work.</p>

<pre>$_POST = <?php htmlspecialchars(var_dump($_POST)) ?></pre>

<pre>$_SERVER = <?php htmlspecialchars(var_dump($_SERVER)) ?></pre>

</body>
</html>
