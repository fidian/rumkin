#!/usr/bin/perl

# Latitude and longitude of the locations
# Latitude is positive if it is north
# Longitude is positive if it is east
# Latitude comes first

$Step = 4;  # This gets changed to fit better.  It only decreases a bit
$Frames = 20;
$UseStepNotFrame = 1;

$Places{"Australia"} = "-4.2167:119.85:au";  # Australia, New Zealand
$Places{"Asia"} = "43.4667:99.55:as"; # Orient, India, Russia
$Places{"Africa"} = "23.3833:23.25:af"; # Africa, Europe
$Places{"South America"} = "-11.55:-59.4167:sa"; # South America and Latin America
$Places{"North America"} = "38.65:-100.24:na"; # North America and Latin America

$Website = "http://www.fourmilab.to"; # .ch and .to -- no trailing slash
$CGIURL = "$Website/cgi-bin/uncgi/Earth";
$| = 1;
$ImageDir = "orig";

GetContinents();

GetMaps("North America", "Asia");
GetMaps("South America", "Asia");
GetMaps("Africa", "Asia");
GetMaps("Australia", "Asia");
#GetMaps("North America", "South America");
#GetMaps("South America", "Africa");
#GetMaps("Africa", "Asia");
#GetMaps("Asia", "Australia");
#GetMaps("Australia", "North America");

sub GetContinents
{
    local ($Cont);
    local ($Lat, $Long, $Name);
    
    foreach $Cont (keys(%Places))
    {
        print "Continent grab:  $Cont\n";
	($Lat, $Long, $Name) = split(/:/, $Places{$Cont});
	GetPictures($Lat, $Long, $Name);
    }
}

sub GetMaps
{
    local ($FromName, $ToName) = @_;
    local ($StartLat, $StartLong, $EndLat, $EndLong);
    local ($LongDistance, $LatDistance);
    local ($TestLong, $TestLat);
    local ($NameFrom, $NameTo);
    
    ($StartLat, $StartLong, $NameFrom) = split(/:/, $Places{$FromName});
    ($EndLat, $EndLong, $NameTo) = split(/:/, $Places{$ToName});
    
    $TestLong = $EndLong;
    $TestLat = $EndLat;
    
    if ($TestLong > 0)
    {
        $TestLong -= 360;
    }
    else
    {
        $TestLong += 360;
    }
    
    if ($TestLat > 0)
    {
        $TestLat -= 360;
    }
    else
    {
        $TestLat += 360;
    }
    
    $LatDistance = $EndLat - $StartLat;
    $LatDistance = $TestLat - $StartLat 
        if (abs($EndLat - $StartLat) > abs($TestLat - $StartLat));

    $LongDistance = $EndLong - $StartLong;
    $LongDistance = $TestLong - $StartLong
        if (abs($EndLong - $StartLong) > abs($TestLong - $StartLong));
    
    print "Grabbing frames for slide from $FromName to $ToName\n";
    print "Traversing from $StartLat:$StartLong to $EndLat:$EndLong ";
    print "by moving $LatDistance:$LongDistance\n";
    
    Traverse($StartLat, $StartLong, $LatDistance, $LongDistance, 
             $NameFrom . "-" . $NameTo);
}

sub Traverse
{
    local ($StartLat, $StartLong, $LatDist, $LongDist, $Name) = @_;
    local ($i, $j);

    if ($UseStepNotFrame)
    {
        $i = abs(int($LatDist / $Step)) + 1;
	$j = abs(int($LongDist / $Step)) + 1;
	
	$i = $j if ($i < $j);
	$Frames = $i;
    }
    
    $i = 0;
    $Frames --;
    while ($i < $Frames)
    {
	$i ++;

        $j = "-";
	$j .= "0" if ($i < 100);
	$j .= "0" if ($i < 10);
        $j = $Name . $j . $i;
	print "Grabbing frame $i of $Frames at " .
	    ($StartLat + $LatDist * $i / $Frames) . ":" .
	    ($StartLong + $LongDist * $i / $Frames) . "\n";
        GetPictures($StartLat + $LatDist * $i / $Frames, 
	            $StartLong + $LongDist * $i / $Frames, $j);
    }
}

sub GetPictures
{
    local ($Lat, $Long, $Name) = @_;
    local ($String);
    
    $String = join("\\&", LatLongRequest($Lat, $Long));
    
    #print "/usr/bin/lynx -source $CGIURL\\\?$String\n";
    open(LYNX, "/usr/bin/lynx -source $CGIURL\?$String |");
    $String = "";
    foreach (<LYNX>)
    {
        if (/src="(\/earthview\/cache\/[0-9]*\.jpg)"/)
	{
	    $String = $1;
	}
    }
    close(LYNX);
    print "50% done\r";
    
    if ($String ne "")
    {
        #print "lynx -dump $Website$String > images/$Name\.jpg\n";
        system("lynx -dump $Website$String > $ImageDir/$Name\.jpg");
        print "Done.\r";
    }
}

sub LatLongRequest
{
    local ($Lat, $Long) = @_;
    local ($ns, $ew);
    local (@Request);

    push (@Request, "imgsize=320");
    push (@Request, "opt=-l");

    $ns = "North";
    if ($Lat <= 0)
    {
	$ns = "South";
	$Lat = - $Lat;
    }
    
    $ew = "East";
    if ($Long <= 0)
    {
	$ew = "West";
	$Long = - $Long;
    }

    $Lat *= 10000; 
    $Lat += .5;
    $Lat = int($Lat);
    $Lat /= 10000;
    
    $Long *= 10000;
    $Long += .5;
    $Long = int($Long);
    $Long /= 10000;
    
    push (@Request, "lat=$Lat");
    push (@Request, "ns=$ns");
    push (@Request, "lon=$Long");
    push (@Request, "ew=$ew");
    push (@Request, "alt=151866394");
    push (@Request, "daynight=-d");
    push (@Request, "img=learth.evif");

    return @Request;
}
