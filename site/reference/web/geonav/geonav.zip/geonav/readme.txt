Grabframes will get all of the globe frames.  Edit it to see the various
config options (near the top).  You'll need lynx to download the files, or
just edit the perl script.

New images are placed in orig.  I used an image converter to compress the
transition steps a great deal so that they use less memory in the browser
and give a more realistic rotating feel.

The ??.html pages are loaded by the script when the user is over the
specified country.