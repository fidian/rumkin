This program is freeware and may be distributed freely on the conditions that the contents of the zip file has not been modified and is not distrubuted for profit.

If you like it send me an e-mail.

Have fun with it.

Scott

---------------------------

Files:
DungeonHelper.prc  - D&D Tools executable
DungeonHelper.pdb  - D&D Tools database
Readme.txt   - This file

---------------------------

D&D Tools are just utility screens to compute various table functions. These are based on 3rd Edition Dungeon & Dragon rules.  (Information on 3rd edition rules can be found at http://www.tsr.com)

The arrows above each screen allows navigation between screens.

Main/About Window:
About box.

Experience:
Compute experience points based on player vs creature statisics.

Time-Distance:
Coompute distance moved over time based on movement rate.

Turning:
Undead turning computations.

The Menu:
Tools
    Experience - Go to the Experience screen.
    Time-Distance - Go to the Time-Distance screen.
    Turning - Go to the Turning screen.

-------------------------------

Other stuff...
Web:	http://www.Scott.Crawford.net

Any problems or suggestions...
e-mail:	Scott@Crawford.net

-------------------------------
12/01/2001
-------------------------------

Initial beta release.

-------------------------------

Disclaimer: (You knew this was coming didn't you.) 
This program should not harm the palm pilot in any way.
If any problems do result I can not be held responsible.
