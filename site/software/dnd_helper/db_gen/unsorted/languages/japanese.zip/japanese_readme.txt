************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** INFO *********** 
**************************** 

Japanese is the language of more than 121,044,000 persons on the islands of Japan, including the Ryukyus.<br>
In addition, there are more than 558,000 Koreans and about 44,000 Chinese in Japan who speak the language.<br>
Outside Japan a considerable number of people of Japanese parentage can speak the Japanese
language with some degree of proficiency; these include 701,000 persons in the United States, 550,000 in Brazil, 
60,000 in Peru, and 47,000 in Canada. In Korea and Taiwan the older generations speak Japanese as a second language.

**************************** 
*********** ABOUT ********** 
**************************** 

This Japanese Wordlist was created by an unknown author(no readme).
I sorted it and removed dupes.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 115521 Words
1050297 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

No doc avaliable.
