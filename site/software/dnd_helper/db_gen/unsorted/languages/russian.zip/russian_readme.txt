************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** INFO *********** 
**************************** 

Russian language, Russian RUSSKI YAZYK, principal state and cultural language of Russia.<br>
Together with Ukrainian and Belarusian, the Russian language makes up the eastern
branch of the Slavic family of languages.<br>
Russian is the primary language of the overwhelming majority of people in Russia and is also used as a second
language in other former republics of the Soviet Union.<br>
Russian was also taught extensively in those countries lying within the Soviet sphere of influence, especially
in eastern Europe, in the second half of the 20th century.

**************************** 
*********** ABOUT ********** 
**************************** 

This Wordlist contains Jan Labanowski's Wordlist and some other lists(see below).
I merged the lists, sorted the result and removed dupes.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 27924 Words
379824 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

The russian_words.koi8 contains a list of over 31,000 Russian words
in alphabetic order transliterated in KOI8 character set.
russian_words.koi8 --- straight file
russian_words.koi8.Z --- compressed with UNIX compress utility

Taken from mailserv@kiae.su.

Jan Labanowski
jkl@osc.edu

computer.slang
   Some kind of ruglish. russian computer slang dictionary 
in KOI8 format.
 
index.html
    
 
obscene_words
   Russian "dirty" words and expressions, those that you
can't find in ordinary dictionaries. KOI8 text file
 
okeany.anglo.ruskij.list
   
 
ruglish_dictionary
   Words used by Russian in America.
 
russian_words
   Wordlist of Russian words.
 

README FILE FOR RUSSIAN

The file russian.lst contains 11,071 russian words stripped from the
russian text files found on ftp.psg.com/pub/k12/russian.  The text is
a Russian history, classical Russian literature, and some oddments.

The character set used is the Russian MS-DOS character set (code page
866).  Word processors to handle the list can be found on the above
machine.  Words may appear several times in capitalised, initial
capital and lower case form.  Roman numerals, and a few strings,
containing both arabic numbers and russian characters have been
included as found.

I am hoping to create similar wordlists in several languages, except
the Major European languages, which are already covered.  I am
specifically interested in the Eastern European languages.  If users
are aware of text in any other languages, please contact Dave Fawthrop
hyphen@ibmpcug.co.uk.  Computer Hyphenation Ltd, Hyphen House, 8
Cooper Grove, Shelf, Halifax, HX3 7RF. United Kingdom Phone\Fax\Answer
+44 (0)274 733317
