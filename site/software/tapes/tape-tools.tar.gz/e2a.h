void e2a(char *src, int len);
