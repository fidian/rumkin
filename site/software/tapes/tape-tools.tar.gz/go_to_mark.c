#include <stdio.h>
#include <ftt.h>
#include "e2a.h"


ftt_descriptor d;

void fft_ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n%s\n", Msg, ftt_get_error(0));
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n", Msg);
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void HexDump(char *data, int len)
{
   int i = 0;
   char HexCodes[] = "0123456789ABCDEF";
   
   for (i = 0; i < len; i ++)
     {
	printf("%c%c ", HexCodes[(data[i] >> 4) & 0x0F],
	       HexCodes[data[i] & 0x0F]);
	if ((i + 1) % 8 == 0)
	  printf(" ");
	if ((i + 1) % 16 == 0)
	  printf("\n");
     }
}


int main(int argc, char **argv)
{
   int i;
   
   if (argc > 1)
     i = atoi(argv[1]);
   else
     i = 1;
   
   d = ftt_open("/dev/st0", FTT_RDONLY);
   
   if (d == 0)
     fft_ErrorDie("Error opening the tape at /dev/sct0");

   if (ftt_skip_fm(d, i) == -1)
     fft_ErrorDie("Error skipping to file mark");
   
   ftt_close(d);
}
