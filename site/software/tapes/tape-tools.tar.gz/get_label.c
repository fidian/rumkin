#include <stdio.h>
#include <ftt.h>
#include "e2a.h"


ftt_descriptor d;

void ftt_ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n%s\n", Msg, ftt_get_error(0));
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n", Msg);
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void HexDump(char *data, int len)
{
   int i = 0;
   char HexCodes[] = "0123456789ABCDEF";
   
   for (i = 0; i < len; i ++)
     {
	printf("%c%c ", HexCodes[(data[i] >> 4) & 0x0F],
	       HexCodes[data[i] & 0x0F]);
	if ((i + 1) % 8 == 0)
	  printf(" ");
	if ((i + 1) % 16 == 0)
	  printf("\n");
     }
}


char *GetString(char *data, int start, int len) 
{
   static char String[80];
   int i;
   
   for (i = 0; i < len; i ++)
     String[i] = data[start + i];
   
   String[i] = '\0';
   
   return String;
}


int main(void)
{
   char data[32768];
   int res;
   int labelType;
   char *vol;
   int vlen;
   
   d = ftt_open("/dev/st0", FTT_RDONLY);
   
   if (d == 0)
     ftt_ErrorDie("Error opening the tape at /dev/sct0");

   // need to read the header block
   if ((res = ftt_read(d, data, 32768)) == -1)
     ftt_ErrorDie("Error reading header block");

   switch (*((long *) data))
     {
      case 0x314c4f56:  // VOL1
      case 0x31524448:  // HDR1
      case 0x31564F45:  // EOV1
      case 0x31464F45:  // EOF1
      case 0x32524448:  // HDR2
      case 0x32564F45:  // EOV2
      case 0x32464F45:  // EOF2
	labelType = FTT_ANSI_HEADER;
	break;
      case 0xF1D3D6E5:  // VOL1
      case 0xF1D9C4C8:  // HDR1
      case 0xF1E5D6C5:  // EOV1
      case 0xF1C6D6C5:  // EOF1
      case 0xF2D9C4C8:  // HDR2
      case 0xF2E5D6C5:  // EOV2
      case 0xF2C6D6C5:  // EOF2
	labelType = FTT_IBM_HEADER;
	break;
      default:
	HexDump(data, res);
	ErrorDie("Unsupported/undetected header type");
     }
   
   while (res == 80)
     {
	if (labelType == FTT_IBM_HEADER)
	  {
	     e2a(data, res);
	  }
	switch (*((long *) data))
	  {
	     // For more information, see
	     // http://www.loc.gov/marc/specifications/specexchtape1.html
	   case 0x314c4f56:  // VOL1
	     printf("Label:  %s\n", GetString(data, 0, 4));
	     printf("Volume ID:  %s\n", GetString(data, 4, 6));
	     printf("Accessibility:  %s\n", GetString(data, 10, 1));
	     printf("Owner ID:  %s\n", GetString(data, 37, 14));
	     printf("Label Version:  %s\n", GetString(data, 79, 1));
	     printf("\n");
	     break;
	   case 0x31524448:  // HDR1
	   case 0x31564F45:  // EOV1
	   case 0x31464F45:  // EOF1
	     printf("Label:  %s\n", GetString(data, 0, 4));
	     printf("File ID:  %s\n", GetString(data, 4, 17));
	     printf("File Set ID:  %s\n", GetString(data, 21, 6));
	     printf("File Section Number:  %s\n", GetString(data, 27, 4));
	     printf("Creation Date:  %s\n", GetString(data, 41, 6));
	     printf("Expiration Date:  %s\n", GetString(data, 47, 6));
	     printf("Accessibility:  %s\n", GetString(data, 53, 1));
	     printf("Block Count:  %s\n", GetString(data, 54, 6));
	     printf("System Code:  %s\n", GetString(data, 60, 13));
	     printf("\n");
	     break;
	   case 0x32524448:  // HDR2
	   case 0x32564F45:  // EOV2
	   case 0x32464F45:  // EOF2
	     printf("Label:  %s\n", GetString(data, 0, 4));
	     printf("Record Format:  %s\n", GetString(data, 4, 1));
	     printf("Block Length:  %s\n", GetString(data, 5, 5));
	     printf("Record Length:  %s\n", GetString(data, 10, 5));
	     printf("Buffer Offset:  %s\n", GetString(data, 50, 2));
	     printf("\n");
	     break;
	   default:
	     printf("Unknown section:  %x\n", *((long *) data));
	     printf("\n");
	  }
	
	if ((res = ftt_read(d, data, 32768)) == -1)
	  ftt_ErrorDie("Error reading header block");
     }
   
   ftt_close(d);
}
