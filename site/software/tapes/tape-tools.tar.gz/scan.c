#include <stdio.h>
#include <ftt.h>
#include "e2a.h"


ftt_descriptor d;

void fft_ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n%s\n", Msg, ftt_get_error(0));
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n", Msg);
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void HexDump(char *data, int len)
{
   int i = 0;
   char HexCodes[] = "0123456789ABCDEF";
   
   for (i = 0; i < len; i ++)
     {
	printf("%c%c ", HexCodes[(data[i] >> 4) & 0x0F],
	       HexCodes[data[i] & 0x0F]);
	if ((i + 1) % 8 == 0)
	  printf(" ");
	if ((i + 1) % 16 == 0)
	  printf("\n");
     }
}


int main(void)
{
   char data[32768];
   int res;
   int labelType;
   char *vol;
   int vlen;
   int OldSize;
   int Count;
   
   d = ftt_open("/dev/st0", FTT_RDONLY);
   
   if (d == 0)
     fft_ErrorDie("Error opening the tape at /dev/sct0");
   
   printf("Blocks\tSize\n");
   
   if (ftt_rewind(d) == -1)
     fft_ErrorDie("Error rewinding tape");
   
   OldSize = -1;
   Count = 0;
   res = ftt_read(d, data, 32768);
   while (res != -1)
     {
	if (OldSize != res)
	  {
	     if (OldSize > 0)
	       printf("%d\t%d\n", OldSize, Count);
	     else if (OldSize == 0)
	       printf("---- Tape mark ----\n");
	     Count = 0;
	     OldSize = res;
	  }
	else if (res == 0)
	  {
	     if (Count == 1)
	       {
		  res = -1;
	       }
	     printf("---- Tape mark ----\n");
	  }
	
	Count ++;
	
	if (res != -1)
	  res = ftt_read(d, data, 32768);
     }
   
   if (res != -1)
     printf("%d\t%d\n", OldSize, Count);
   
   ftt_close(d);
}
