#include <stdio.h>
#include <ftt.h>
#include "e2a.h"


ftt_descriptor d;

void fft_ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n%s\n", Msg, ftt_get_error(0));
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void ErrorDie(char *Msg)
{
   fprintf(stderr, "%s\n", Msg);
   if (d != 0)
     ftt_close(d);
   exit(-1);
}


void HexDump(char *data, int len)
{
   int i = 0;
   char HexCodes[] = "0123456789ABCDEF";
   
   for (i = 0; i < len; i ++)
     {
	printf("%c%c ", HexCodes[(data[i] >> 4) & 0x0F],
	       HexCodes[data[i] & 0x0F]);
	if ((i + 1) % 8 == 0)
	  printf(" ");
	if ((i + 1) % 16 == 0)
	  printf("\n");
     }
}


char *GetString(char *data, int start, int len) 
{
   static char String[80];
   int i;
   
   for (i = 0; i < len; i ++)
     String[i] = data[start + i];
   
   String[i] = '\0';
   
   return String;
}


int main(void)
{
   char data[32768];
   int res;
   int labelType;
   char *vol;
   int vlen;
   int oldres;
   int count;
   
   d = ftt_open("/dev/st0", FTT_RDONLY);
   
   if (d == 0)
     fft_ErrorDie("Error opening the tape at /dev/sct0");

   res = ftt_read(d, data, 32768);
   
   while (res > 0)
     {
	fwrite(data, 1, res, stdout);
	res = ftt_read(d, data, 32768);
     }
   
   ftt_close(d);
}
