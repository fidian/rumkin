Launcher III 2.2

Copyright (c) 2001, Benc Software Production, http://www.benc.hr
Send questions, comments or error reports to launcheriii@benc.hr


Installation
------------
If you are already using Launcher 1.5.2 or older version, it is good to
deactivate it and delete (with the built-in launcher) before installing
the new version.

Deinstallation
--------------
Before deleting the Launcher III, you must first deactivate it by unchecking
the "Always use LauncherIII" option in the Launcher III Preferences.

If something goes terribly wrong, and you cannot access the built-in launcher,
then please install the DeactivateLIII.prc. It will automatically deactivate
the Launcher III - you don't even have to start it after installation.

DeactivateLIII.prc can also help you with any other application launcher which
hooks itself to the "Home" button.


Usage tips:
-----------
- Use the 'Tab' menu to create or delete tabs, or change current tab's properties.
To get detailed descriptions of available options, tap on the 'i' icon located in
the upper right corner of the form.

- Use the 'Options' menu to set your preferences and to access other
LauncherIII features.

- To refresh the list of applications, use the 'Refresh Apps' option.

- To set the Launcher III options, choose the 'Preferences' option under the
'Options' menu. To get detailed descriptions of available options, tap on the
'i' icon located in the upper right corner of the 'Preferences' form.

- To choose which gadgets you want to see in the Launcher III, choose the
'Gadget settings' option under the 'Options' menu. Tap on the 'Help' button
to get more information about each gadget's functionality.

- Use the 'Apps' menu to launch commonly used built-in Palm apps.

- Use the 'Help' menu at any time to view these tips.

- To launch an application, simply tap the application's icon.

- To find an application quickly, just write its beginning letter and it will be
shown at the top of the tab.

- If you tap on the hack, the 'HACK manager' application, chosen in the setup,
will be started.

- If you tap on the DOC file, the 'DOC reader' application, chosen in the setup,
will be started, and, if it supports the 'sysAppLaunchCmdOpenDB' command, selected
DOC file will be loaded.

- If you tap on the database which has associated application, that application
will be started and the database will be opened.

- To move an application to another tab, drag the application's icon and drop
it on the desired tab.

- To delete or beam an application, or to get some info about it, drag the
application's icon to appropriate gadget.

- Tap on the delete, beam or info gadget to get the list of all databases.
Chosen action will be performed on the selected database.

- To view a different tab, tap the desired tab.

- If you tap on already active tab, you'll be able to change tab's properties.

- To switch between viewing the current date, time, and day of week, tap on the
time display in the lower left-hand corner.

- To switch between showing your battery power as a voltage, or percentage bar, or
free memory as a number or percentage bar, tap on the voltage display in the lower
center.

- If a device has flash RAM, and FlashPro is installed, and the "Enable API"
checkbox is checked in the FlashPro "Preferences", then Launcher III will also
display free flash memory, and the letter "F" will be shown infront of the memory display.


LauncherIII is freeware!
