// deflater_res.h

// Forms
#define MainForm 		1000
#define PreferencesForm 1002
#define AboutForm	      1001
#define DeflateResultsForm 1003
#define InflateResultsForm 1004

// Menus
#define MainMenuBar		1000
#define MainMenuPreferences   1000
#define MainMenuAboutDeflater	1001

// Alerts
#define CustomAlert		1
#define NoZLibAlert		1000
#define FailedDeflateAlert  	1001
#define DeflateSuccessfulAlert 	1002
#define DeflateDeleteDatabaseAlert     1003
#define BadOSAlert	        1004
#define NotEnoughMemoryAlert	1005
#define SelectForDeflateAlert	1006
#define SelectForInflateAlert	1007
#define InflateDeleteDatabaseAlert	1008
#define GeneralErrorAlert       1009

// Form Objects
#define DeflatePushButton	1000
#define InflatePushButton	1001
#define DatabaseList    1002
#define DatabaseListSB	1003
#define DeflateButton	1004
#define InflateButton	1005
#define DatabaseNameTable	1002
#define FilterPopTrigger	1006
#define FilterList	1007
#define FreeSpaceLabel	1008
#define SelectForDeflate	1002
#define SelectForInflate	1003
#define DatabaseNameTableSB	1003
#define AboutOKButton	1000
#define OKButton 1001
#define CancelButton 1002
#define ShowResultsCB 1000

// Other
#define LogoBitmapFamily	1001
