/////////////////////////////////////////////////////////////////////////////
// deflatedb.h

/*
 -------------------------------------------------------------------------
 Copyright (c) 2003, Copera, Inc., Mountain View, CA, USA.
 All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software in both source and binary 
 form is allowed (with or without changes) provided that:

   1. distributions of this source code include the above copyright 
      notice, this list of conditions and the following disclaimer;

   2. distributions in binary form include the above copyright
      notice, this list of conditions and the following disclaimer
      in the documentation and/or other associated materials;

   3. the copyright holder's name is not used to endorse products 
      built using this software without specific written permission. 

 DISCLAIMER

 This software is provided 'as is' with no explcit or implied warranties
 in respect of any properties, including, but not limited to, correctness 
 and fitness for purpose.
 -------------------------------------------------------------------------
 Issue Date: January 20, 2003
*/


/////////////////////////////////////////////////////////////////////////////

Err write_output (UInt32 size)
{
  UInt16 index = dmMaxRecordIndex;
  MemHandle h = DmNewRecord (g_deflatedDB, &index, size);
  if (h == 0)
  {
    // Not enough memory for output.
    return 1;
  }
  void * p = MemHandleLock (h);
  DmWrite (p, 0, g_tempBuffer, size);
  MemHandleUnlock (h);
  DmReleaseRecord (g_deflatedDB, index, true);
  return 0;
}


/////////////////////////////////////////////////////////////////////////////

Err deflate_write_proc (const void * dataP, UInt32 * sizeP, void * userDataP)
{
  z_stream * zs = (z_stream *)userDataP;

  zs->next_in = (Bytef *)dataP;
  zs->avail_in = *sizeP;

  // Update progress meter.
  g_pm.UpdateMeter (zs->total_in);

  // Check if user pressed cancel.
  EventType event;
  EvtGetEvent (&event, 0);
  if (g_pm.CheckCancel (&event))
    return ERR_CANCEL;
  
  while (zs->avail_in > 0)
  {
    // Make sure there's some output space.
    if (zs->avail_out == 0)
    {
      // Flush to output database.
      if (write_output (TEMP_BUFFER_SIZE))
	      return ERR_WRITE;
      zs->next_out = g_tempBuffer;
      zs->avail_out = TEMP_BUFFER_SIZE;
    }
    
    // Do deflation.
    Int16 err = deflate (zs, 0);
    if (err != Z_OK)
    {
      CForm::PrintF ("deflate error (%hd)", err);
      return ERR_DEFLATE;
    }
  }

  return 0;
}


/////////////////////////////////////////////////////////////////////////////

#define ERR(x,y) { rval = x; goto DeflateDatabase_error##y; }

Err DeflateDatabase (char * name)
{
  char name2[32];
  Err rval, err2;
  int err1;
  LocalID dbID, dbID2;
  UInt32 t1 = TimGetTicks ();
  UInt32 t2;
  UInt32 typeId, creatorId;
  UInt32 totalBytes;
  z_stream zs;
  Int16 err3;

  // Open output database.
  StrCopy (name2, name);
  if (StrLen(name2) < 31) StrCat (name2, "D");
  else {
    if (name2[31] == 'D') {
      ERR(1,1);
    }
    name2[31] = 'D';
  }
  
  // Check if output database already exists.

  dbID2 = DmFindDatabase (0, name2);
  if (dbID2 != 0)
  {
    // Ask user if they want to overwrite.
    UInt16 button = FrmAlert (DeflateDeleteDatabaseAlert);
    if (button == 0) 
    {
      if (DmDeleteDatabase (0, dbID2))
      {
        // Failed to delete.
        ERR(13, 1);
      }
    }
    else
    {
      // User didn't want to overwrite.
      return 0;
    }
  }

  dbID = DmFindDatabase (0, name);
  if (dbID == 0)
  {
    // Failed to find database.
    ERR(2,1);
  }

  DmDatabaseInfo (0, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, &typeId, &creatorId);

  // Init progress meter.

  DmDatabaseSize (0, dbID, 0, &totalBytes, 0);
  g_pm.Init (totalBytes, PMF_TEXT | PMF_CANCEL);
  g_pm.UpdateText ("Deflating...");

  if (DmCreateDatabase (0, name2, creatorId, DEFLATED_DATA_TYPE, false))
  {
    // Failed to create new database.
    ERR(3,2);
  }

  dbID2 = DmFindDatabase (0, name2);
  if (dbID2 == 0)
  {
    // Failed to find new database.
    ERR(4,3);
  }

  g_deflatedDB = DmOpenDatabase (0, dbID2, dmModeWrite);
  if (g_deflatedDB == 0)
  {
    // Failed to open new database for write.
    ERR(5,3);
    return 1;
  }

  // Initialize for deflate.

  MemSet (&zs, sizeof(z_stream), 0);

  err1 = deflateInit (&zs, 6);
  if (err1 != Z_OK)
  {
    CForm::PrintF ("Failed to init (%hd)", err1);
    ERR(6,4);
  }

  zs.next_out = g_tempBuffer;
  zs.avail_out = TEMP_BUFFER_SIZE;

  // Write compressed data.

  err2 = ExgDBWrite (deflate_write_proc, (void *)&zs, name, 0, 0);
  if (err2)
  {
    if (err2 == ERR_CANCEL) ERR(0,5);
    ERR(7,5);
  }

  // Write remaining output.

  while (1)
  {    
    err3 = deflate (&zs, Z_FINISH);
    if (err3 == Z_STREAM_END) break;
    else if (err3 != Z_OK)
    {
      ERR(8,5);
    }
    
    // Make more output space and try again.
    if (zs.avail_out != 0)
    {
      ERR(9,5);
    }
    if (write_output (TEMP_BUFFER_SIZE))
    {
      ERR(10,5);
    }
    zs.avail_out = TEMP_BUFFER_SIZE;
    zs.next_out = g_tempBuffer;
  }

  // Write final output in g_tempBuffer.
  if (zs.avail_out < TEMP_BUFFER_SIZE)
  {
    if (write_output (TEMP_BUFFER_SIZE - zs.avail_out))
    {
      ERR(11,5);
    }
  }

  // Shutdown.

  deflateEnd (&zs);

  DmCloseDatabase (g_deflatedDB);
  g_deflatedDB = 0;

  // Delete old database.
  if (DmDeleteDatabase (0, dbID))
  {
    // Failed to delete old database.
    ERR(12,3);
  }

  g_pm.Finish ();

  // Rebuild name lists & refresh screen.
  BuildDatabaseArrays ();
  g_app.mainForm.UpdateFlateMode ();
  g_app.mainForm.UpdateFreeSpace ();
  
  if (g_showResults)
  {
    // Display results

    t2 = TimGetTicks ();
    UInt32 t3 = (t2 - t1);
    if (t3 == 0) t3 = 1;
    g_app.deflateResultsForm.time = (t2 - t1) / (UInt32)SysTicksPerSecond();
    if (g_app.deflateResultsForm.time == 0) g_app.deflateResultsForm.time = 1;
    float compression = 0.0f;
    if (zs.total_in > 0) compression = 
      ((float)zs.total_out / (float)zs.total_in) * 100.0f;
    g_app.deflateResultsForm.compression = (UInt32)compression;
    g_app.deflateResultsForm.speed = zs.total_in * 
      (UInt32)SysTicksPerSecond() / t3;
    g_app.deflateResultsForm.oldSize = zs.total_in;
    g_app.deflateResultsForm.newSize = zs.total_out;
    
    FrmPopupForm (DeflateResultsForm);
  }

  return 0;

DeflateDatabase_error5:
  deflateEnd (&zs);
DeflateDatabase_error4:
  DmCloseDatabase (g_deflatedDB);
DeflateDatabase_error3:
  DmDeleteDatabase (0, dbID2);
DeflateDatabase_error2:
  g_pm.Finish ();
  FrmEraseForm (FrmGetActiveForm ());
  FrmDrawForm (FrmGetActiveForm ());
DeflateDatabase_error1:
  return rval;
}

#undef ERR


/////////////////////////////////////////////////////////////////////////////

Err inflate_read_proc (void * dataP, UInt32 * sizeP, void * userDataP)
{
  if (g_inflateDone)
  {
    *sizeP = 0;
    return 0;
  }
  
  z_stream * zs = (z_stream *)userDataP;
  zs->next_out = (Bytef *)dataP;
  zs->avail_out = *sizeP;

  // Update progress meter.
  g_pm.UpdateMeter (zs->total_in);

  // Check if user pressed cancel.
  EventType event;
  EvtGetEvent (&event, 0);
  if (g_pm.CheckCancel (&event)) {
    return ERR_CANCEL;
  }

  // Loop until output buffer is filled.
  while (zs->avail_out > 0)
  {
    // Check if we need some more input.
    if (zs->avail_in == 0)
    {
      // Need to read next record into temp buffer.
      MemHandle h = DmQueryRecord (g_deflatedDB, g_nextInputRecord);
      if (h == 0)
      {
        // No more input.. ?
        return ERR_NOINPUT;
      }
      g_nextInputRecord++;
      void * p = MemHandleLock (h);
      Int16 size = MemHandleSize (h);
      MemMove (g_tempBuffer, p, size);
      MemHandleUnlock (h);
      zs->next_in = g_tempBuffer;
      zs->avail_in = size;
    }
  
    // Do inflation.
    Int16 err = inflate (zs, 0);
    if (err == Z_STREAM_END)
    {
      // Only OK if we've written all the output we need to.
      g_inflateDone = 1;
      *sizeP = *sizeP - zs->avail_out;
      return 0;
    }
    else if (err != Z_OK)
    {
      // Inflation error.
      return ERR_INFLATE;
    }
  }

  return 0;
}


/////////////////////////////////////////////////////////////////////////////

Boolean delete_proc (const char * nameP, UInt16 version, UInt16 cardNo, 
		     LocalID dbID, void * userDataP)
{
  // Ask user if they want to overwrite.
  UInt16 button = FrmAlert (InflateDeleteDatabaseAlert);
  if (button == 0) 
  {
    if (DmDeleteDatabase (0, dbID))
    {
      // Failed to delete.
      CForm::PrintF ("Failed to delete existing database");
      return false;
    }

    return true;
  }

  return false;
}


/////////////////////////////////////////////////////////////////////////////

#define ERR(x,y) { rval = x; goto InflateDatabase_error##y; }

Err InflateDatabase (char * name)
{
  UInt32 t1 = TimGetTicks ();
  Err rval, err;
  int err1;
  LocalID dbID;
  LocalID dbID2;
  UInt32 totalBytes;
  Boolean needReset;

  // Open input database.
  char name2[32];
  StrCopy (name2, name);
  if (StrLen(name2) < 31) StrCat (name2, "D");
  else {
    if (name2[31] == 'D') {
      ERR(1,1);
    }
    name2[31] = 'D';
  }

  dbID = DmFindDatabase (0, name2);
  if (dbID == 0)
  {
    // Failed to find deflated database.
    ERR(2,1);
  }

  // Init progress meter.
  DmDatabaseSize (0, dbID, 0, &totalBytes, 0);
  g_pm.Init (totalBytes, PMF_TEXT | PMF_CANCEL);
  g_pm.UpdateText ("Inflating...");

  g_deflatedDB = DmOpenDatabase (0, dbID, dmModeReadOnly);
  if (g_deflatedDB == 0)
  {
    // Failed to open input database.
    ERR(3,2);
  }

  // Initialize for inflate.

  z_stream zs;
  MemSet (&zs, sizeof(z_stream), 0);
  g_nextInputRecord = 0;
  
  err1 = inflateInit (&zs);
  if (err1 != Z_OK)
  {
    CForm::PrintF ("Failed to init (%hd)", err1);
    ERR(4,3);
  }

  zs.avail_in = 0;
  g_inflateDone = 0;
  
  err = ExgDBRead (inflate_read_proc, delete_proc, (void *)&zs, &dbID2, 0, 
		   &needReset, true);
  if (err)
  {
    if (err == ERR_CANCEL) ERR(0, 4);
    CForm::PrintF ("Failed to inflate (%hu)", err);
    ERR(5,4);
  }

  // Shutdown.

  inflateEnd (&zs);

  DmCloseDatabase (g_deflatedDB);

  if (g_inflateDone)
  {
    // Delete deflated database.

    if (DmDeleteDatabase (0, dbID))
    {
      // Failed to delete.
      ERR(6,2);
    }
  }

  g_pm.Finish ();

  // Rebuild name lists & refresh screen.
  BuildDatabaseArrays ();
  g_app.mainForm.UpdateFlateMode ();
  g_app.mainForm.UpdateFreeSpace ();

  if (g_showResults && g_inflateDone)
  {
    // Display results
    UInt32 t2 = TimGetTicks ();
    UInt32 t3 = (t2 - t1);
    if (t3 == 0) t3 = 1;
    g_app.inflateResultsForm.time = (t2 - t1) / (UInt32)SysTicksPerSecond();
    if (g_app.inflateResultsForm.time == 0) g_app.inflateResultsForm.time = 1;
    float compression = 0.0f;
    if (zs.total_out > 0) compression = ((float)zs.total_in / 
                                         (float)zs.total_out) * 100.0f;
    g_app.inflateResultsForm.compression = (UInt32)compression;
    g_app.inflateResultsForm.speed = zs.total_in * 
      (UInt32)SysTicksPerSecond() / t3;
    g_app.inflateResultsForm.oldSize = zs.total_in;
    g_app.inflateResultsForm.newSize = zs.total_out;
    
    FrmPopupForm (InflateResultsForm);
  }
  
  return 0;

InflateDatabase_error4:
  inflateEnd (&zs);
InflateDatabase_error3:
  DmCloseDatabase (g_deflatedDB);
InflateDatabase_error2:
  g_pm.Finish ();
  FrmEraseForm (FrmGetActiveForm ());
  FrmDrawForm (FrmGetActiveForm ());
InflateDatabase_error1:
  return rval;
}

#undef ERR


