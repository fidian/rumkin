/////////////////////////////////////////////////////////////////////////////
// deflater.cpp

/*
 -------------------------------------------------------------------------
 Copyright (c) 2003, Copera, Inc., Mountain View, CA, USA.
 All rights reserved.

 LICENSE TERMS

 The free distribution and use of this software in both source and binary 
 form is allowed (with or without changes) provided that:

   1. distributions of this source code include the above copyright 
      notice, this list of conditions and the following disclaimer;

   2. distributions in binary form include the above copyright
      notice, this list of conditions and the following disclaimer
      in the documentation and/or other associated materials;

   3. the copyright holder's name is not used to endorse products 
      built using this software without specific written permission. 

 DISCLAIMER

 This software is provided 'as is' with no explcit or implied warranties
 in respect of any properties, including, but not limited to, correctness 
 and fitness for purpose.
 -------------------------------------------------------------------------
 Issue Date: January 20, 2003
*/

#include <PalmOS.h>
#include <ULPProgress.h>
#include <ULPForm.h>
#include <ULPApp.h>
#include <SysZLib.h>
#include "deflater_res.h"


/////////////////////////////////////////////////////////////////////////////

#define ERR_INIT 1
#define ERR_WRITE 2
#define ERR_CANCEL 3
#define ERR_GENERAL 4
#define ERR_DEFLATE 5
#define ERR_INFLATE 6
#define ERR_NOINPUT 7

#define TEMP_BUFFER_SIZE 32000
#define DEFLATED_DATA_TYPE 'DFTD'
#define DEFLATER_CREATOR_ID 'DFLT'

#define DEFLATER_DB_NAME "Deflater"
#define ZLIB_DB_NAME "ZLib"

#define FT_ALL 0
#define FT_APPS 1
#define FT_DATA 2
#define FT_OTHER 3


/////////////////////////////////////////////////////////////////////////////

class CMainForm : public CForm
{
public:
  
  Boolean OnOpen ();
  Boolean OnClose ();
  Boolean OnScrollRepeat (Int16 value, Int16 newValue);
  Boolean OnTableEnter (TablePtr table, Int16 row, Int16 col);
  Boolean OnDeflateButton ();
  Boolean OnInflateButton ();
  Boolean OnDeflatePushButton ();
  Boolean OnInflatePushButton ();
  Boolean OnFilterPopSelect (Int16 selection);
  Boolean OnKeydown (WChar chr, UInt16 modifiers);
  Boolean OnPreferences ();
  Boolean OnAbout ();
  void UpdateFlateMode ();
  void UpdateFreeSpace ();
  Boolean HandleEvent (EventPtr event);
};


/////////////////////////////////////////////////////////////////////////////

class CPreferencesForm : public CForm
{
public:

  Boolean OnOpen ();
  Boolean OnOKButton ();
  Boolean OnCancelButton ();
  Boolean HandleEvent (EventPtr event);
};


/////////////////////////////////////////////////////////////////////////////

class CDeflateResultsForm : public CForm
{
public:

  UInt32 time;
  UInt32 compression;
  UInt32 speed;
  UInt32 oldSize;
  UInt32 newSize;

  Boolean OnOpen ();
  Boolean OnOKButton ();
  Boolean HandleEvent (EventPtr event);
};


/////////////////////////////////////////////////////////////////////////////

class CInflateResultsForm : public CForm
{
public:

  UInt32 time;
  UInt32 compression;
  UInt32 speed;
  UInt32 oldSize;
  UInt32 newSize;

  Boolean OnOpen ();
  Boolean OnOKButton ();
  Boolean HandleEvent (EventPtr event);
};


/////////////////////////////////////////////////////////////////////////////

#define APP_CLASS CDeflaterApp

class CDeflaterApp : public CApp
{
public:

  static Boolean IsDeviceCompatible (Boolean showAlert);
  static Err CreateApp () { return 0; }
  static void DestroyApp () {}
  static CDeflaterApp * GetApp ();
  void LoadForm (UInt16);
  Err NormalStart ();
  void NormalStop ();
  void EventLoop ();
  UInt32 HandleLaunch (UInt16, MemPtr, UInt16) { return 0; }
          
  DECLARE_FORM(MainForm, CMainForm, mainForm);
  DECLARE_FORM(PreferencesForm, CPreferencesForm, prefsForm);
  DECLARE_FORM(DeflateResultsForm, CDeflateResultsForm, deflateResultsForm);
  DECLARE_FORM(InflateResultsForm, CInflateResultsForm, inflateResultsForm);
};


/////////////////////////////////////////////////////////////////////////////

START_LOAD_FORM(CDeflaterApp)
  LOAD_FORM_ENTRY(MainForm, mainForm)
  LOAD_FORM_ENTRY(PreferencesForm, prefsForm)
  LOAD_FORM_ENTRY(DeflateResultsForm, deflateResultsForm)
  LOAD_FORM_ENTRY(InflateResultsForm, inflateResultsForm)
END_LOAD_FORM()


/////////////////////////////////////////////////////////////////////////////

START_FORM_EVENT_HANDLER(CForm, CMainForm)
  HANDLE_EVENT(frmOpenEvent, OnOpen)
  HANDLE_EVENT(frmCloseEvent, OnClose)
  HANDLE_MENU_ITEM(MainMenuPreferences, OnPreferences)
  HANDLE_MENU_ITEM(MainMenuAboutDeflater, OnAbout)
  HANDLE_KEYDOWN(OnKeydown)
  HANDLE_POPSELECT(FilterPopTrigger, OnFilterPopSelect)
  HANDLE_CONTROLSELECT(DeflateButton, OnDeflateButton)
  HANDLE_CONTROLSELECT(InflateButton, OnInflateButton)
  HANDLE_CONTROLSELECT(DeflatePushButton, OnDeflatePushButton)
  HANDLE_CONTROLSELECT(InflatePushButton, OnInflatePushButton)
  HANDLE_SCROLLREPEAT(DatabaseNameTableSB, OnScrollRepeat)
  HANDLE_TABLEENTER(DatabaseNameTable, OnTableEnter)
END_FORM_EVENT_HANDLER()


/////////////////////////////////////////////////////////////////////////////

START_FORM_EVENT_HANDLER(CForm, CPreferencesForm)
  HANDLE_EVENT(frmOpenEvent, OnOpen)
  HANDLE_CONTROLSELECT(OKButton, OnOKButton)
  HANDLE_CONTROLSELECT(CancelButton, OnCancelButton)
END_FORM_EVENT_HANDLER()


/////////////////////////////////////////////////////////////////////////////

START_FORM_EVENT_HANDLER(CForm, CDeflateResultsForm)
  HANDLE_EVENT(frmOpenEvent, OnOpen)
  HANDLE_CONTROLSELECT(OKButton, OnOKButton)
END_FORM_EVENT_HANDLER()


/////////////////////////////////////////////////////////////////////////////

START_FORM_EVENT_HANDLER(CForm, CInflateResultsForm)
  HANDLE_EVENT(frmOpenEvent, OnOpen)
  HANDLE_CONTROLSELECT(OKButton, OnOKButton)
END_FORM_EVENT_HANDLER()


/////////////////////////////////////////////////////////////////////////////

Bytef * g_tempBuffer = 0;
DmOpenRef g_deflatedDB = 0;
UInt32 g_databaseCount[2];
Char * g_databaseName[2] = { 0, 0 };
UInt32 * g_databaseSize[2] = { 0, 0 };
Boolean g_flateMode = 0;
Int16 g_scrollPos[2] = { 0, 0 };
UInt8 g_filterType = FT_ALL;
UInt16 g_nextInputRecord;
Boolean g_inflateDone;
CProgressMeter g_pm;
Boolean g_showResults = 0;
char g_temp[256];
CDeflaterApp g_app;


/////////////////////////////////////////////////////////////////////////////

Err BuildDatabaseArrays ();
void UpdateFlateMode (FormPtr formP);
void UpdateFreeSpace (FormPtr formP);


/////////////////////////////////////////////////////////////////////////////

void DisplayError (char * msg, Err val)
{
  StrPrintF (g_temp, "%hu", val);
  FrmCustomAlert (GeneralErrorAlert, msg, g_temp, " ");
}


/////////////////////////////////////////////////////////////////////////////

void dump_zstream (z_stream * zs) 
{
  HostTraceOutputTL (appErrorClass, "--------------------------------------");
  HostTraceOutputTL (appErrorClass, "z_stream:  %lx", zs);
  HostTraceOutputTL (appErrorClass, "next_in:   %lx", zs->next_in);
  HostTraceOutputTL (appErrorClass, "avail_in:  %hu", zs->avail_in);
  HostTraceOutputTL (appErrorClass, "total_in:  %lu", zs->total_in);
  HostTraceOutputTL (appErrorClass, "next_out:  %lx", zs->next_out);
  HostTraceOutputTL (appErrorClass, "avail_out: %hu", zs->avail_out);
  HostTraceOutputTL (appErrorClass, "total_out: %lu", zs->total_out);
  HostTraceOutputTL (appErrorClass, "msg:       %lx", zs->msg);
  HostTraceOutputTL (appErrorClass, "state:     %lx", zs->state);
  HostTraceOutputTL (appErrorClass, "zalloc:    %lx", zs->zalloc);
  HostTraceOutputTL (appErrorClass, "zfree:     %lx", zs->zfree);
  HostTraceOutputTL (appErrorClass, "opaque:    %lx", zs->opaque);
  HostTraceOutputTL (appErrorClass, "data_type: %hd", zs->data_type);
  HostTraceOutputTL (appErrorClass, "adler:     %lu", zs->adler);
  HostTraceOutputTL (appErrorClass, "reserved:  %lu", zs->reserved);
  HostTraceOutputTL (appErrorClass, "--------------------------------------");
}


#include "deflatedb.h"


/////////////////////////////////////////////////////////////////////////////

static Boolean filter_database (UInt32 typeId, LocalID dbID, char * name)
{
  if (typeId == DEFLATED_DATA_TYPE) 
    return 1; // Ignore, if it's a compressed database.
  if (MemLocalIDKind (dbID) != memIDHandle) 
    return 1; // Ignore, if it's a ROM database.
  if ((g_filterType == FT_APPS) && (typeId != 'appl')) return 1;
  if ((g_filterType == FT_DATA) && (typeId != 'DATA')) return 1;
  if ((g_filterType == FT_OTHER) && 
      ((typeId == 'appl') || (typeId == 'DATA'))) return 1;
  if (StrCompare (name, DEFLATER_DB_NAME) == 0) return 1;
  if (StrCompare (name, ZLIB_DB_NAME) == 0) return 1;

  // Check if database is deleteable.

  if (MemLocalIDKind (dbID) != memIDHandle) // db is ROM based
    return 1;
  
  UInt16 attributes;
  if (DmDatabaseInfo (0, dbID, 0, &attributes, 0, 0, 0, 0, 0, 0, 0, 0, 0) == errNone)
  {
    if (attributes & dmHdrAttrOpen) return 1; // db is currently open
  }
  else return 1; // unable to get db info
 
  return 0;
}


/////////////////////////////////////////////////////////////////////////////

Err BuildDatabaseArrays ()
{
  // Count databases and size of name array.

  DmSearchStateType ss;
  LocalID dbID;
  UInt16 cardNo;
  UInt32 typeId;
  UInt32 namesize;
  Boolean firstTime;
  UInt32 index;
  char * s;
  UInt32 totalBytes;
  
  // Clear previous lists.

  SFREE(g_databaseSize[1]);
  SFREE(g_databaseName[1]);
  SFREE(g_databaseSize[0]);
  SFREE(g_databaseName[0]);

  // Build deflate list.

  g_databaseCount[0] = 0;
  firstTime = true;
  namesize = 0;

  while (1)
  {
    if (DmGetNextDatabaseByTypeCreator (firstTime, &ss, 0, 0, false, 
					&cardNo, &dbID) != errNone)
      break;
    firstTime = false;

    DmDatabaseInfo (0, dbID, g_temp, 0, 0, 0, 0, 0, 0, 0, 0, &typeId, 0);

    if (filter_database (typeId, dbID, g_temp))
      continue;

    g_databaseCount[0]++;
    namesize += StrLen(g_temp) + 1;
  }

  if (g_databaseCount[0] != 0)
  {
    // Allocate and fill name array.

    g_databaseName[0] = (Char *)MemPtrNew (namesize);
    if (g_databaseName[0] == 0)
      return 1;

    g_databaseSize[0] = (UInt32 *)MemPtrNew (g_databaseCount[0] * 4);
    if (g_databaseSize[0] == 0)
      return 1;
  
    firstTime = true;
    s = g_databaseName[0];
    index = 0;
  
    while (1)
    {
      if (DmGetNextDatabaseByTypeCreator (firstTime, &ss, 0, 0, false, 
					  &cardNo, &dbID) != errNone)
	break;
      firstTime = false;
      DmDatabaseInfo (0, dbID, g_temp, 0, 0, 0, 0, 0, 0, 0, 0, &typeId, 0);
      
      if (filter_database (typeId, dbID, g_temp))
	continue;

      DmDatabaseSize (0, dbID, 0, &totalBytes, 0);
      g_databaseSize[0][index] = totalBytes / 1024 + 1;

      StrCopy (s, g_temp);
      s += StrLen(g_temp) + 1;
      index++;
    }
  }
  
  // Build inflate list.

  g_databaseCount[1] = 0;
  firstTime = true;
  namesize = 0;

  while (1)
  {
    if (DmGetNextDatabaseByTypeCreator (firstTime, &ss, DEFLATED_DATA_TYPE, 
					0, false, &cardNo, &dbID) != errNone)
      break;
    firstTime = false;

    DmDatabaseInfo (0, dbID, g_temp, 0, 0, 0, 0, 0, 0, 0, 0, &typeId, 0);

    g_databaseCount[1]++;
    namesize += StrLen(g_temp) + 1;
  }

  if (g_databaseCount[1] != 0)
  {
    // Allocate and fill name array.

    g_databaseName[1] = (Char *)MemPtrNew (namesize);
    if (g_databaseName[1] == 0)
      return 2;
  
    g_databaseSize[1] = (UInt32 *)MemPtrNew (g_databaseCount[1] * 4);
    if (g_databaseSize[1] == 0)
      return 1;
  
    firstTime = true;
    s = g_databaseName[1];
    index = 0;
  
    while (1)
    {
      if (DmGetNextDatabaseByTypeCreator (firstTime, &ss, DEFLATED_DATA_TYPE, 
					  0, false, &cardNo, &dbID) != errNone)
	break;
      firstTime = false;
      DmDatabaseInfo (0, dbID, g_temp, 0, 0, 0, 0, 0, 0, 0, 0, &typeId, 0);

      DmDatabaseSize (0, dbID, 0, &totalBytes, 0);
      g_databaseSize[1][index] = totalBytes / 1024 + 1;

      g_temp[StrLen(g_temp)-1] = 0; // Remove 'D' from end.
      StrCopy (s, g_temp);
      s += StrLen(g_temp) + 1;
      index++;
    }
  }
  
  g_scrollPos[0] = 0;
  g_scrollPos[1] = 0;
  
  return 0;  
}


/////////////////////////////////////////////////////////////////////////////

char * FindDatabaseNameByIndex (UInt32 index)
{
  char * s = g_databaseName[g_flateMode];
  
  while (index)
  {
    while (*s) s++;
    s++;
    index--;
  }
  
  return s;
}


/////////////////////////////////////////////////////////////////////////////

static void DrawDatabaseNameTableItem (TablePtr tableP, Int16 row, 
				       Int16 column, RectanglePtr bounds)
{
  row += g_scrollPos[g_flateMode];
  if (row < 0) return;
  if ((UInt32)row >= g_databaseCount[g_flateMode]) return;
  
  RectangleType oldclip;
  char * str = FindDatabaseNameByIndex (row);

  WinGetClip (&oldclip);
  WinSetClip (bounds);
  WinDrawChars (str, StrLen(str), bounds->topLeft.x, bounds->topLeft.y);
  
  StrPrintF (g_temp, "%luK", g_databaseSize[g_flateMode][row]);
  WinDrawChars (g_temp, StrLen(g_temp), bounds->topLeft.x + bounds->extent.x - 
		FntCharsWidth(g_temp, StrLen(g_temp)), bounds->topLeft.y);
  WinSetClip (&oldclip);
}


/////////////////////////////////////////////////////////////////////////////

void CMainForm::UpdateFreeSpace ()
{
  UInt32 memoryFree;
  MemCardInfo (0, NULL, NULL, NULL, NULL, NULL, NULL, &memoryFree);
  UInt32 mb_part = memoryFree / 1048576;
  UInt32 fr_part = (memoryFree - mb_part * 1048576) / 10000;
  StrPrintF (g_temp, "%lu.%lu MB", mb_part, fr_part);

  HideObject (FreeSpaceLabel);
  CopyLabel (FreeSpaceLabel, g_temp);
  FontID oldFont = FntSetFont (boldFont);
  SetObjectPosition (FreeSpaceLabel, 160 - 
		     FntCharsWidth(g_temp, StrLen(g_temp)), 1);
  FntSetFont (oldFont);
  ShowObject (FreeSpaceLabel);
}


/////////////////////////////////////////////////////////////////////////////

void CMainForm::UpdateFlateMode ()
{
  ControlPtr deflatePBP = (ControlPtr)GetObject (DeflatePushButton);
  TablePtr tableP = (TablePtr)GetObject (DatabaseNameTable);
  ScrollBarPtr scrollP = (ScrollBarPtr)GetObject (DatabaseNameTableSB);

  if (CtlGetValue(deflatePBP) == 1)
  {
    g_flateMode = 0;
    HideObject (InflateButton);
    ShowObject (DeflateButton);
    ShowObject (FilterPopTrigger);
  }
  else
  {
    g_flateMode = 1;
    HideObject (DeflateButton);
    ShowObject (InflateButton);
    HideObject (FilterPopTrigger);
  }

  // Scrollbar.
  Int16 rows = TblGetNumberOfRows (tableP);
  UInt16 maxValue, pos;
  if (g_databaseCount[g_flateMode] > (UInt16)rows)
  {
    pos = g_scrollPos[g_flateMode];
    maxValue = g_databaseCount[g_flateMode] - (UInt16)rows;
  }
  else
  {
    pos = 0;
    maxValue = 0;
  } 
  SclSetScrollBar (scrollP, pos, 0, maxValue, rows);
  
  // Redraw table.
  TblEraseTable (tableP);
  TblDrawTable (tableP);
}
  

/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnOpen ()
{
  if (BuildDatabaseArrays ())
  {
    DisplayError ("Failed to build database arrays", 0);
    CApp::StopApplication ();
    return true;
  }
  
  DrawForm ();

  // Select 'Delete' push button.
  SetControlValue (DeflatePushButton, 1);  
  UpdateFlateMode ();
  
  // Init database name table.

  TablePtr tableP = (TablePtr)GetObject (DatabaseNameTable);

  Int16 numRows = TblGetNumberOfRows (tableP);
  while (numRows--)
    TblSetItemStyle (tableP, numRows, 0, customTableItem);

  TblSetCustomDrawProcedure (tableP, 0, DrawDatabaseNameTableItem);
  TblSetColumnUsable (tableP, 0, true);
  TblHasScrollBar (tableP, true);

  TblEraseTable (tableP);
  TblDrawTable (tableP);

  UpdateFreeSpace ();
  
  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnClose ()
{
  SFREE(g_databaseSize[1]);
  SFREE(g_databaseName[1]);
  SFREE(g_databaseSize[0]);
  SFREE(g_databaseName[0]);
  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnScrollRepeat (Int16 value, Int16 newValue)
{
  g_scrollPos[g_flateMode] += (newValue - value);
  if (g_scrollPos[g_flateMode] < 0) 
    g_scrollPos[g_flateMode] = 0;

  TablePtr tableP = (TablePtr)GetObject (DatabaseNameTable);
  TblUnhighlightSelection (tableP);
  TblEraseTable (tableP);
  TblDrawTable (tableP);
  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnTableEnter (TablePtr tableP, Int16 row, Int16 col)
{
  if (row + g_scrollPos[g_flateMode] >= (Int16)g_databaseCount[g_flateMode]) 
    return true;

  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnDeflateButton ()
{
  Int16 row, col;
  TablePtr tableP = (TablePtr)GetObject (DatabaseNameTable);
  if (TblGetSelection (tableP, &row, &col) == true)
  {
    Err err = DeflateDatabase (FindDatabaseNameByIndex 
			   (row + g_scrollPos[g_flateMode]));
    if (err) DisplayError ("Failed to deflate database", err);
  }
  else
  {
    FrmAlert (SelectForDeflateAlert);  
  }

  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnInflateButton ()
{
  Int16 row, col;
  TablePtr tableP = (TablePtr)GetObject (DatabaseNameTable);
  if (TblGetSelection (tableP, &row, &col) == true)
  {
    Err err = InflateDatabase (FindDatabaseNameByIndex 
			   (row + g_scrollPos[g_flateMode]));
    if (err) DisplayError ("Failed to inflate database", err);
  }
  else
  {
    FrmAlert (SelectForInflateAlert);
  }

  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnDeflatePushButton ()
{
  UpdateFlateMode ();
  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnInflatePushButton ()
{
  UpdateFlateMode ();
  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnFilterPopSelect (Int16 selection)
{
  g_filterType = selection;
  BuildDatabaseArrays ();
  UpdateFlateMode ();
  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnAbout ()
{
  DoDialog (AboutForm);
  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnPreferences ()
{
  FrmPopupForm (PreferencesForm);
  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CMainForm::OnKeydown (WChar chr, UInt16 modifiers)
{
  Int16 min, max, pageSize, value, newValue;
  ScrollBarPtr scrollBarP;

  switch (chr)
  {
    case vchrPageUp:
      scrollBarP = (ScrollBarPtr)GetObject (DatabaseNameTableSB);
      SclGetScrollBar (scrollBarP, &value, &min, &max, &pageSize);
      newValue = value - 9;
      if (newValue < 0) 
	newValue = 0;
      SclSetScrollBar (scrollBarP, newValue, min, max, pageSize);
      OnScrollRepeat (value, newValue);
      break;

    case vchrPageDown:
      scrollBarP = (ScrollBarPtr)GetObject (DatabaseNameTableSB);
      SclGetScrollBar (scrollBarP, &value, &min, &max, &pageSize);
      newValue = value + 9;
      if (newValue > (Int16)g_databaseCount[g_flateMode] - 9)
	newValue = g_databaseCount[g_flateMode] - 9;
      SclSetScrollBar (scrollBarP, newValue, min, max, pageSize);
      OnScrollRepeat (value, newValue);
      break;
  }

  return false;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CPreferencesForm::OnOpen ()
{
  SetControlValue (ShowResultsCB, g_showResults);
  DrawForm ();
  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CPreferencesForm::OnOKButton ()
{
  g_showResults = GetControlValue (ShowResultsCB);
  FrmReturnToForm (0);
  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CPreferencesForm::OnCancelButton ()
{
  FrmReturnToForm (0);
  return true;
}


/////////////////////////////////////////////////////////////////////////////

void print_u32 (Char * text1, UInt32 val, Char * text2, Coord x, Coord y)
{
  WinDrawChars (text1, StrLen(text1), x, y);
  StrPrintF (g_temp, "%lu%s", val, text2);
  WinDrawChars (g_temp, StrLen(g_temp), x + 60, y);
}

Boolean CDeflateResultsForm::OnOpen ()
{
  DrawForm ();

  Coord x = 6;
  Coord y = 16;
  print_u32 ("Old Size:",     oldSize, " bytes", x, y); y += 12;
  print_u32 ("New Size:",     newSize, " bytes", x, y); y += 12;
  print_u32 ("Compression:",  compression, "%", x, y); y += 12;
  print_u32 ("Time:",         time, " secs.", x, y); y += 12;
  print_u32 ("Speed:",        speed, " bytes/sec.", x, y);

  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CDeflateResultsForm::OnOKButton ()
{
  FrmReturnToForm (0);
  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CInflateResultsForm::OnOpen ()
{
  DrawForm ();

  Coord x = 6;
  Coord y = 16;
  print_u32 ("Old Size:",     oldSize, " bytes", x, y); y += 12;
  print_u32 ("New Size:",     newSize, " bytes", x, y); y += 12;
  print_u32 ("Compression:",  compression, "%", x, y); y += 12;
  print_u32 ("Time:",         time, " secs.", x, y); y += 12;
  print_u32 ("Speed:",        speed, " bytes/sec.", x, y);

  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CInflateResultsForm::OnOKButton ()
{
  FrmReturnToForm (0);
  return true;
}


/////////////////////////////////////////////////////////////////////////////

Boolean CDeflaterApp::IsDeviceCompatible (Boolean showAlert)
{
  if (CApp::GetPalmOSROMVersion() < romVersion35)
  {
    if (showAlert) FrmAlert (BadOSAlert);
    return false;
  }

  return true;
}


/////////////////////////////////////////////////////////////////////////////

CDeflaterApp * CDeflaterApp::GetApp ()
{
  return &g_app;
}


/////////////////////////////////////////////////////////////////////////////

Err CDeflaterApp::NormalStart ()
{
  // Load preferences
  UInt16 size;
  Int16 version = PrefGetAppPreferences (DEFLATER_CREATOR_ID, 0,
					 (void *)&g_showResults, &size, true);
  if ((version != 1) || (size != sizeof(g_showResults)))
  {
    // Reset to defaults.
    g_showResults = 0;  
  }

  if (ZLSetup)
  {
    FrmAlert (NoZLibAlert);
    return 1;
  }

  // Init temp space.
  g_tempBuffer = (Bytef *)MemPtrNew (TEMP_BUFFER_SIZE);
  if (g_tempBuffer == 0)
  {
    FrmAlert (NotEnoughMemoryAlert);
    return 2;
  }

  FrmGotoForm (MainForm);
  
  return 0;
}


/////////////////////////////////////////////////////////////////////////////

void CDeflaterApp::NormalStop ()
{
  FrmCloseAllForms ();

  ZLTeardown;

  SFREE(g_tempBuffer);

  // Save preferences.
  PrefSetAppPreferences (DEFLATER_CREATOR_ID, 0, 1, (void *)&g_showResults, 
			 sizeof(g_showResults), true);
}


/////////////////////////////////////////////////////////////////////////////

#include <ULPAppMain.h>

