-----------------------------------------------------------------
                Daylight Savings Hack 2.1.3
    Copyright(C) 1997-2000, Benc Software Production
                 E-mail: support@benc.hr
                 Web: http://www.benc.hr
-----------------------------------------------------------------

"Daylight Saving Hack" uses the "HackMaster" System Extensions
Manager by Edward Keyes. It is a simple application that changes
your Pilot's time according to rules you can specify on DSHack's
control panel.

This archive contains the following files:

README.TXT   This file
DSHACK.PRC   Program file for European users

After installing DSHACK.PRC, start you hack manager, click on 
DSHack's "+" button to open control panel, specify your rules,
click on "OK" button and click DaylightSavingHack's checkbox.
After that, turn your Pilot off and on. Every time you turn on 
your Pilot, DSHack will check if it is time to switch from 
Standard to Daylight Saving Time and vice versa.

Before changing the rules, click on "Default" button first.

Here are some examples:

Europe (default settings)
-------------------------
Standard time    to  Daylight Saving  02'00 Last Sunday of March
Daylight Saving  to  Standard time    03'00 Last Sunday of October

United States
-------------
Standard time    to  Daylight Saving  02'00 First Sunday of April
Daylight Saving  to  Standard time    03'00 Last Sunday of October

Part of Australia
-----------------
Standard time    to  Daylight Saving  02'00 Last Sunday of October
Daylight Saving  to  Standard time    03'00 Last Sunday of March


Disclaimer:
-----------
"Daylight Saving Hack" is freeware. You may distribute it,
but only with this file and on non commercial basis.

Benc Software Production is not responsible for any damage or loss of
data caused by this software. If you encounter errors, please send 
a report to support@benc.hr
-----------