/* dbfcat is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfcat is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfcat archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfcat is available from http://rumkin.com/tools/dbf_tools/
 *
 * dbfcat.c is the whole program - reads from multiple files, writes one
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <zlib.h>
#include <time.h>

#define BYTE_1 unsigned char
#define BYTE_2 unsigned short
#define BYTE_4 unsigned int
#define BLOCK 32768


void WipeHeader(unsigned char *c)
{
   // Wipe the Last Update
   c[1] = '\0';
   c[2] = '\0';
   c[3] = '\0';
   
   // Wipe number of records
   c[4] = '\0';
   c[5] = '\0';
   c[6] = '\0';
   c[7] = '\0';
}


void SetHeader(unsigned char *c, BYTE_4 records)
{
   time_t t;
   struct tm *tm;
   
   memcpy(&(c[4]), &records, 4);
   t = time((time_t *) NULL);
   tm = localtime(&t);
   c[1] = tm->tm_year;
   c[2] = tm->tm_mon + 1;
   c[3] = tm->tm_mday;
}


int main(int argc, char **argv)
{
   int i, bytes;
   BYTE_4 records = 0, more_records;
   BYTE_2 first_pos, test_pos;
   gzFile **dbfFiles;
   unsigned char *header = NULL, *test_header = NULL;
   BYTE_1 dbf_type;
   
   if (argc == 1)
     {
	fprintf(stderr, "Specify .dbf or .dbf.gz files to concatenate.\n");
	fprintf(stderr, "Resulting .dbf is written to stdout.\n");
	return 0;
     }
   
   dbfFiles = (gzFile **) malloc(sizeof(gzFile *) * (argc - 1));
   if (dbfFiles == NULL)
     {
	fprintf(stderr, "Unable to allocate memory.\n");
	return 1;
     }
   
   for (i = 0; i < argc - 1; i ++)
     {
	dbfFiles[i] = gzopen(argv[i + 1], "rb");
	if (! dbfFiles[i])
	  {
	     fprintf(stderr, "Unable to open \"%s\" for reading.",
		     argv[i + 1]);
	     return 2;
	  }
	
	if (header == NULL)
	  {
	     // First file
	     dbf_type = (BYTE_1) gzgetc(dbfFiles[i]);
	     if (dbf_type != 0x02 && dbf_type != 0x03 && dbf_type != 0x30)
	       {
		  fprintf(stderr, "Bad file type 0x%02X\n", dbf_type & 0xFF);
		  return 3;
	       }
	
	     // Skip the last update
	     gzgetc(dbfFiles[i]);
	     gzgetc(dbfFiles[i]);
	     gzgetc(dbfFiles[i]);
	
	     // Number of records in file
	     gzread(dbfFiles[i], &records, 4);
	     
	     // First record position
	     gzread(dbfFiles[i], &first_pos, 2);
	     
	     // Go back to the beginning
	     gzrewind(dbfFiles[i]);
	     
	     header = (unsigned char *) malloc(first_pos);
	     test_header = (unsigned char *) malloc(first_pos);
	     if (! header || ! test_header)
	       {
		  fprintf(stderr, "Error allocating memory.\n");
		  return 4;
	       }
	     
	     gzread(dbfFiles[i], header, first_pos);
	     
	     WipeHeader(header);
	     // fprintf(stderr, "%s %u\n", argv[i + 1], records);
	  }
	else
	  {
	     // Subsequent files
	     gzread(dbfFiles[i], test_header, first_pos);
	     
	     memcpy(&more_records, &(test_header[4]), 4);
	     records += more_records;
	     
	     WipeHeader(test_header);
	    
	     if (memcmp(header, test_header, first_pos))
	       {
		  fprintf(stderr, "Header of \"%s\" does not match previous files.\n",
			  argv[i + 1]);
		  return 5;
	       }
	     // fprintf(stderr, "%s %u\n", argv[i + 1], more_records);
	  }
     }

   // fprintf(stderr, "%u\n", records);
   
   // All files are open.  Spit out modified header
   SetHeader(header, records);
   fwrite(header, 1, first_pos, stdout);
   
   free(header);
   free(test_header);
   
   header = (unsigned char *) malloc(BLOCK);
   if (header == NULL)
     {
	fprintf(stderr, "Unable to allocate the data buffer\n");
	return 6;
     }
   
   for (i = 0; i < argc - 1; i ++)
     {
	while (! gzeof(dbfFiles[i]))
	  {
	     bytes = gzread(dbfFiles[i], header, BLOCK);
	     if (bytes > 0)
	       {
		  fwrite(header, 1, bytes, stdout);
	       }
	  }
	gzclose(dbfFiles[i]);
     }
   
   free(header);
   
   return 0;
}
