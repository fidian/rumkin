/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * db.c holds all database opening, closing, and db-related functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <math.h>

#include "dbfagg.h"
#include "db.h"
#include "list.h"


void Dump(unsigned char *data, int len)
{
   int i;
   
   for (i = 0; i < len; i ++)
     {
	fprintf(stderr, "  %c (%x)", 
		(data[i] >= 32 && data[i] <= 127)?data[i]:'.', 
		data[i]);
     }
   
   fprintf(stderr, "\n");
}


FILE *OpenDatabase(char *name)
{
   FILE *fp;
   
   if (name[0] == '-' && name[1] == '\0')
     {
	return stdin;
     }
   
   fp = fopen(name, "rb");
   if (! fp)
     {
	fprintf(stderr, "Unable to open %s for reading.\n", name);
	Deallocate();
     }
   
   return fp;
}


void ReadTableHeader(FILE *fp)
{
   struct TableHeader *header;
   struct RecordHeader *record;
   int FieldStart = 1, BytesRead = 0;
   
   header = (struct TableHeader *) malloc(sizeof(struct TableHeader));
   if (! header)
     {
	fprintf(stderr, "Unable to allocate memory.\n");
	CloseProgram(fp);
     }
   
   record = (struct RecordHeader *) malloc(sizeof(struct RecordHeader));
   if (! record)
     {
	fprintf(stderr, "Unable to allocate memory.\n");
	CloseProgram(fp);
     }
   
   if (fread(header, sizeof(struct TableHeader), 1, fp) == 0)
     {
	fprintf(stderr, "Unable to read table header.\n");
	CloseProgram(fp);
     }
   BytesRead += sizeof(struct TableHeader);
   
   if (header->RecCount == 0)
     {
	fprintf(stderr, "Table record count is 0.\n");
	CloseProgram(fp);
     }
   
   RecCount = header->RecCount;
   RecLen = header->RecLen;

   if (fread(record, sizeof(struct RecordHeader), 1, fp) == 0)
     {
	fprintf(stderr, "Unable to read table record.\n");
	CloseProgram(fp);
     }
   BytesRead += sizeof(struct RecordHeader);
   
   // Can calculate the number of fields with
   // (first_record_position - 296) / 32
   while (record->FieldName[0] != 0x0D)
     {
	record->FieldName[10] = '\0';  // Just to be sure.
	
	PlaceField(record, FieldStart);
	FieldStart += record->FieldLen;

	if (BytesRead + sizeof(struct RecordHeader) <
	    header->FirstRecPos)
	  {
	     // Read another
	     if (fread(record, sizeof(struct RecordHeader), 1, fp) == 0)
	       {
		  fprintf(stderr, "Unable to read table record.\n");
		  CloseProgram(fp);
	       }
	     BytesRead += sizeof(struct RecordHeader);
	  }
	else
	  {
	     // Do not read another record
	     record->FieldName[0] = 0x0D;
	  }
     }
   
   if (BytesRead < header->FirstRecPos)
     {
	free(record);
	record = malloc(header->FirstRecPos - BytesRead);
	if (record == NULL)
	  {
	     fprintf(stderr, "Error allocating memory.\n");
	     CloseProgram(fp);
	  }
	if (fread(record, header->FirstRecPos - BytesRead, 1, fp) == 0)
	  {
	     fprintf(stderr, "Unable to read remainder of table header.\n");
	     CloseProgram(fp);
	  }
     }
   
   // fp should now be at the start of the data if all went well.
   
   free(record);
   free(header);
}


void PlaceField(struct RecordHeader *record, int FieldStart)
{
   struct groupdef *gd;
   
   gd = groupdeflist;
   
   while (gd != NULL)
     {
	if (strcasecmp(gd->FieldName, record->FieldName) == 0)
	  {
	     gd->FieldStart = FieldStart;
	     gd->FieldLen = record->FieldLen;
	     gd->FieldType = record->FieldType;
	     gd->FieldPrecision = record->FieldPrecision;
	     if (gd->OutFieldLen == -1)
	       gd->OutFieldLen = record->FieldLen;
	     if (gd->OutFieldPrecision == -1)
	       gd->OutFieldPrecision = record->FieldPrecision;
	  }
	gd = gd->Next;
     }
}


int InitDatabase(char *name)
{
   struct TableHeader header;
   struct RecordHeader record;
   int i, j;
   struct groupdef *gd;
   time_t t;
   struct tm *tm;
   
   out = fopen(name, "wb+");
   if (out == NULL)
     {
	fprintf(stderr, "Error opening %s\n", name);
	return 1;
     }
   
   i = 0;
   j = 0;
   gd = groupdeflist;
   while (gd != NULL)
     {
	i ++;
	j += gd->OutFieldLen;
	gd = gd->Next;
     }
   
   memset(&header, 0, sizeof(struct TableHeader));
   
   header.TableType = 0x03;
   header.FirstRecPos = sizeof(struct TableHeader) +
     sizeof(struct RecordHeader) * i + 1; // 1 byte for 0x0D
   header.RecLen = j + 1; // 1 byte for delete flag
  
   t = time((time_t *) NULL);
   tm = localtime(&t);
   header.LastUpdate[0] = tm->tm_year;
   header.LastUpdate[1] = tm->tm_mon + 1;
   header.LastUpdate[2] = tm->tm_mday;
   
   if (fwrite(&header, sizeof(struct TableHeader), 1, out) == 0)
     {
	fprintf(stderr, "Error writing to file.\n");
	return 1;
     }
   
   gd = groupdeflist;
   i = 1;  // 1 byte for delete flag
   while (gd != NULL)
     {
	if (gd->FuncNo == FUNC_KEY)
	  {
	     memset(&record, 0, sizeof(struct RecordHeader));
	     strcpy(record.FieldName, gd->OutFieldName);
	     strtoupper(record.FieldName);
	     record.FieldType = gd->FieldType;
	     record.FieldLen = gd->OutFieldLen;
	     record.FieldPrecision = gd->OutFieldPrecision;
	     if (fwrite(&record, sizeof(struct RecordHeader), 1, out) == 0)
	       {
		  fprintf(stderr, "Error writing to file.\n");
		  return 1;
	       }
	  }
	gd = gd->Next;
     }
   
   gd = groupdeflist;
   i = 1;  // 1 byte for delete flag
   while (gd != NULL)
     {
	if (gd->FuncNo == FUNC_SUBKEY)
	  {
	     memset(&record, 0, sizeof(struct RecordHeader));
	     strcpy(record.FieldName, gd->OutFieldName);
	     strtoupper(record.FieldName);
	     record.FieldType = gd->FieldType;
	     record.FieldLen = gd->OutFieldLen;
	     record.FieldPrecision = gd->OutFieldPrecision;
	     if (fwrite(&record, sizeof(struct RecordHeader), 1, out) == 0)
	       {
		  fprintf(stderr, "Error writing to file.\n");
		  return 1;
	       }
	  }
	gd = gd->Next;
     }
   
   gd = groupdeflist;
   i = 1;  // 1 byte for delete flag
   while (gd != NULL)
     {
	if (gd->FuncNo != FUNC_KEY && gd->FuncNo != FUNC_SUBKEY)
	  {
	     memset(&record, 0, sizeof(struct RecordHeader));
	     strcpy(record.FieldName, gd->OutFieldName);
	     strtoupper(record.FieldName);
	     record.FieldType = gd->FieldType;
	     record.FieldLen = gd->OutFieldLen;
	     record.FieldPrecision = gd->OutFieldPrecision;
	     
	     if (fwrite(&record, sizeof(struct RecordHeader), 1, out) == 0)
	       {
		  fprintf(stderr, "Error writing to file.\n");
		  return 1;
	       }
	  }
	gd = gd->Next;
     }
   
   record.FieldName[0] = 0x0D;
   if (fwrite(&record, 1, 1, out) == 0)
     {
	fprintf(stderr, "Error writing to file.\n");
	return 1;
     }
   
   return 0;
}


void SetRecordNumber(void)
{
   BYTE_4 reccount;
   
   if (fseek(out, 4, SEEK_SET) != 0)
     {
	fprintf(stderr, "Error seeking in file.\n");
	return;
     }
   
   reccount = WrittenRecords;
   if (fwrite(&reccount, 4, 1, out) == 0)
     {
	fprintf(stderr, "Error updating the number of records.\n");
	return;
     }
   
   if (fseek(out, 0, SEEK_END) != 0)
     {
	fprintf(stderr, "Error seeking to end of file.\n");
	return;
     }
}


int DumpSubkeys(unsigned char *key, unsigned int keysize, 
		 struct SortedListNode **list, unsigned int subkeysize)
{
   unsigned char *totalkey;
   struct SortedListNode *node, *tmp;
   
   totalkey = malloc(keysize + subkeysize);
   if (totalkey == NULL)
     {
	fprintf(stderr, "Error allocating memory.\n");
	return 1;
     }
   
   memcpy(totalkey, key, keysize);
   
   node = *list;
   *list = NULL;
   
   while (node != NULL)
     {
	memcpy(totalkey + keysize, node->Key, subkeysize);
	if (DumpRecord(totalkey, keysize + subkeysize, 
		       &(node->Data.SmallGroupDef)))
	  return 1;
	tmp = node;
	node = node->Next;
	free(tmp);
     }

   free(totalkey);
   return 0;
}


int DumpRecord(unsigned char *key, unsigned int keysize, 
	       struct smallgroupdef **sgd)
{
   struct smallgroupdef *cur, *tmp;
   char deleteflag = ' ';
   
   cur = *sgd;
   *sgd = NULL;
   
   if (cur == NULL)
     return 0;
   
   WrittenRecords ++;

   if (fwrite(&deleteflag, 1, 1, out) == 0)
     {
	fprintf(stderr, "Unable to append data to file.\n");
	return 1;
     }
   
   if (fwrite(key, keysize, 1, out) == 0)
     {
	fprintf(stderr, "Unable to append data to file.\n");
	return 1;
     }
   
   while (cur != NULL)
     {
	if (cur->FuncNo == FUNC_MAX)
	  {
	     if (WriteNumber(cur->Data.Double, cur->FieldLen,
			     cur->FieldPrecision))
	       return 1;
	  }
	else if (cur->FuncNo == FUNC_MIN)
	  {
	     if (WriteNumber(cur->Data.Double, cur->FieldLen,
			     cur->FieldPrecision))
	       return 1;
	  }
	else if (cur->FuncNo == FUNC_SUM)
	  {
	     if (WriteNumber(cur->Data.Double, cur->FieldLen,
			     cur->FieldPrecision))
	       return 1;
	  }
	else if (cur->FuncNo == FUNC_MODE)
	  {
	     if (WriteMode(&(cur->Data.List), cur->FieldLen))
	       return 1;
	  }
	else if (cur->FuncNo == FUNC_MODENB)
	  {
	     if (WriteModeNB(&(cur->Data.List), cur->FieldLen,
			     cur->FieldType))
	       return 1;
	  }
	else if (cur->FuncNo == FUNC_COUNT)
	  {
	     if (WriteNumber(cur->Data.Long, cur->FieldLen,
			     cur->FieldPrecision))
	       return 1;
	  }
	else if (cur->FuncNo == FUNC_AVG)
	  {
	     if (WriteNumber(cur->Data.Double / cur->ExtraData, 
			 cur->FieldLen, cur->FieldPrecision))
	       return 1;
	  }
	else
	  {
	     fprintf(stderr, "Unknown function in DumpRecord()\n");
	     return 1;
	  }
   
	tmp = cur;
	cur = cur->Next;
	free(tmp);
     }
   return 0;
}


int WriteNumber(double d, int len, int prec)
{
   char *outbuf;
   signed int i;
   int j;
   long long l, ll;
   double dd;

   outbuf = malloc(len);
   if (outbuf == NULL)
     {
	fprintf(stderr, "Unable to allocate memory.\n");
	return 1;
     }
   
   memset(outbuf, ' ', len);
   
   i = len;
   
   if (prec)
     {
	i -= prec + 1;
     }
   
   dd = 0.5 / pow(10, prec);  // Rounding factor
   if (d < 0)
     {
	d -= dd;
	dd = - d;
     }
   else
     {
	d += dd;
	dd = d;
     }
   l = abs((long long) d);
   dd -= (double) l;
   
   outbuf[i - 1] = '0';
   
   while (l && i > 0)
     {
	i --;
	ll = l / 10;
	j = l - (ll * 10);
	l = ll;
	outbuf[i] = '0' + j;
     }
   
   if (i == 0 && l)
     {
	// Overflow is not a "hard error"
	memset(outbuf, '*', len);
	return WriteAndFree(outbuf, len);
     }
   
   if (d < 0)
     {
	if (i == 0)
	  {
	     // Overflow is not a "hard error"
	     memset(outbuf, '*', len);
	     return WriteAndFree(outbuf, len);
	  }
	i --;
	outbuf[i] = '-';
     }
   
   if (prec == 0)
     {
	return WriteAndFree(outbuf, len);
     }
   
   i = len - (prec + 1);
   outbuf[i ++] = '.';
   while (i < len)
     {
	dd *= 10;
	l = (long long) dd;
	outbuf[i ++] = '0' + l;
	dd -= (double) l;
     }
   
   return WriteAndFree(outbuf, len);
}


int WriteMode(struct SortedListNode **ListHead, int len)
{
   unsigned char *winner = NULL;
   unsigned long win_count = 0;
   struct SortedListNode *cur, *tmp;
   
   cur = *ListHead;
   *ListHead = NULL;
   
   while (cur != NULL)
     {
	if (win_count < cur->Data.Count)
	  {
	     if (winner != NULL)
	       free(winner);
	     winner = cur->Key;
	     win_count = cur->Data.Count;
	  }
	else
	  {
	     free(cur->Key);
	  }
		 
	tmp = cur;
	cur = cur->Next;
	free(tmp);
     }

   return WriteAndFree(winner, len);
}


int IsEmpty(char *c, char t)
{
   int i = 0;
   if (t == 'C')
     {
	// Spaces only
	while (c[i] == ' ')
	  {
	     i ++;
	  }
	if (c[i] == '\0')
	  return 1;
     }
   else if (t == 'N')
     {
	// Spaces, zeros, period, hyphen
	while (c[i] == ' ' || c[i] == '0' || c[i] == '.' || c[i] == '-')
	  {
	     i ++;
	  }
	if (c[i] == '\0')
	  return 1;
     }
   return 0;
}


// Merely set all "blank" entries to have a score of 1 and increment
// everything else.  That will force empty nodes to have the lowest
// priority possible.
int WriteModeNB(struct SortedListNode **ListHead, int len, char type)
{
   struct SortedListNode *cur;
   
   cur = *ListHead;
   while (cur != NULL)
     {
	if (IsEmpty(cur->Key, type))
	  {
	     cur->Data.Count = 1;
	  }
	else
	  {
	     cur->Data.Count ++;
	  }
	cur = cur->Next;
     }
   
   return WriteMode(ListHead, len);
}


int WriteAndFree(unsigned char *outbuf, int len)
{
   if (fwrite(outbuf, len, 1, out) == 0)
     {
	free(outbuf);
	return 1;
     }
   free(outbuf);
   return 0;
}


void strtoupper(char *c)
{
   while (*c != '\0')
     {
	if (*c >= 'a' && *c <= 'z')
	  *c += 'A' - 'a';
	c ++;
     }
}


double ParseNumber(char *c, int l)
{
   double d = 0.0, factor = 0.0;
   int sign = 1;
   
   while (l --)
     {
	if (factor == 0)
	  {
	     // Left side of decimal point up to the decimal point
	     if (*c == '.')
	       {
		  factor = 0.1;
	       }
	     else if (*c == '-')
	       {
		  sign = -1;
	       }
	     else if (*c != ' ' && (*c < '0' || *c > '9'))
	       {
		  // Not a valid number, decimal, hyphen, or space
		  return d * (double) sign;
	       }
	     else if (*c >= '0' && *c <= '9')
	       {
		  d *= 10;
		  d += *c - '0';
	       }
	     // Unhandled case:  *c == ' '
	  }
	else
	  {
	     if (*c < '0' || *c > '9')
	       {
		  // Not a number -- quit
		  return d * (double) sign;
	       }
	     d += factor * (*c - '0');
	     factor /= 10;
	  }
	
	c ++;
     }
   
   return d * (double) sign;
}

