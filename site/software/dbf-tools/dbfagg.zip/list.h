/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * list.h holds the definition of a linked list node struct
 */

#ifndef LIST_H
#define LIST_H

struct SortedListNode
{
   unsigned char *Key;
   union 
     {
	struct smallgroupdef *SmallGroupDef;
//	struct groupdef *GroupDef;
	unsigned long Count;
     } Data;
   struct SortedListNode *Next;
};

struct SortedListNode *FindKey(struct SortedListNode **, 
			       unsigned char *, int);

#endif
