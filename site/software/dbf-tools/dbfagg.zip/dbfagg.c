/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * dbfagg.c is the main program file, which accepts options and runs commands
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define DBFAGG_MAIN

#include "dbfagg.h"

#include "db.h"
#include "list.h"
#include "script.h"


int main(int argc, char **argv)
{
   FILE *fp;
   
   if (argc < 4)
     {
	if (argc > 1)
	  {
	     printf("Too few arguments\n");
	     printf("\n");
	  }
	
	fprintf(stderr, "dbfagg <input> <script> <output>\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "Runs group functions on a dbf to make it smaller.\n");
	fprintf(stderr, "Try to have the input file be sorted before hand for best results.\n");
	fprintf(stderr, "\n");
	fprintf(stderr, "<input>  :: The name of the input dbf or - for stdin\n");
	fprintf(stderr, "<script> :: The name of the script file\n");
	fprintf(stderr, "<output> :: The name of the output dbf\n");
	
	return 1;
     }
   
   LoadScriptFile(argv[2]);
   fp = OpenDatabase(argv[1]);
   ReadTableHeader(fp);
   if (TestGroupdef())
     CloseProgram(fp);

   if (InitDatabase(argv[3]))
     CloseProgram(fp);
   ProcessData(fp);
   
   if (fp != stdin)
     fclose(fp);
   
   Deallocate();
   
   return 0;
}


void CloseProgram(FILE *fp)
{
   if (fp != stdin)
     fclose(fp);
   if (out != NULL)
     fclose(out);
   Deallocate();
   exit(1);
}


void Deallocate(void)
{
   struct groupdef *gd, *gd2;
   
   gd = groupdeflist;
   while (gd != NULL)
     {
	gd2 = gd->Next;
	free(gd);
	gd = gd2;
     }
}


int TestGroupdef(void)
{
   struct groupdef *gd;
   int errorcount, allowedtypes;
   
   gd = groupdeflist;
   errorcount = 0;
   
   while (gd != NULL)
     {
	if ((gd->FieldStart == 0 || gd->FieldLen == 0) &&
	    gd->FuncNo != FUNC_COUNT)
	  {
	     fprintf(stderr, "Field %s not in database.\n", gd->FieldName);
	     errorcount ++;
	  }
	else
	  {
	     // allowedtypes bitmask:
	     // 1 = N
	     // 2 = C
	     
	     if (gd->FuncNo == FUNC_KEY)
	       allowedtypes = 3;
	     else if (gd->FuncNo == FUNC_SUBKEY)
	       allowedtypes = 3;
	     else if (gd->FuncNo == FUNC_MAX)
	       allowedtypes = 1;
	     else if (gd->FuncNo == FUNC_MIN)
	       allowedtypes = 1;
	     else if (gd->FuncNo == FUNC_SUM)
	       allowedtypes = 1;
	     else if (gd->FuncNo == FUNC_MODE)
	       allowedtypes = 3;
	     else if (gd->FuncNo == FUNC_MODENB)
	       allowedtypes = 3;
	     else if (gd->FuncNo == FUNC_AVG)
	       allowedtypes = 1;
	     else if (gd->FuncNo == FUNC_COUNT)
	       allowedtypes = 0;
	     else
	       {
		  fprintf(stderr, "Unknown function\n");
		  return 1;
	       }
	     
	     if ((allowedtypes & 0x01 && gd->FieldType != 'N') &&
		 (allowedtypes & 0x02 && gd->FieldType != 'C'))
	       {
		  fprintf(stderr, "Bad type for field %s.\n",
			  gd->OutFieldName);
		  errorcount ++;
	       }
	     
	     if (gd->OutFieldLen < gd->OutFieldPrecision + 1)
	       {
		  fprintf(stderr, "Field %s needs to be longer.\n",
			  gd->OutFieldName);
		  errorcount ++;
	       }
	  }
	gd = gd->Next;
     }
   
   return errorcount;
}


void FreeSmallGroupDef(struct smallgroupdef *sgd)
{
   struct smallgroupdef *sgd2;

   while (sgd != NULL)
     {
	sgd2 = sgd;
	sgd = sgd->Next;
	
	if (sgd2->FuncNo == FUNC_MODE || sgd2->FuncNo == FUNC_MODENB)
	  {
	     FreeSortedList(sgd2->Data.List, 1);
	  }
	
	free(sgd2);
     }
   
}


void FreeSortedList(struct SortedListNode *sln, int IsCount)
{
   struct SortedListNode *sln2;
   
   while (sln != NULL)
     {
	sln2 = sln;
	sln = sln->Next;
	
	if (sln2->Key != NULL)
	  free(sln2->Key);
	
	if (IsCount == 0 && sln2->Data.SmallGroupDef != NULL)
	  FreeSmallGroupDef(sln2->Data.SmallGroupDef);
	
	free(sln2);
     }
}


void FreeAndClose(char *data, unsigned int keysize, char *thiskey,
		  char *lastkey, unsigned int subkeysize,
		  char *subkey, struct SortedListNode *SubAggData,
		  struct smallgroupdef *AggData, FILE *fp)
{
   struct SortedListNode *sln;
   
   free(data);
   
   if (keysize > 0)
     {
	free(lastkey);
	free(thiskey);
     }
   
   if (subkeysize > 0)
     {
	free(subkey);
     }
   
   if (subkeysize > 0)
     {
	FreeSortedList(SubAggData, 0);
     }
   else
     {
	FreeSmallGroupDef(AggData);
     }
   
   if (fp != NULL)
     CloseProgram(fp);
}
       
       
void ProcessData(FILE *fp)
{
   unsigned char *data;
   char *lastkey, *thiskey, *keyswap, *subkey;
   unsigned int keysize, subkeysize;
   struct SortedListNode *SubAggData = NULL, *Use_AggData;
   struct smallgroupdef **AggData = NULL, *sgd;
   unsigned long long reccount;
   
   data = (char *) malloc(RecLen + 1);
   // Add 1 for spare byte at the end which could be used if the last
   // field is numeric and an aggregate function is used on it.
   // See how AggregateRecord() works.
   if (data == NULL)
     {
	fprintf(stderr, "Error allocating memory.\n");
	CloseProgram(fp);
     }
   
   keysize = FindKeySize(FUNC_KEY);
   subkeysize = FindKeySize(FUNC_SUBKEY);

   if (keysize > 0)
     {
	lastkey = (char *) calloc(keysize, 1);
	if (lastkey == NULL)
	  {
	     free(data);
	     fprintf(stderr, "Error allocating memory.\n");
	     CloseProgram(fp);
	  }
	
	thiskey = (char *) malloc(keysize);
	if (thiskey == NULL)
	  {
	     free(data);
	     free(lastkey);
	     fprintf(stderr, "Error allocating memory.\n");
	     CloseProgram(fp);
	  }
     }
   
   if (subkeysize > 0)
     {
	subkey = (char *) malloc(subkeysize);
	if (subkey == NULL)
	  {
	     free(data);
	     if (keysize > 0)
	       {
		  free(lastkey);
		  free(thiskey);
	       }
	     fprintf(stderr, "Error allocating memory.\n");
	     CloseProgram(fp);
	  }
     }
   
   AggData = &(sgd);
   sgd = NULL;
   reccount = 0;
   while (fread(data, RecLen, 1, fp))
     {
	reccount ++;
	BuildKey(FUNC_KEY, thiskey, data);
	
	if (keysize > 0 && memcmp(lastkey, thiskey, keysize))
	  {
	     if (subkeysize)
	       {
		  if (DumpSubkeys(lastkey, keysize, &SubAggData, 
				  subkeysize))
		    {
		       FreeAndClose(data, keysize, thiskey, lastkey,
				    subkeysize, subkey, SubAggData, 
				    *AggData, fp);
		    }
	       }
	     else
	       {
		  if (DumpRecord(lastkey, keysize, AggData))
		    {
		       FreeAndClose(data, keysize, thiskey, lastkey,
				    subkeysize, subkey, SubAggData, 
				    *AggData, fp);
		    }
	       }
	     
	     // Set lastkey, but instead of copying memory, just
	     // do three assignments.  Might be faster for keys
	     // longer than maybe 9 chars?  Give or take.
	     keyswap = lastkey;
	     lastkey = thiskey;
	     thiskey = keyswap;	     
	  }
	
	if (subkeysize > 0)
	  {
 	     BuildKey(FUNC_SUBKEY, subkey, data);
	     Use_AggData = FindKey(&SubAggData, subkey, subkeysize);
	     if (Use_AggData == NULL)
	       {
		  FreeAndClose(data, keysize, thiskey, lastkey,
			       subkeysize, subkey, SubAggData, *AggData, fp);
	       }
	     AggData = &(Use_AggData->Data.SmallGroupDef);
	  }
	
	if (*AggData == NULL)
	  {
	     // Allocate a new data entry
	     if (CreateAggList(AggData))
	       {
		  FreeAndClose(data, keysize, thiskey, lastkey,
			       subkeysize, subkey, SubAggData, *AggData, fp);
	       }
	  }
	AggregateRecord(data, AggData);
     }

   if (subkeysize)
     {
	if (DumpSubkeys(lastkey, keysize, &SubAggData, subkeysize))
	  {
	     FreeAndClose(data, keysize, thiskey, lastkey,
			  subkeysize, subkey, NULL, NULL, fp);
	  }
     }
   else
     {
	if (DumpRecord(lastkey, keysize, AggData))
	  {
	     FreeAndClose(data, keysize, thiskey, lastkey,
			  subkeysize, subkey, NULL, NULL, fp);
	  }
     }
   
   SetRecordNumber();
   
   FreeAndClose(data, keysize, thiskey, lastkey, subkeysize,
		subkey, NULL, NULL, NULL);
}


unsigned int FindKeySize(int KeyType)
{
   unsigned int i = 0;
   struct groupdef *gd;
   
   gd = groupdeflist;
   
   while (gd != NULL)
     {
	if (gd->FuncNo == KeyType)
	  {
	     i += gd->FieldLen;
	  }
	gd = gd->Next;
     }
   
   return i;
}


void BuildKey(int KeyType, unsigned char *where, unsigned char *rec)
{
   unsigned int i = 0, j;
   struct groupdef *gd;
   
   gd = groupdeflist;
   
   while (gd != NULL)
     {
	if (gd->FuncNo == KeyType)
	  {
	     memcpy(where + i, rec + gd->FieldStart, gd->FieldLen);
	     i += gd->FieldLen;
	  }
	gd = gd->Next;
     }
}


int CreateAggList(struct smallgroupdef **gdHead)
{
   struct groupdef *gd;
   struct smallgroupdef *gdnew, *gdlast;
   
   *gdHead = NULL;
   gdlast = NULL;
   gd = groupdeflist;
   
   while (gd != NULL)
     {
	if (gd->FuncNo != FUNC_KEY && gd->FuncNo != FUNC_SUBKEY)
	  {
	     gdnew = (struct smallgroupdef *) 
	       calloc(sizeof(struct smallgroupdef), 1);
	     if (gdnew == NULL)
	       {
		  fprintf(stderr, "Error allocating memory.\n");
		  return 1;
	       }
	     gdnew->FuncNo = gd->FuncNo;
	     gdnew->FieldStart = gd->FieldStart;
	     gdnew->FieldLen = gd->OutFieldLen;
	     gdnew->FieldPrecision = gd->OutFieldPrecision;
	     gdnew->SourceLen = gd->FieldLen;
	     gdnew->FieldType = gd->FieldType;
	     
	     if (gdlast == NULL)
	       {
		  gdlast = gdnew;
		  *gdHead = gdnew;
	       }
	     else
	       {
		  gdlast->Next = gdnew;
		  gdlast = gdnew;
	       }
	  }
	gd = gd->Next;
     }
   return 0;
}


void AggregateRecord(unsigned char *data, struct smallgroupdef **sgdHead)
{
   struct smallgroupdef *sgd;
   struct SortedListNode *sln;
   double d;
   
   sgd = *sgdHead;
   
   while (sgd != NULL)
     {
	if (sgd->FuncNo == FUNC_MIN)
	  {
	     d = ParseNumber(data + sgd->FieldStart, sgd->SourceLen);
	     if (sgd->ExtraData == 0 || sgd->Data.Double > d)
	       {
		  sgd->ExtraData = 1;
		  sgd->Data.Double = d;
	       }
	  }
	else if (sgd->FuncNo == FUNC_MAX)
	  {
	     d = ParseNumber(data + sgd->FieldStart, sgd->SourceLen);
	     if (sgd->ExtraData == 0 || sgd->Data.Double < d)
	       {
		  sgd->ExtraData = 1;
		  sgd->Data.Double = d;
	       }
	  }
	else if (sgd->FuncNo == FUNC_SUM)
	  {
	     sgd->Data.Double += ParseNumber(data + sgd->FieldStart, 
					     sgd->SourceLen);
	  }
	else if (sgd->FuncNo == FUNC_MODE || sgd->FuncNo == FUNC_MODENB)
	  {
	     sln = FindKey(&(sgd->Data.List), data + sgd->FieldStart,
			   sgd->SourceLen);
	     sln->Data.Count ++;
	  }
	else if (sgd->FuncNo == FUNC_COUNT)
	  {
	     sgd->Data.Long ++;
	  }
	else if (sgd->FuncNo == FUNC_AVG)
	  {
	     sgd->Data.Double += ParseNumber(data + sgd->FieldStart, 
					     sgd->SourceLen);
	     sgd->ExtraData ++;
	  }
	else
	  {
	     fprintf(stderr, "Unknown function in AggregateRecord()\n");
	     return;
	  }

	sgd = sgd->Next;
     }
}
