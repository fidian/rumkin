/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * script.c is responsible for everything to read the script format
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "dbfagg.h"

void GetFields(struct groupdef *gd, char *src, int i);


void LoadScriptFile(char *filename)
{
   FILE *fp;
   int i, needfield;
   char line[256];
   struct groupdef *gd = NULL;
   
   fp = fopen(filename, "r");
   if (! fp)
     {
	fprintf(stderr, "Unable to open script file:  %s\n", filename);
	exit(1);
     }
   
   while (!feof(fp))
     {
	line[0] = '\0';
	fgets(line, 256, fp);
	
	i = 0;
	while (line[i] == ' ' || line[i] == '\t' || line[i] == '\r' ||
	       line[i] == '\n')
	  i ++;
	
	if (line[i] != '\0')
	  {
	     if (gd == NULL)
	       {
		  gd = (struct groupdef *) calloc(sizeof(struct groupdef), 1);
		  if (gd == NULL)
		    {
		       fprintf(stderr, "Error allocating memory.\n");
		       exit(1);
		    }
		  groupdeflist = gd;
	       }
	     else
	       {
		  gd->Next = (struct groupdef *) calloc(sizeof(struct groupdef), 1);
		  if (gd->Next == NULL)
		    {
		       Deallocate();
		       fprintf(stderr, "Error allocating memory.\n");
		       exit(1);
		    }
		  gd = gd->Next;
	       }
	     
	     gd->OutFieldLen = -1;
	     gd->OutFieldPrecision = -1;
	     
	     if (strncasecmp(&(line[i]), "KEY", 3) == 0)
	       {
		  gd->FuncNo = FUNC_KEY;
		  i += 3;
		  GetFields(gd, line, i);
	       }
	     else if (strncasecmp(&(line[i]), "SUBKEY", 6) == 0)
	       {
		  gd->FuncNo = FUNC_SUBKEY;
		  i += 6;
		  GetFields(gd, line, i);
	       }
	     else if (strncasecmp(&(line[i]), "MAX", 3) == 0)
	       {
		  gd->FuncNo = FUNC_MAX;
		  i += 3;
		  GetFields(gd, line, i);
	       }
	     else if (strncasecmp(&(line[i]), "MIN", 3) == 0)
	       {
		  gd->FuncNo = FUNC_MIN;
		  i += 3;
		  GetFields(gd, line, i);
	       }
	     else if (strncasecmp(&(line[i]), "SUM", 3) == 0)
	       {
		  gd->FuncNo = FUNC_SUM;
		  i += 3;
		  GetFields(gd, line, i);
	       }
	     else if (strncasecmp(&(line[i]), "MODENB", 6) == 0)
	       {
		  gd->FuncNo = FUNC_MODENB;
		  i += 6;
		  GetFields(gd, line, i);
	       }
	     else if (strncasecmp(&(line[i]), "MODE", 4) == 0)
	       {
		  gd->FuncNo = FUNC_MODE;
		  i += 4;
		  GetFields(gd, line, i);
	       }
	     else if (strncasecmp(&(line[i]), "COUNT", 5) == 0)
	       {
		  gd->FuncNo = FUNC_COUNT;
		  gd->FieldType = 'N';
		  gd->FieldLen = 9;
		  gd->FieldPrecision = 0;
		  i += 5;
		  GetFields(gd, line, i);
		  if (gd->OutFieldLen == -1)
		    gd->OutFieldLen = gd->FieldLen;
		  if (gd->OutFieldPrecision == -1)
		    gd->OutFieldPrecision = gd->FieldPrecision;
	       }
	     else if (strncasecmp(&(line[i]), "AVG", 3) == 0)
	       {
		  gd->FuncNo = FUNC_AVG;
		  i += 3;
		  GetFields(gd, line, i);
	       }
	     else
	       {
		  Deallocate();
		  fprintf(stderr, "Unknown function:  %s\n", &(line[i]));
		  exit(1);
	       }
	  }
     }
}

   
void GetFields(struct groupdef *gd, char *src, int i)
{
   int j;
   
   if (src[i] != ' ' && src[i] != '\t')
     {
	Deallocate();
	fprintf(stderr, "Bad line:  %s\n");
	exit(1);
     }
   
   while (src[i] == ' ' || src[i] == '\t' || src[i] == '\n' || 
	  src[i] == '\r')
     {
	i ++;
     }
   
   if (src[i] == '\0')
     {
	Deallocate();
	fprintf(stderr, "Field required:  %s\n", src);
	exit(1);
     }
   
   // FieldName
   
   if (gd->FuncNo != FUNC_COUNT)
     {
	for (j = 0; j < 10 && src[i] != '\0' && src[i] != ' ' &&
	     src[i] != '\t' && src[i] != '\r' && src[i] != '\n'; j ++, i ++)
	  {
	     gd->FieldName[j] = src[i];
	  }
	
	if (src[i] != '\0' && src[i] != ' ' && src[i] != '\t' &&
	    src[i] != '\r' && src[i] != '\n')
	  {
	     Deallocate();
	     fprintf(stderr, "Field name too long.\n");
	     exit(1);
	  }
	
	gd->FieldName[j] = '\0';
	
	strcpy(gd->OutFieldName, gd->FieldName);
	
	if (src[i] == '\0')
	  return;
	
	while (src[i] == ' ' || src[i] == '\t' || src[i] == '\n' || 
	       src[i] == '\r')
	  {
	     i ++;
	  }
     }
   else
     {
	gd->FieldName[0] = '\0';
     }
   
   
   // OutFieldName

   for (j = 0; j < 10 && src[i] != '\0' && src[i] != ' ' &&
	src[i] != '\t' && src[i] != '\r' && src[i] != '\n'; j ++, i ++)
     {
	gd->OutFieldName[j] = src[i];
     }
   
   if (src[i] != '\0' && src[i] != ' ' && src[i] != '\t' &&
       src[i] != '\r' && src[i] != '\n')
     {
	Deallocate();
	fprintf(stderr, "Field name too long.\n");
	exit(1);
     }

   if (j)
     {
	gd->OutFieldName[j] = '\0';
     }

   // Field Size

   while (src[i] == ' ' || src[i] == '\t' || src[i] == '\n' || 
	  src[i] == '\r')
     {
	i ++;
     }
   
   if (src[i] == '\0')
     return;
   
   if (gd->FuncNo == FUNC_KEY || gd->FuncNo == FUNC_SUBKEY || 
       gd->FuncNo == FUNC_MODE || gd->FuncNo == FUNC_MODENB)
     {
	Deallocate();
	fprintf(stderr, 
		"KEY, SUBKEY, MODE, and MODENB do not support resizing the field.\n");
	exit(1);
     }

   j = i;
   
   while (src[i] != '\0' && src[i] != ' ' && src[i] != '\t' &&
	  src[i] != '\r' && src[i] != '\n')
     {
	i ++;
     }
   
   gd->OutFieldLen = atoi(src + j);
   
   if (gd->OutFieldLen == 0)
     {
	Deallocate();
	fprintf(stderr, "Error reading field size.\n");
	exit(1);
     }
   
   // Field Precision
   
   while (src[i] == ' ' || src[i] == '\t' || src[i] == '\n' || 
	  src[i] == '\r')
     {
	i ++;
     }
   
   if (src[i] == '\0')
     return;

   j = i;
   
   while (src[i] != '\0' && src[i] != ' ' && src[i] != '\t' &&
	  src[i] != '\r' && src[i] != '\n')
     {
	i ++;
     }
   
   gd->OutFieldPrecision = atoi(src + j);  // Could actually be zero
}
