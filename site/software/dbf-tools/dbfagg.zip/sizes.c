/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * sizes.c is a simple program to determine field sizes
 */

#include <stdio.h>

int main(void)
{
   printf("Type size checker:\n");
   printf("  char  %d\n", sizeof(char));
   printf("  short %d\n", sizeof(short));
   printf("  int   %d\n", sizeof(int));
   printf("  long  %d\n", sizeof(long));
}
