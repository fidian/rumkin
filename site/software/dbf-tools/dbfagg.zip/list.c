/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * list.c holds all of the linked list functions
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "list.h"

// returns a pointer to a pointer containing to the address.
// Creates a new element in the list if not found.
struct SortedListNode *FindKey(struct SortedListNode **head,
	       unsigned char *data, int data_len)
{
   struct SortedListNode *cur = *head, *back1 = NULL, *back2 = NULL;
   
   while (cur != NULL && memcmp(cur->Key, data, data_len))
     {
	back2 = back1;
	back1 = cur;
	cur = cur->Next;
     }
   
   if (cur == NULL)
     {
	cur = (struct SortedListNode *) 
	  calloc(sizeof(struct SortedListNode), 1);
	if (cur == NULL)
	  {
	     fprintf(stderr, "Error allocating memory.\n");
	     return NULL;
	  }
	
	cur->Key = (unsigned char *) malloc(data_len);
	if (cur->Key == NULL)
	  {
	     fprintf(stderr, "Error allocating memory.\n");
	     return NULL;
	  }
	
	memcpy(cur->Key, data, data_len);
	
	cur->Next = *head;
	*head = cur;
	
	return cur;
     }
   
   // Rearrange links
   if (back2 != NULL)
     {
	back2->Next = cur;
	back1->Next = cur->Next;
	cur->Next = back1;
     }
   else if (cur != *head)
     {
	*head = cur;
	back1->Next = cur->Next;
	cur->Next = back1;
     }

   return cur;
}
