/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * db.h holds the database-related structures and function definitions
 */

#ifndef DB_H
#define DB_H

#define BYTE_1 unsigned char
#define BYTE_2 unsigned short
#define BYTE_4 unsigned int

struct TableHeader
{
   BYTE_1 TableType;
   BYTE_1 LastUpdate[3];  // Stored as an int, but only 3 bytes (YYMMDD)
   BYTE_4 RecCount;
   BYTE_2 FirstRecPos;
   BYTE_2 RecLen;  // Including delete flag
   BYTE_1 Reserved[16];
   BYTE_1 Flags;
   BYTE_1 CodePageMark;
   BYTE_2 Reserved2;
};

struct RecordHeader
{
   char FieldName[11];  // 10 characters + 1 NULL = 11 max
   char FieldType;
   BYTE_4 FieldDisplacement;  // usually 0
   BYTE_1 FieldLen;
   BYTE_1 FieldPrecision;
   BYTE_1 Flags;
   BYTE_1 Reserved[13];
};

struct TableHeaderEnd
{
   BYTE_1 Terminator;  // 0x0D
   BYTE_1 Backlink[263];
};


FILE *OpenDatabase(char *name);
void ReadTableHeader(FILE *fp);
void PlaceField(struct RecordHeader *, int);
int InitDatabase(char *);
void SetRecordNumber(void);
int DubSubkeys(unsigned char *, unsigned int, 
	       struct SortedListNode **, unsigned int);
int DumpRecord(unsigned char *, unsigned int, struct smallgroupdef **);
int WriteNumber(double, int, int);
int WriteMode(struct SortedListNode **, int);
int IsEmpty(char *, char);
int WriteModeNB(struct SortedListNode **, int, char);
int WriteAndFree(unsigned char *, int);
void strtoupper(char *);
double ParseNumber(char *, int);

void Dump(unsigned char *, int);

#endif
