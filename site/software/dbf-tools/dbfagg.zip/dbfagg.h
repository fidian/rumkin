/* dbfagg is free software; you can redistribute it and/or modify it
 * under the terms of the GNU General Public LIcense as published by the
 * Free Software Foundataion; either version 3 of the License, or (at your
 * option) any later version.
 *
 * dbfagg is distribued in the hope that it will be useful but WITHOUT
 * ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
 * FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
 * for more details.
 *
 * The dbfagg archive has a copy of the GNU General Public License, but
 * if you did not get it, see <http://www.gnu.org/licenses/>
 *
 * dbfagg is available from http://rumkin.com/tools/dbf_tools/
 *
 * dbfagg.h holds all of the global types and data structures
 */

#ifndef DBFAGG_H
#define DBFAGG_H

#define FUNC_KEY 0
#define FUNC_SUBKEY 1
#define FUNC_MAX 2
#define FUNC_MIN 3
#define FUNC_SUM 4
#define FUNC_MODE 5
#define FUNC_MODENB 6
#define FUNC_COUNT 7
#define FUNC_AVG 8

struct groupdef 
{
   int FuncNo;
   char FieldName[11];
   int FieldStart;  // Position from beginning of record
   int FieldLen;
   int FieldPrecision;
   char OutFieldName[11];
   int OutFieldLen;
   int OutFieldPrecision;
   char FieldType;  // Hopefully a 'C' or 'N'
   struct groupdef *Next;
};

struct smallgroupdef
{
   int FuncNo;
   int FieldStart;  // Position from beginning of record
   int FieldLen;
   int FieldPrecision;
   int SourceLen;  // Length of data in source for AVG, SUM, etc.
   char FieldType;
   union 
     {
	long double Double;
	struct SortedListNode *List;
	unsigned long Long;
     } Data;
   unsigned long ExtraData;
   struct smallgroupdef *Next;
};

#ifdef DBFAGG_MAIN
#define MAYBE_EXTERN
#else
#define MAYBE_EXTERN extern
#endif

MAYBE_EXTERN struct groupdef *groupdeflist;
MAYBE_EXTERN unsigned int RecCount;
MAYBE_EXTERN unsigned int RecLen;
MAYBE_EXTERN FILE *out;
MAYBE_EXTERN unsigned long WrittenRecords;

void CloseProgram(FILE *);
void Deallocate(void);
int TestGroupdef(void);
void FreeSmallGroupDef(struct smallgroupdef *);
void FreeSortedList(struct SortedListNode *, int);
void FreeAndClose(char *, unsigned int, char *, char *, unsigned int,
		  char *, struct SortedListNode *,
		  struct smallgroupdef *, FILE *);
void ProcessData(FILE *);
unsigned int FindKeySize(int);
void BuildKey(int, unsigned char *, unsigned char *);
int CreateAggList(struct smallgroupdef **);
void AggregateRecord(unsigned char *, struct smallgroupdef **);


#endif
