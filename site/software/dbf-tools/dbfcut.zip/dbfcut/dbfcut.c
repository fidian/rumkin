#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>
#include <time.h>

#define BYTE_1 unsigned char
#define BYTE_2 unsigned short
#define BYTE_4 unsigned int


void WipeHeader(unsigned char *c)
{
   // Wipe the Last Update
   c[1] = '\0';
   c[2] = '\0';
   c[3] = '\0';
   
   // Wipe number of records
   c[4] = '\0';
   c[5] = '\0';
   c[6] = '\0';
   c[7] = '\0';
}


void SetHeader(unsigned char *c, BYTE_4 records)
{
   time_t t;
   struct tm *tm;
   
   memcpy(&(c[4]), &records, 4);
   t = time((time_t *) NULL);
   tm = localtime(&t);
   c[1] = tm->tm_year;
   c[2] = tm->tm_mon + 1;
   c[3] = tm->tm_mday;
}


void CopyRecords(FILE *outfp, gzFile *infp, BYTE_4 bytes)
{
   BYTE_4 bytes_to_read;
   unsigned char *buffer;
   
   buffer = (unsigned char *) malloc(8192);
   if (buffer == NULL)
     {
	fprintf(stderr, "Unable to allocate buffer space.\n");
	exit(4);
     }
   
   while (bytes)
     {
	bytes_to_read = bytes;
	if (bytes_to_read > 8192)
	  bytes_to_read = 8192;
	gzread(infp, buffer, bytes_to_read);
	fwrite(buffer, 8192, 1, outfp);
     }

   free(buffer);
}


int main(int argc, char **argv)
{
   gzFile *infp;
   FILE *outfp;
   int i, bytes, chunk = 0;
   BYTE_4 records = 0, records_to_write;
   BYTE_2 first_pos, record_len;
   unsigned char *header = NULL;
   BYTE_1 dbf_type;
   char filename[12];
   
   if (argc == 1)
     {
	fprintf(stderr, "Specify .dbf or .dbf.gz file to cut into chunks.\n");
	fprintf(stderr, "Resulting .dbf files have the format \"out%04d.dbf\"\n");
	return 0;
     }


   infp = gzopen(argv[1], "rb");
   if (! infp)
     {
	fprintf(stderr, "Unable to open \"%s\" for reading.\n", argv[1]);
	return 2;
     }

   // First file
   dbf_type = (BYTE_1) gzgetc(infp);
   if (dbf_type != 0x02 && dbf_type != 0x03 && dbf_type != 0x30)
     {
	fprintf(stderr, "Bad file type 0x%02X\n", dbf_type & 0xFF);
	return 3;
     }
	
   // Skip the last update
   gzgetc(infp);
   gzgetc(infp);
   gzgetc(infp);
	
   // Number of records in file
   gzread(infp, &records, 4);
	     
   // First record position
   gzread(infp, &first_pos, 2);
	     
   // Size of a record including delete flag
   gzread(infp, &record_len, 2);
	     
   // Go back to the beginning
   gzrewind(infp);
	     
   header = (unsigned char *) malloc(first_pos);
   if (! header)
     {
	fprintf(stderr, "Error allocating memory for header.\n");
	return 4;
     }
	     
   gzread(infp, header, first_pos);
   
   while (records > 0)
     {
	records_to_write = (1024 * 1024 * 1024) / record_len;
	if (records_to_write > records)
	  records_to_write = records;
	records -= records_to_write;

	sprintf(filename, "out%02d.dbf", chunk ++);
	outfp = fopen(filename, "wb");
	SetHeader(header, records_to_write);
	CopyRecords(outfp, infp, records_to_write * record_len);
	fclose(outfp);
     }
   
   free(header);
   
   return 0;
}

