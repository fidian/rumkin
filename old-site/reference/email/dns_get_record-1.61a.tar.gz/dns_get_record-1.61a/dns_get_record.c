/* This is a backport of the prospective PHP5 function "dns_get_record()" 
   to PHP4. This code is covered by the PHP license, please see "LICENSE".
   Backport done by Alexander Mayrhofer <axelm-php@nona.net>, please see
   http://nona.net/software/dns_get_record/ for latest version            */

/*
   +----------------------------------------------------------------------+
   | PHP Version 4                                                        |
   +----------------------------------------------------------------------+
   | Copyright (c) 1997-2003 The PHP Group                                |
   +----------------------------------------------------------------------+
   | This source file is subject to version 3.0 of the PHP license,       |
   | that is bundled with this package in the file LICENSE, and is        |
   | available at through the world-wide-web at                           |
   | http://www.php.net/license/3_0.txt.                                  |
   | If you did not receive a copy of the PHP license and are unable to   |
   | obtain it through the world-wide-web, please send a note to          |
   | license@php.net so we can mail you a copy immediately.               |
   +----------------------------------------------------------------------+
   | Authors: The typical suspects                                        |
   |          Pollita <pollita@php.net>                                   |
   |          Marcus Boerger <helly@php.net>                              |
   +----------------------------------------------------------------------+
 */

/* $Id: dns_get_record.c,v 1.3 2003/07/24 08:53:42 axelm Exp $ */

/* {{{ includes */
#include "php.h"

#if HAVE_SYS_SOCKET_H
#include <sys/socket.h>
#endif

#ifdef PHP_WIN32
#if HAVE_LIBBIND
#ifndef WINNT
#define WINNT 1
#endif
/* located in www.php.net/extra/bindlib.zip */
#if HAVE_ARPA_INET_H 
#include "arpa/inet.h"
#endif
#include "netdb.h"
#if HAVE_ARPA_NAMESERV_H
#include "arpa/nameser.h"
#endif
#if HAVE_RESOLV_H
#include "resolv.h"
#endif
#endif /* HAVE_LIBBIND */
#include <winsock2.h>
#else	/* This holds good for NetWare too, both for Winsock and Berkeley sockets */
#include <netinet/in.h>
#if HAVE_ARPA_INET_H
#include <arpa/inet.h>
#endif
#include <netdb.h>
#ifdef _OSD_POSIX
#undef STATUS
#undef T_UNSPEC
#endif
#if HAVE_ARPA_NAMESER_H
#include <arpa/nameser.h>
#endif
#if HAVE_RESOLV_H
#include <resolv.h>
#endif
#endif

/* Borrowed from SYS/SOCKET.H */
#if defined(NETWARE) && defined(USE_WINSOCK)
#define AF_INET 2   /* internetwork: UDP, TCP, etc. */
#endif

#include "dns.h"
/* }}} */

#define HAVE_DNS_FUNCS 1


#if HAVE_DNS_FUNCS

#define PHP_DNS_NUM_TYPES	11	/* Number of DNS Types Supported by PHP currently */

#define PHP_DNS_A      0x00000001
#define PHP_DNS_NS     0x00000002
#define PHP_DNS_CNAME  0x00000010
#define PHP_DNS_SOA    0x00000020
#define PHP_DNS_PTR    0x00000800
#define PHP_DNS_HINFO  0x00001000
#define PHP_DNS_MX     0x00004000
#define PHP_DNS_TXT    0x00008000
#define PHP_DNS_SRV    0x02000000
#define PHP_DNS_NAPTR  0x04000000    
#define PHP_DNS_AAAA   0x08000000
#define PHP_DNS_ANY    0x10000000
#define PHP_DNS_ALL    (PHP_DNS_A|PHP_DNS_NS|PHP_DNS_CNAME|PHP_DNS_SOA|PHP_DNS_PTR|PHP_DNS_HINFO|PHP_DNS_MX|PHP_DNS_TXT|PHP_DNS_SRV|PHP_DNS_NAPTR|PHP_DNS_AAAA)

PHP_MINIT_FUNCTION(dns_get_record) {
	REGISTER_LONG_CONSTANT("DNS_A",     PHP_DNS_A,     CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_NS",    PHP_DNS_NS,    CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_CNAME", PHP_DNS_CNAME, CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_SOA",   PHP_DNS_SOA,   CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_PTR",   PHP_DNS_PTR,   CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_HINFO", PHP_DNS_HINFO, CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_MX",    PHP_DNS_MX,    CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_TXT",   PHP_DNS_TXT,   CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_SRV",   PHP_DNS_SRV,   CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_NAPTR", PHP_DNS_NAPTR, CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_AAAA",  PHP_DNS_AAAA,  CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_ANY",   PHP_DNS_ANY,   CONST_CS | CONST_PERSISTENT);
	REGISTER_LONG_CONSTANT("DNS_ALL",   PHP_DNS_ALL,   CONST_CS | CONST_PERSISTENT);
	return SUCCESS;
}

#ifndef HFIXEDSZ
#define HFIXEDSZ        12      /* fixed data in header <arpa/nameser.h> */
#endif /* HFIXEDSZ */

#ifndef QFIXEDSZ
#define QFIXEDSZ        4       /* fixed data in query <arpa/nameser.h> */
#endif /* QFIXEDSZ */

#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN  256
#endif /* MAXHOSTNAMELEN */

#ifndef MAXRESOURCERECORDS
#define MAXRESOURCERECORDS	64
#endif /* MAXRESOURCERECORDS */

typedef union {
	HEADER qb1;
	u_char qb2[65536];
} querybuf;

/* declaration of functions to be exported */
ZEND_FUNCTION(dns_get_record);

/* compiled function list so Zend knows what's in this module */
zend_function_entry dns_get_record_functions[] =
{
    ZEND_FE(dns_get_record, NULL)
    {NULL, NULL, NULL}
};

/* compiled module information */
zend_module_entry dns_get_record_module_entry = {
    STANDARD_MODULE_HEADER,
    "dns_get_record backport",      /* extension name */
    dns_get_record_functions,  /* extension function list */
    PHP_MINIT(dns_get_record), 		/* extension-wide startup function */
    NULL,               /* extension-wide shutdown function */
    NULL,               /* per-request startup function */
    NULL,               /* per-request shutdown function */
    NULL,               /* information function */
    "1.59",              /* extension version number (string) */
    STANDARD_MODULE_PROPERTIES
};

/* implement standard "stub" routine to introduce ourselves to Zend */
ZEND_GET_MODULE(dns_get_record)

/* {{{ proto array|false dns_get_record(string hostname [, int type[, array authns, array addtl]])
   Get any Resource Record corresponding to a given Internet host name */
PHP_FUNCTION(dns_get_record)
{
	zval *subarray[MAXRESOURCERECORDS];
	pval *addtl, *host, *authns, *fetch_type;
	int addtl_recs = 0;
	int type_to_fetch, type_param = PHP_DNS_ANY;
	int current_subarray = 0;
	struct __res_state res;
	HEADER *hp;
	querybuf buf, answer, *ans;
	u_char *cp = NULL, *end = NULL;
	long n, qd, an, ns = 0, ar = 0;
	int type, first_query = 1, store_results = 1;

	switch (ZEND_NUM_ARGS()) {
		case 1:
			if (zend_get_parameters(ht, 1, &host) == FAILURE) {
				WRONG_PARAM_COUNT;
			}
			break;
		case 2:
			if (zend_get_parameters(ht, 2, &host, &fetch_type) == FAILURE) {
				WRONG_PARAM_COUNT;
			}
			type_param = Z_LVAL_P(fetch_type);
			break;
		case 4:
			if (zend_get_parameters(ht, 4, &host, &fetch_type, &authns, &addtl) == FAILURE) {
				WRONG_PARAM_COUNT;
			}
			type_param = Z_LVAL_P(fetch_type);
			pval_destructor(authns);
			addtl_recs = 1;		/* We want the additional Records */
			array_init(authns);
			pval_destructor(addtl);
			array_init(addtl);
			break;
		default:
			WRONG_PARAM_COUNT;
	}
	
	convert_to_string(host);

	if (type_param&~PHP_DNS_ALL && type_param!=PHP_DNS_ANY) {
		php_error(E_WARNING, "Type '%d' not supported", type_param);
		RETURN_FALSE;
	}

	/* Initialize the return array */
	array_init(return_value);

	/* - We emulate an or'ed type mask by querying type by type. (Steps 0 - NUMTYPES-1 )
	 *   If additional info is wanted we check again with T_ANY (step NUMTYPES / NUMTYPES+1 )
	 *   store_results is used to skip storing the results retrieved in step
	 *   NUMTYPES+1 when results were already fetched.
	 * - In case of PHP_DNS_ANY we use the directly fetch T_ANY. (step NUMTYPES+1 )
	 */
	for(type = (type_param==PHP_DNS_ANY ? (PHP_DNS_NUM_TYPES + 1) : 0); type < (addtl_recs ? (PHP_DNS_NUM_TYPES + 2) : PHP_DNS_NUM_TYPES) || first_query; type++)
	{
		first_query = 0;
		switch(type) {
			case 0: 
				type_to_fetch = type_param&PHP_DNS_A     ? T_A     : 0;
				break;
			case 1: 
				type_to_fetch = type_param&PHP_DNS_NS    ? T_NS    : 0;
				break;
			case 2: 
				type_to_fetch = type_param&PHP_DNS_CNAME ? T_CNAME : 0;
				break;
			case 3: 
				type_to_fetch = type_param&PHP_DNS_SOA   ? T_SOA   : 0;
				break;
			case 4: 
				type_to_fetch = type_param&PHP_DNS_PTR   ? T_PTR   : 0;
				break;
			case 5: 
				type_to_fetch = type_param&PHP_DNS_HINFO ? T_HINFO : 0;
				break;
			case 6: 
				type_to_fetch = type_param&PHP_DNS_MX    ? T_MX    : 0;
				break;
			case 7: 
				type_to_fetch = type_param&PHP_DNS_TXT   ? T_TXT   : 0;
				break;
			case 8:
#ifdef T_AAAA
				type_to_fetch = type_param&PHP_DNS_AAAA	 ? T_AAAA  : 0;
				break;
#else
				continue;
#endif
			case 9:
#ifdef T_SRV
				type_to_fetch = type_param&PHP_DNS_SRV   ? T_SRV   : 0;
				break;
#else
				continue;
#endif
			case 10:
#ifdef T_NAPTR
				type_to_fetch = type_param&PHP_DNS_NAPTR ? T_NAPTR : 0;
				break;
#else
				continue;
#endif

			case PHP_DNS_NUM_TYPES:
				store_results = 0;
				continue;
			default:
			case (PHP_DNS_NUM_TYPES + 1):
				type_to_fetch = T_ANY;
				break;
		}
		if (type_to_fetch) {
			res_ninit(&res);
			res.retrans = 5;
			res.options &= ~RES_DEFNAMES;
		
			n = res_nmkquery(&res, QUERY, Z_STRVAL_P(host), C_IN, type_to_fetch, NULL, 0, NULL, buf.qb2, sizeof buf);
			if (n<0) {
				php_error(E_WARNING, "res_nmkquery() failed");
				zval_dtor(return_value);
				RETURN_FALSE;
			}
			n = res_nsend(&res, buf.qb2, n, answer.qb2, sizeof answer);
			if (n<0) {
				php_error(E_WARNING, "res_nsend() failed");
				zval_dtor(return_value);
				RETURN_FALSE;
			}
		
			cp = answer.qb2 + HFIXEDSZ;
			end = answer.qb2 + n;
			ans = &answer;
			hp = (HEADER *)ans;
			qd = ntohs(hp->qdcount);
			an = ntohs(hp->ancount);
			ns = ntohs(hp->nscount);
			ar = ntohs(hp->arcount);
		
			/* Skip QD entries, they're only used by dn_expand later on */
			while (qd-- > 0) {
				n = dn_skipname(cp, end);
				if (n < 0) {
					php_error(E_WARNING, "Unable to parse DNS data received");
					zval_dtor(return_value);
					RETURN_FALSE;
				}
				cp += n + QFIXEDSZ;
			}
		
			/* YAY! Our real answers! */
			while (an-- && cp && cp < end) {
				cp = php_parserr(cp, &answer, type_to_fetch, store_results, &subarray[current_subarray]);
				if (subarray[current_subarray] != NULL && store_results)
					zend_hash_next_index_insert(HASH_OF(return_value), (void *)&subarray[current_subarray], sizeof(zval *), NULL);
				current_subarray++;
			}
			res_nclose(&res);
		}
	}

	if (addtl_recs) {
		/* List of Authoritative Name Servers */
		while (ns-- > 0 && cp && cp < end) {
			cp = php_parserr(cp, &answer, T_ANY, 1, &subarray[current_subarray]);
			if (subarray[current_subarray] != NULL)
				zend_hash_next_index_insert(HASH_OF(authns), (void *)&subarray[current_subarray], sizeof(zval *), NULL);
			current_subarray++;
		}
		/* Additional records associated with authoritative name servers */
		while (ar-- > 0 && cp && cp < end) {
			cp = php_parserr(cp, &answer, T_ANY, 1, &subarray[current_subarray]);
			if (subarray[current_subarray] != NULL)
				zend_hash_next_index_insert(HASH_OF(addtl), (void *)&subarray[current_subarray], sizeof(zval *), NULL);
			current_subarray++;
		}
	}
}
/* }}} */

/* {{{ php_parserr */
static u_char *php_parserr(u_char *cp, querybuf *answer, int type_to_fetch, int store, zval **subarray) {
	u_short type, class, dlen;
	u_long ttl;
	long n, i;
	u_short s;
	u_char *tp;
	char name[MAXHOSTNAMELEN];

	n = dn_expand(answer->qb2, answer->qb2+65536, cp, name, (sizeof(name)) - 2);
	if (n < 0) {
		return NULL;
	}
	cp += n;
	
	GETSHORT(type, cp);
	GETSHORT(class, cp);
	GETLONG(ttl, cp);
	GETSHORT(dlen, cp);
	if (type_to_fetch != T_ANY && type != type_to_fetch) {
		*subarray = NULL;
		cp += dlen;
		return cp;
	}

	if (!store) {
		*subarray = NULL;
		cp += dlen;
		return cp;
	}

	MAKE_STD_ZVAL(*subarray);
	array_init(*subarray);

	add_assoc_string(*subarray, "host", name, 1);
	switch (type) {
		case T_A:
			add_assoc_string(*subarray, "type", "A", 1);
			sprintf(name, "%d.%d.%d.%d", cp[0], cp[1], cp[2], cp[3]);
			add_assoc_string(*subarray, "ip", name, 1);
			cp += dlen;
			break;
		case T_MX:
			add_assoc_string(*subarray, "type", "MX", 1);
			GETSHORT(n, cp);
			add_assoc_long(*subarray, "pri", n);
			/* no break; */
		case T_CNAME:
			if (type == T_CNAME)
				add_assoc_string(*subarray, "type", "CNAME", 1);
			/* no break; */
		case T_NS:
			if (type == T_NS)
				add_assoc_string(*subarray, "type", "NS", 1);
			/* no break; */
		case T_PTR:
			if (type == T_PTR)
				add_assoc_string(*subarray, "type", "PTR", 1);
			n = dn_expand(answer->qb2, answer->qb2+65536, cp, name, (sizeof name) - 2);
			if (n < 0) {
				return NULL;
			}
			cp += n;
			add_assoc_string(*subarray, "target", name, 1);
			break;
		case T_HINFO:
			/* See RFC 1010 for values */
			add_assoc_string(*subarray, "type", "HINFO", 1);
			n = *cp & 0xFF;
			cp++;
			add_assoc_stringl(*subarray, "cpu", cp, n, 1);
			cp += n;
			n = *cp & 0xFF;
			cp++;
			add_assoc_stringl(*subarray, "os", cp, n, 1);
			cp += n;
			break;
		case T_TXT:
			add_assoc_string(*subarray, "type", "TXT", 1);
			n = cp[0]; 
			for(i=1; i<=n; i++)
				name[i-1] = cp[i];
			name[i-1] = '\0';
			cp += dlen;
			add_assoc_string(*subarray, "txt", name, 1);
			break;
		case T_SOA:
			add_assoc_string(*subarray, "type", "SOA", 1);
			n = dn_expand(answer->qb2, answer->qb2+65536, cp, name, (sizeof name) -2);
			if (n < 0) {
				return NULL;
			}
			cp += n;
			add_assoc_string(*subarray, "mname", name, 1);
			n = dn_expand(answer->qb2, answer->qb2+65536, cp, name, (sizeof name) -2);
			if (n < 0) {
				return NULL;
			}
			cp += n;
			add_assoc_string(*subarray, "rname", name, 1);
			GETLONG(n, cp);
			add_assoc_long(*subarray, "serial", n);
			GETLONG(n, cp);
			add_assoc_long(*subarray, "refresh", n);
			GETLONG(n, cp);
			add_assoc_long(*subarray, "retry", n);
			GETLONG(n, cp);
			add_assoc_long(*subarray, "expire", n);
			GETLONG(n, cp);
			add_assoc_long(*subarray, "minimum-ttl", n);
			break;

#ifdef T_AAAA
		case T_AAAA:
			tp = name;
			for(i=0; i < 8; i++) {
				GETSHORT(s, cp);
				if (s > 0) {
					if (tp > (u_char *)name) {
						tp[0] = ':';
						tp++;
					}
					sprintf(tp,"%x",s);
					tp += strlen(tp);
				} else if (s == 0) {
					if ((tp > (u_char *)name) && (tp[-1] != ':')) {
						tp[0] = ':';
						tp++;
					}
				}
			}
			if ((tp > (u_char *)name) && (tp[-1] == ':'))
				tp[-1] = '\0';
			tp[0] = '\0';
			add_assoc_string(*subarray, "type", "AAAA", 1);
			add_assoc_string(*subarray, "ipv6", name, 1);
			break;
#endif
#ifdef T_SRV
		case T_SRV:
			add_assoc_string(*subarray, "type", "SRV", 1);
			GETSHORT(n, cp);
			add_assoc_long(*subarray, "pri", n);
			GETSHORT(n, cp);
			add_assoc_long(*subarray, "weight", n);
			GETSHORT(n, cp);
			add_assoc_long(*subarray, "port", n);
			n = dn_expand(answer->qb2, answer->qb2+65536, cp, name, (sizeof name) - 2);
			if (n < 0) {
				return NULL;
			}
			cp += n;
			add_assoc_string(*subarray, "target", name, 1);
			break;
#endif
#ifdef T_NAPTR
		case T_NAPTR:
			add_assoc_string(*subarray, "type", "NAPTR", 1);
			GETSHORT(n, cp);
			add_assoc_long(*subarray, "order", n);
			GETSHORT(n, cp);
			add_assoc_long(*subarray, "pref", n);
			n = (cp[0] & 0xFF);
			add_assoc_stringl(*subarray, "flags", ++cp, n, 1);
			cp += n;
			n = (cp[0] & 0xFF);
			add_assoc_stringl(*subarray, "services", ++cp, n, 1);
			cp += n;
			n = (cp[0] & 0xFF);
			add_assoc_stringl(*subarray, "regex", ++cp, n, 1);
			cp += n;
			n = dn_expand(answer->qb2, answer->qb2+65536, cp, name, (sizeof name) - 2);
			if (n < 0) {
				return NULL;
			}
			cp += n;
			add_assoc_string(*subarray, "replacement", name, 1);
			break;
#endif
		default:
			cp += dlen;
	}

	add_assoc_string(*subarray, "class", "IN", 1);
	add_assoc_long(*subarray, "ttl", ttl);

	return cp;
}
/* }}} */
#endif /* HAVE_DNS_FUNCS */

