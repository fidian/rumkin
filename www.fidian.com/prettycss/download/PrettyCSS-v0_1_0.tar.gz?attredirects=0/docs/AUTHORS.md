Tyler Akins <fidian@rumkin.com> - Main contributor
