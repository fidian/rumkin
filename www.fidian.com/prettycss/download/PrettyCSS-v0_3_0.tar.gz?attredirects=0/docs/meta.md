All documentation is using the "markdown" syntax as much as possible.
http://daringfireball.net/projects/markdown/syntax has a good run-down of
the markdown syntax and what it supports.

There is a nice package.json cheat sheet at http://package.json.nodejitsu.com/
and more documentation from the "npm help json" command.
