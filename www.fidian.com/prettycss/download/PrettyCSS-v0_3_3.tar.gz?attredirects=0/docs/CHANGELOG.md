v0.3.2
======

* Use OptionParser for command line program's options
* Bugfix - fixing newlines in comments being reindented

v0.3.1
======

* Bugfix - some properties need to be case sensitive

v0.3.0
======

* Added many more tests - now to a good spot with tests

v0.2.0
======

* Added live HTML view
* Parsing values and validating that the property's value seems correct
* Added many tests, but not complete coverage of anything

v0.1.0
======

* Can tokenize CSS
* Can parse tokens into CSS objects
* Has tests for each of the CSS objects and for the tokenizer
* A couple scripts that are useful for testing changes
* Initial stab at documentation
* Web-based textarea test page with live updates
* Error detection for formats that are invalid
* Manages all whitespace and works as a beautifier
