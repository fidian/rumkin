<?PHP
/* Sprint File Uploader
 *
 * Copyright (C) 2003-2005 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for legal information
 * See http://rumkin.com/tools/sprint/ for more information about these tools
 */

$GLOBALS['Force Clean'] = 1;

echo "<pre>";

chdir('..');
include 'common.inc';

?>
	
Database cleaned.
