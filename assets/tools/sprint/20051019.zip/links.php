<?PHP
/* Sprint File Uploader
 *
 * Copyright (C) 2003-2005 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for legal information
 * See http://rumkin.com/tools/sprint/ for more information about these tools
 */

require 'common.inc';

SprintStandardHeader('Phone Links');


Section('Ringers, Wallpapers, and Other Phone Files');

$Links = array(
   array('Name' => 'Craig Given',
         'Desc' => 'Very clean site with ringtones, apps, and images.  ' .
	           'There is also a very nice FAQ available that will ' .
		   'answer many questions about using your phone and ' .
		   'getting more things onto it.',
	 'URL' => 'http://www.craiggiven.com/pcs.htm'),
   array('Name' => 'fonpirate',
	 'Desc' => 'Browse this site with your phone to get images, ' .
	           'ringers, and programs.',
         'URL' => 'http://www.fonpirate.com/'),
   array('Name' => 'Fresh MIDIs',
	 'Desc' => 'Popular songs that are in MIDI format, ready for your ' .
	           'phone.',
	 'URL' => 'http://freshmidis.co.nr/'),
   array('Name' => 'MBuzzy',
         'Desc' => 'Free ringtones, apps, and images.  Lots of content.',
	 'URL' => 'http://mbuzzy.com/'),
   array('Name' => 'Midi Freak',
	 'Desc' => 'Free MIDI songs, ringtones, and other things you ' .
	           'can upload to your phone.',
	 'URL' => 'http://www.midifreak.net/Midi.html'),
   array('Name' => 'Midlet.org',
         'Desc' => 'Java based games for mobile phones.',
	 'URL' => 'http://midlet.org/'),
   array('Name' => 'MyPhoneFiles',
	 'Desc' => 'Ringers, wallpapers, and more.',
	 'URL' => 'http://www.myphonefiles.com/'),
   array('Name' => 'phoneART',
	 'Desc' => 'Collection of wallpapers and ringers for you to ' .
	    'download.  You can also leave a comment in the guestbook ' .
	    'to request something special.',
	 'URL' => 'http://www.phoneart.net'),
   array('Name' => 'Ring Cities',
	 'Desc' => 'Forum site where you can get ringers, games, and ' .
	    'other downloads.',
         'URL' => 'http://ringcities.com/'),
);

MakeLinkList($Links);

Section('<a name="uploaders">Other Uploaders</a>');

$Links = array(
   array('Name' => 'BitPim',
	 'Desc' => 'Runs on your local computer and talks to your phone ' .
	           'through a special USB cable.  Freeware, but you do ' .
	           'need to go out and buy a cable.',
	 'URL' => 'http://bitpim.sourceforge.net/'),
   array('Name' => 'gtoal.com',
         'Desc' => 'An earlier version of my uploader.',
	 'URL' => 'http://www.gtoal.com/pcs/'),
   array('Name' => 'Knuckledragger.net',
         'Desc' => 'Another older copy of my uploader.  Seems like this ' .
	           'free stuff is quite popular.',
	 'URL' => 'http://www.knuckledragger.net/sprintpcsuploads.htm'),
   array('Name' => 'PCS.Cruz-Network.net',
	 'Desc' => 'Same uploader as here, but looks better.',
	 'URL' => 'http://pcs.cruz-network.net/'),
   array('Name' => 'PCSpix',
         'Desc' => 'Lets you upload files to your phone after ' .
                   'registering.  Not sure what uploader software they use.',
	 'URL' => 'http://pcspix.com/index.html'),
   array('Name' => 'Pix2Fone',
	 'Desc' => 'Alternate site that will let you send images to your ' .
	           'phone.',
	 'URL' => 'http://www.pix2fone.com/'),
   array('Name' => 'ThePhoneMall.net',
	 'Desc' => 'My uploader that has been spruced up quite a bit.',
	 'URL' => 'http://upload.thephonemall.net/'),
   array('Name' => 'SprintUsers.com',
         'Desc' => 'Their own software that will send files to your ' .
	           'phone.  They stole large portions of my FAQ and ' .
		   'regurgitated it in their own FAQ.  Thanks for the ' .
		   'lack of credit.',
	 'URL' => 'http://www.sprintusers.com/focus/'),
   array('Name' => 'Stellnernet.com',
	 'Desc' => 'Recently set up and would like users to visit his site.',
	 'URL' => 'http://www.phoneuploader.stellernet.com/'),
   array('Name' => 'T1mmy.net',
         'Desc' => 'An independantly written piece of software that does ' .
	           'a very good job of sending files.',
         'URL' => 'http://www.t1mmy.net/visionTool.html'),
   array('Name' => 'Vorpal Cloud',
	 'Desc' => 'Same uploader as me, but themed to go with their site.',
	 'URL' => 'http://www.vorpalcloud.org/tools/pcsuploader/'),
);	       

MakeLinkList($Links);

Section('<a name=info>Informational Sites and Online Converters</a>');

$Links = array(
   array('Name' => 'CMX FAQ',
	 'Desc' => 'Some information about the CMX format.',
	 'URL' => 'http://www.cdmatech.com/solutions/pdf/cmx_faq.pdf'),
   array('Name' => 'Dreampages',
	 'Desc' => 'A site that lists many other Sprint-related sites.',
	 'URL' => 'http://www.dreampages.com/dir/Content/'),
   array('Name' => 'How to make PMD files from animated GIFs',
	 'Desc' => 'A step-by-step  document with lots of nice ' .
	           'pictures.',
         'URL' => 'http://www.3gupload.com/ringtones/module/Forum/action/FlatTopic/fid/12/tid/141'),
   array('Name' => 'Online Image Converter',
	 'Desc' => 'Change your bmp, png, gif, or jpeg images into another ' .
	           'type.',
	 'URL' => 'http://www.thedreaming.com/Code/PHP/OIC/'),
   array('Name' => 'Samsung A660 Information',
         'Desc' => 'How to get files on your phone, games that work, ' .
	           'setting it up as a modem for your computer, and ' .
		   'lots of other information.',
	 'URL' => 'http://members.lycos.co.uk/jab5915/samsung.html'),
   array('Name' => 'Screen Sizes',
	 'Desc' => 'A list of screen sizes so you can resize images ' .
	           'to fit your phone before you upload them.',
	 'URL' => 'http://forum.sprintusers.com/showthread.php?s=&threadid=37433'),
   array('Name' => 'SprintUsers',
         'Desc' => 'This is their section for Sprint Vision PCS users.  ' .
	           'It contains links to many other worthwhile sites.',
	 'URL' => 'http://www.sprintusers.com/links/links-visioncontent.php'),
   array('Name' => 'WAP Universal Resource File',
	 'Desc' => 'Look up phone information based on model, make, ' .
	    'or user agent string.',
	 'URL' => 'http://www.thewirelessfaq.com/all.asp'),
);

MakeLinkList($Links);

Section('Uploading and Related Software');

$Links = array(
   array('Name' => 'BlurredVision',
         'Desc' => 'PHP toolkit to upload files to your PCS phone.  Still ' .
	           'in early development stages.',
	 'URL' => 'http://sourceforge.net/projects/blurredvision'),
   array('Name' => 'messaging.inc',
	 'Desc' => 'PHP function to send a SMS via Sprint\'s web site.  ' .
	           'It works better than using email to send messages.',
	 'URL' => 'messaging.inc'),
   array('Name' => 'MiniSendNote',
	 'Desc' => 'Tiny program to send messages from a Sprint phone ' . 
	           'without forcing you to use thier annoying WAP system.',
	 'URL' => 'http://www.apgap.com/minisendnote.php'),
   array('Name' => 'My Uploader',
	 'Desc' => 'The code that runs this site.  Not to be humble, but ' .
	           'it has all of the awesome features I can think of.  ' .
		   'Automatic image resizing, phone detection, and ' .
		   'tons more.  Oh, it\'s freeware (open source).  Yeah, ' .
	           'I know, that wasn\'t humble at all.',
	 'URL' => 'downloads.php'),
   array('Name' => 'PCS Vision Uploader',
	 'Desc' => 'Appears to be effectively the same thing as what I ' .
	           'wrote, but developed independently.',
	 'URL' => 'http://osx.freshmeat.net/projects/pcsvisionuploader/'),
   array('Name' => 'Text Messenger',
	 'Desc' => 'Palm OS program to send a Sprint user a message.',
	 'URL' => 'http://i500.nopdesign.com/apps.esiml'),
);	       

MakeLinkList($Links);

StandardFooter();
