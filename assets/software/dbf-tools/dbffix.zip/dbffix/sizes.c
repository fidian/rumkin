#include <stdio.h>

int main(void)
{
   printf("Type size checker:\n");
   printf("  char  %d\n", sizeof(char));
   printf("  short %d\n", sizeof(short));
   printf("  int   %d\n", sizeof(int));
   printf("  long  %d\n", sizeof(long));
}
