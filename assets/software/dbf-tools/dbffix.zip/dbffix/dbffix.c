#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define BYTE_1 unsigned char
#define BYTE_2 unsigned short
#define BYTE_4 unsigned int


int main(int argc, char **argv)
{
   FILE *fp;
   BYTE_1 dbf_type;
   BYTE_4 records, counted_records;
   BYTE_2 first_pos, record_len;
   unsigned char *buffer;
   
   int i, bytes, chunk = 0;
   BYTE_4 records_to_write;
   unsigned char *header = NULL;
   char filename[12];
   
   if (argc == 1)
     {
	fprintf(stderr, "Specify .dbf file to fix the header.\n");
	return 0;
     }


   fp = fopen(argv[1], "ab+");
   if (! fp)
     {
	fprintf(stderr, "Unable to open \"%s\" for reading.\n", argv[1]);
	return 2;
     }
   fseek(fp, 0, SEEK_SET);

   dbf_type = (BYTE_1) fgetc(fp);
   if (dbf_type != 0x02 && dbf_type != 0x03 && dbf_type != 0x30)
     {
	fprintf(stderr, "Bad file type 0x%02X\n", dbf_type & 0xFF);
	return 3;
     }
	
   // Skip the last update
   fgetc(fp);
   fgetc(fp);
   fgetc(fp);
	
   // Number of records in file
   fread(&records, sizeof(BYTE_4), 1, fp);
	     
   // First record position
   fread(&first_pos, sizeof(BYTE_2), 1, fp);
	     
   // Size of a record including delete flag
   fread(&record_len, sizeof(BYTE_2), 1, fp);
	     
   // Jump to start of data
   fseek(fp, first_pos, SEEK_SET);

   buffer = (unsigned char *) malloc(record_len);
   if (! buffer)
     {
	fprintf(stderr, "Error allocating memory for buffer.\n");
	return 2;
     }
   
   counted_records = 0;
   while (! feof(fp))
     {
	if (fread(buffer, 1, record_len, fp) == record_len)
	  {
	     counted_records ++;
	  }
     }
   
   if (counted_records == records)
     {
	printf("Record count matches the header.\n");
     }
   else
     {
	printf("Record count does not match - updating header.\n");
	fseek(fp, 4, SEEK_SET);
	fwrite(&counted_records, 4, 1, fp);
     }

   fclose(fp);
   
   return 0;
}

