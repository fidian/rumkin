/* D&D Helper - Turning Undead (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

/* TurnEventHandler
 * 
 * Handles events on the Turning Undead form.
 */
Boolean TurnEventHandler(EventPtr event);
