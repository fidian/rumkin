/* D&D Helper - Movement Calculator
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */


#include <PalmOS.h>	// Pilot functions
#include "dnd_helper.h"	// The ID numbers for everything
#include "input.h"
#include "misc.h"
#include "movement.h"
#include "prefs.h"

// These arrays correspond to the different things in the .rcp file
// Values in here have been multiplied by 100 (fixed precision of 2)
unsigned short Movement_Speed_L [] = { 100, 200, 300, 400 };
unsigned short Movement_Obstructions_L [] = { 100, 75, 50 };
unsigned short Movement_Surface_L [] = { 100, 75, 50 };
unsigned short Movement_Visibility_L [] = { 100, 50 };
// This one is special -- roads are not allowed on deserts
// Terrain is the first index, path is the second (just like the book)
unsigned short Movement_PathTerrain_L [][3] = 
{ 
   { 100, 100, 100 },  // Plains
   { 100, 100, 75 },  // Scrub, rough
   { 100, 100, 50 },  // Forest
   { 100, 75, 25 },  // Jungle
   { 100, 75, 50 },  // Swamp
   { 100, 75, 50 },  // Hills
   { 75, 50, 25 },  // Mountains
   { 100, 0, 50 },  // Sandy Desert
};

unsigned long Movement_Hours, Movement_Minutes, Movement_Seconds,
  Movement_Miles, Movement_Feet;
Boolean Movement_Hours_Updated, Movement_Minutes_Updated,
  Movement_Seconds_Updated, Movement_Miles_Updated, Movement_Feet_Updated, 
  Movement_Rounds_Updated, Movement_Rate_Updated, Movement_Popup_Updated;


unsigned short Movement_EffectiveMovementRate() 
{
   float Modifier;
   
   Modifier = (float) Movement_Speed_L[Prefs->Movement_Speed] / (float) 100;
   Modifier *= (float) Movement_Obstructions_L[Prefs->Movement_Obstructions] /
     (float) 100;
   Modifier *= (float) Movement_Surface_L[Prefs->Movement_Surface] /
     (float) 100;
   Modifier *= (float) Movement_Visibility_L[Prefs->Movement_Visibility] /
     (float) 100;
   Modifier *= (float)
     Movement_PathTerrain_L[Prefs->Movement_Terrain][Prefs->Movement_Path] /
     (float) 100;
   Modifier *= (float) Prefs->Movement_Rate;
   
   return (unsigned short) Modifier;
}


void Movement_UpdateNumbers(Boolean init)
{
   Boolean Recalc_MilesFeet = false;
   Boolean Recalc_HoursMinutesSeconds = false;
   
   if (init) 
     {
	Movement_Seconds = (Prefs->Movement_Rounds % 10) * 6;
	Movement_Hours = Prefs->Movement_Rounds / 600;
	Movement_Minutes = (Prefs->Movement_Rounds % 600) / 10;
	Movement_Feet = (unsigned long) Movement_EffectiveMovementRate() * 
	  (unsigned long) Prefs->Movement_Rounds;
        Movement_Miles = Movement_Feet / 5280;
	Movement_Feet = Movement_Feet % 5280;
	Movement_Hours_Updated = false;
	Movement_Minutes_Updated = false;
	Movement_Seconds_Updated = false;
	Movement_Miles_Updated = false;
	Movement_Feet_Updated = false;
	Movement_Rounds_Updated = false;
	Movement_Rate_Updated = false;
     }
   else
     {
	if (Movement_Rate_Updated || Movement_Popup_Updated)
	  {
	     Movement_Rate_Updated = false;
	     Movement_Popup_Updated = false;
	     Recalc_MilesFeet = true;
	     Recalc_HoursMinutesSeconds = true;
	  }
	if (Movement_Hours_Updated || Movement_Minutes_Updated ||
	    Movement_Seconds_Updated)
	  {
	     Movement_Hours_Updated = false;
	     Movement_Minutes_Updated = false;
	     Movement_Seconds_Updated = false;
	     Recalc_MilesFeet = true;
	     Prefs->Movement_Rounds = (Movement_Seconds / 6) +
	       ((unsigned int) Movement_Minutes * 10) + 
	       ((unsigned int) Movement_Hours * 600);
	  }
	if (Movement_Miles_Updated || Movement_Feet_Updated)
	  {
	     Movement_Miles_Updated = false;
	     Movement_Feet_Updated = false;
	     Recalc_HoursMinutesSeconds = true;
	     if (Prefs->Movement_Rate > 0)
	       Prefs->Movement_Rounds = ((unsigned long) Movement_Miles * 
					 (unsigned long) 5280 + 
					 (unsigned long) Movement_Feet) /
	       (unsigned long) Prefs->Movement_Rate;
	     else
	       {
		  Movement_Miles = 0;
		  Movement_Feet = 0;
	       }
	  }
	if (Movement_Rounds_Updated)
	  {
	     Movement_Rounds_Updated = false;
	     Recalc_MilesFeet = true;
	     Recalc_HoursMinutesSeconds = true;
	  }
	
	if (Recalc_HoursMinutesSeconds)
	  {
	     Movement_Seconds = (Prefs->Movement_Rounds % 10) * 6;
	       Movement_Hours = Prefs->Movement_Rounds / 600;
	     Movement_Minutes = (Prefs->Movement_Rounds % 600) / 10;
	  }
	if (Recalc_MilesFeet)
	  {
	     Movement_Feet = Movement_EffectiveMovementRate() * 
	       Prefs->Movement_Rounds;
	     Movement_Miles = Movement_Feet / 5280;
	     Movement_Feet = Movement_Feet % 5280;
	  }
     }
   
   CopyNumberToLabel(Movement_Rate_Trigger, Prefs->Movement_Rate);
   CopyNumberToLabel(Movement_Hours_Trigger, Movement_Hours);
   CopyNumberToLabel(Movement_Minutes_Trigger, Movement_Minutes);
   CopyNumberToLabel(Movement_Seconds_Trigger, Movement_Seconds);
   CopyNumberToLabel(Movement_Miles_Trigger, Movement_Miles);
   CopyNumberToLabel(Movement_Feet_Trigger, Movement_Feet);
   CopyNumberToLabel(Movement_Rounds_Trigger, Prefs->Movement_Rounds);
}


/* MovementEventHandler
 * 
 * Handles events on the Movement form.
 */
Boolean MovementEventHandler(EventPtr event)
{
   LocalID id;
   
   if (event->eType == frmOpenEvent)
     {
	HelpText = S_MovementHelp;
	DrawCurrentForm();
	Movement_UpdateNumbers(true);
	SetListAndPopup(Movement_Speed_List, Movement_Speed_Popup,
			Prefs->Movement_Speed);
	SetListAndPopup(Movement_Terrain_List, Movement_Terrain_Popup,
			Prefs->Movement_Terrain);
	SetListAndPopup(Movement_Path_List, Movement_Path_Popup,
			Prefs->Movement_Path);
        SetListAndPopup(Movement_Obstructions_List, 
			Movement_Obstructions_Popup, 
			Prefs->Movement_Obstructions);
	SetListAndPopup(Movement_Surface_List, Movement_Surface_Popup,
			Prefs->Movement_Surface);
	SetListAndPopup(Movement_Visibility_List, Movement_Visibility_Popup,
			Prefs->Movement_Visibility);
	return true;
     }
   if (event->eType == popSelectEvent)
     {
	Prefs->Movement_Speed = GetListIndex(Movement_Speed_List);
	Prefs->Movement_Terrain = GetListIndex(Movement_Terrain_List);
	Prefs->Movement_Path = GetListIndex(Movement_Path_List);
	Prefs->Movement_Obstructions = 
	  GetListIndex(Movement_Obstructions_List);
	Prefs->Movement_Surface = GetListIndex(Movement_Surface_List);
	Prefs->Movement_Visibility = GetListIndex(Movement_Visibility_List);
	Movement_Popup_Updated = true;
	Movement_UpdateNumbers(false);
     }
   if (event->eType == winEnterEvent && DoWinEnter)
     {
	DoWinEnter = false;
	Movement_UpdateNumbers(false);
	return true;
     }
   if (event->eType == ctlSelectEvent)
     {
	id = event->data.ctlEnter.controlID;

	if (id == Movement_Rate_Trigger)
	  {
	     InputNumber(S_MovementRate, &(Prefs->Movement_Rate), 
			 INPUT_TARGET_SHORT, &Movement_Rate_Updated, 250, 0);
	     return true;
	  }
	
	if (id == Movement_Hours_Trigger)
	  {
	     InputNumber(S_Hours, &Movement_Hours, INPUT_TARGET_LONG,
			 &Movement_Hours_Updated, 5000, 0);
	     return true;
	  }
	if (id == Movement_Minutes_Trigger)
	  {
	     InputNumber(S_Minutes, &Movement_Minutes, INPUT_TARGET_LONG,
			 &Movement_Minutes_Updated, 59, 0);
	     return true;
	  }
	if (id == Movement_Seconds_Trigger)
	  {
	     InputNumber(S_Seconds, &Movement_Seconds, INPUT_TARGET_LONG,
			 &Movement_Seconds_Updated, 59, 0);
	     return true;
	  }
	
	if (id == Movement_Miles_Trigger)
	  {
	     InputNumber(S_Miles, &Movement_Miles, INPUT_TARGET_LONG,
			 &Movement_Miles_Updated, 68181, 0);
	     return true;
	  }
	if (id == Movement_Feet_Trigger)
	  {
	     InputNumber(S_Feet, &Movement_Feet, INPUT_TARGET_LONG,
			 &Movement_Feet_Updated, 5279, 0);
	     return true;
	  }
	
	if (id == Movement_Rounds_Trigger)
	  {
	     InputNumber(S_Rounds, &Prefs->Movement_Rounds,
			 INPUT_TARGET_LONG, &Movement_Rounds_Updated, 
			 3000000, 0);
	     return true;
	  }
     }
   return false;
}
