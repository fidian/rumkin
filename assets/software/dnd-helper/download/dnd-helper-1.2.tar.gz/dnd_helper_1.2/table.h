/* D&D Helper - Table Display (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#ifdef TABLE_C
unsigned short TableToDisplay;
#else
extern unsigned short TableToDisplay;
#endif

#define TABLE_SHOW_ABILITIES 0
#define TABLE_SHOW_LEVELS 1
#define TABLE_SHOW_TREASURE_PER_ENCOUNTER 2
#define TABLE_SHOW_WEALTH_GAIN 3
#define TABLE_SHOW_TREASURE_ENCOUNTERS 4
#define TABLE_SHOW_CHARACTER_WEALTH 5

void Table_Update(Boolean UpdateScrollbar);
void Table_Scroll(Int16 Lines, Boolean UpdateScrollbar);
void Table_DrawTableFunc(void *tableP, Int16 row, Int16 col, 
			 RectanglePtr bounds);
void Table_DrawTable(void);
void Table_DrawHeadings(void);
Boolean TableEventHandler(EventPtr event);
