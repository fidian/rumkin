/* D&D Helper - Preferences (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>


#ifndef PREFS_H
#define PREFS_H

#define SSTRING_BLOCK_SIZE 128

typedef struct
{
   // Palm OS does a four-byte alignment kind of thing.
   UInt16 PrefsVersion;

   UInt8 Exp_PlayerNum;
   UInt8 Exp_PlayerLvl;  // Word 1
   UInt8 Exp_EnemyNum;
   UInt8 Exp_EnemyCr;
   UInt8 Die_Num;
   UInt8 Die_Sides;  // Word 2
   UInt32 Movement_Rounds;  // Word 3
   UInt8 Movement_Speed;
   UInt8 Movement_Obstructions;
   UInt8 Movement_Surface;
   UInt8 Movement_Visibility;  // Word 4
   UInt8 Movement_Path;
   UInt8 Movement_Terrain;
   UInt8 Movement_Rate;
   Int8 Turn_ChaMod;  // Word 5
   UInt8 Turn_Level;
   UInt8 Die_Modifier;
   UInt8 Total_Die_Modifier;
   UInt8 LastForm;  // Word 6;
} PrefType;

typedef struct dbListType
{
   UInt32 type;
   UInt16 card;
   LocalID id;
   char Name[33];
   struct dbListType *next;
} dbListType;

typedef struct
{
   UInt16 Version;  // 0
   UInt16 Flags;    // 0x0001 = multiple generations instead of just one
   UInt16 RecCount[1];
} db_header;

typedef struct sstring
{
   unsigned char *data;
   UInt32 size;
   struct sstring *next;
} sstring;

typedef union 
{
   struct
     {
	UInt16 Type;
	UInt16 Flags;
     } generic;
   
   struct
     {
	UInt16 Type;
	UInt16 Flags;
	UInt16 Items;
     } random;

   struct
     {
	UInt16 Type;
	UInt16 Flags;
	UInt8 MaxLen;
	char data[1];
     } pairs;
} db_category;

typedef struct
{
   UInt16 MaxItemNumber;
   UInt16 ChanceOffset[1]; // Chance (if there) and offset
} db_data_random;

typedef struct
{
   char first_letter;
   UInt8 possible;
   char data[1];  // Ading a table here pushes it to the 4 byte boundary
//   struct
//     {
//	char next_letter;
//	UInt8 possible;
//     } table[1];
} db_data_pairs_header;

typedef struct
{
   UInt16 Flags;
   UInt16 Items;
   char data[1];
} db_data_psr;

#ifdef DND_HELPER_C
#define MAYBE_EXTERN
#else
#define MAYBE_EXTERN extern
#endif
MAYBE_EXTERN PrefType *Prefs;
MAYBE_EXTERN char MiscBuffer[80];
MAYBE_EXTERN LocalID HelpText;
MAYBE_EXTERN dbListType *dbListHead;
MAYBE_EXTERN Int16 dbListNum;
MAYBE_EXTERN char **dbListNames;
MAYBE_EXTERN Int16 GenDB;
MAYBE_EXTERN sstring *sstringHead;
MAYBE_EXTERN sstring *dieString;
MAYBE_EXTERN sstring *generateString;
MAYBE_EXTERN Boolean DoWinEnter;

void Prefs_SetupDefaultPrefs(UInt32);

#endif