/* D&D Helper - Super String Functions
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include "dnd_helper.h"
#include "prefs.h"
#include "misc.h"

sstring *String_New(void)
{
   sstring *p;

   p = GetMemory(sizeof(sstring), S_CreatingAString);
   if (p == NULL)
     return NULL;
   
   p->data = NULL;
   p->size = 0;
   p->next = sstringHead;
   sstringHead = p;
   
   return p;
}


void String_AppendChars(sstring *str, char *c) 
{
   char *p;
   UInt32 newSize;
   
   if (c == NULL || StrLen(c) == 0 || str == NULL)
     return;
   
   newSize = StrLen(c) + 1;
   
   if (str->data != NULL)
     newSize += StrLen(str->data);
   
   newSize /= SSTRING_BLOCK_SIZE;
   newSize ++;
   newSize *= SSTRING_BLOCK_SIZE;
   
   if (str->data == NULL)
     {
	str->data = (char *) GetMemory(newSize, S_CreatingAString);
	if (str->data == NULL)
	  return;
	str->size = newSize;
	StrCopy(str->data, c);
	return;
     }
   
   if (str->size < newSize)
     {
	p = (char *) GetMemory(newSize, S_CreatingAString);
	if (p == NULL)
	  return;
	StrCopy(p, str->data);
	MemPtrFree(str->data);
	str->data = p;
	str->size = newSize;
     }
   
   StrCat(str->data, c);
}


void String_AppendChar(sstring *str, char c)
{
   char d[2] = { 0, 0 };
   d[0] = c;
   String_AppendChars(str, d);
}


void String_AppendString(sstring *str, sstring *more)
{
   if (more != NULL)
     String_AppendChars(str, more->data);
}


void String_AppendStringID(sstring *str, LocalID Id)
{
   SysCopyStringResource(MiscBuffer, Id);
   String_AppendChars(str, MiscBuffer);
}


void String_Delete(sstring *s)
{
   sstring *t;
   
   if (s == NULL)
     return;

   if (s->data != NULL) 
     MemPtrFree(s->data);
   
   if (sstringHead == s)
     sstringHead = s->next;
   else
     {
	t = sstringHead;
	while (t->next != s && t->next != NULL)
	  {
	     t = t->next;
	  }
	if (t->next != NULL)
	  {
	     t->next = s->next;
	  }
     }
   
   MemPtrFree(s);
}


void String_DeleteAll(void)
{
   sstring *p;
   
   while (sstringHead != NULL)
     {
	p = sstringHead->next;
	if (sstringHead->data != NULL)
	  MemPtrFree(sstringHead->data);
	MemPtrFree(sstringHead);
	sstringHead = p;
     }
}
