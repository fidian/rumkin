/* D&D Helper - Generate
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>	// Pilot functions
#include "beam.h"
#include "dnd_helper.h"	// The ID numbers for everything
#include "misc.h"
#include "version.h"
#include "generate.h"
#include "prefs.h"


void Generate_dbList(void) 
{
   Err theErr;
   DmSearchStateType state;
   UInt16 card;
   LocalID id;
   char Name[33];
   UInt32 type;
   dbListType *p, *now, *prev;

   dbListNum = 0;
   GenDB = 0;
   
   theErr = DmGetNextDatabaseByTypeCreator(true, &state, NULL, APPLICATION_ID,
					   false, &card, &id);
   while (! theErr && id)
     {
	theErr = DmDatabaseInfo(card, id, Name, NULL, NULL, NULL, NULL,
				NULL, NULL, NULL, NULL, &type, NULL);
	if (! theErr && type == 'DATA')
	  {
	     dbListNum ++;
	     
	     // Create the node
	     p = GetMemory(sizeof(dbListType), S_CreatingTheDatabaseList);
	     if (p == NULL)
	       return;
	     
	     // fill values in for the node
	     p->card = card;
	     p->type = type;
	     p->id = id;
	     StrCopy(p->Name, Name);
	     
	     // find the right spot and insert it
	     if (dbListHead == NULL)
	       {
		  dbListHead = p;
		  p->next = NULL;
	       }
	     else
	       {
		  prev = NULL;
		  now = dbListHead;
		  while (now != NULL && 
			 StrCompare(now->Name, p->Name) < 0)
		    {
		       prev = now;
		       now = now->next;
		    }
		  if (prev == NULL)
		    dbListHead = p;
		  else
		    prev->next = p;
		  p->next = now;
	       }
	  }
	
	theErr = DmGetNextDatabaseByTypeCreator(false, &state, NULL,
						APPLICATION_ID, false, &card,
						&id);
     }
}


void Generate_ListDatabases(void)
{
   UInt16 Index;
   dbListType *p;
   ListPtr obj;
   
   if (dbListHead == NULL)
     Generate_dbList();
   
   if (dbListNum == 0)
     {	
	FrmAlert(A_NoGenerateDatabases);
	return;
     }
   
   if (dbListNames == NULL)
     {
	dbListNames = (char **) GetMemory(sizeof(char *) * dbListNum,
					  S_CreatingTheDatabaseList);
	if (dbListNames == NULL)
	  return;
	
	Index = 0;
	p = dbListHead;
	while (Index < dbListNum)
	  {
	     dbListNames[Index] = p->Name;
	     p = p->next;
	     Index ++;
	  }
     }

   obj = GetObjectPointer(Generate_List);
   LstSetListChoices(obj, dbListNames, dbListNum);
   LstDrawList(obj);
   LstSetSelection(obj, GenDB);
}


/* GenerateEventHandler
 * 
 * Handles events on the Generate form.
 */
Boolean GenerateEventHandler(EventPtr event)
{
   LocalID id;
   int Selection;
   dbListType *p, *prev;
   Int16 i;
   
   if (event->eType == frmOpenEvent)
     {
	HelpText = S_GenerateHelp;
	DrawCurrentForm();
	Generate_ListDatabases();
	return true;
     }
   if (event->eType == ctlSelectEvent)
     {
	id = event->data.ctlEnter.controlID;
	
	if (id == Generate_Button)
	  {
	     Selection = LstGetSelection(GetObjectPointer(Generate_List));
	     if (Selection != noListSelection) 
	       {
		  GenDB = Selection;
		  p = dbListHead;
		  while (Selection && p != NULL) 
		    {
		       Selection --;
		       p = p->next;
		    }
		  if (p == NULL)
		    return true;
		  if (p->type == 'DATA') 
		    {
		       FrmGotoForm(F_Generate_DATA);
		    }
	       }
	     return true;
	  }
	if (id == Generate_Beam)
	  {
	     Selection = LstGetSelection(GetObjectPointer(Generate_List));
	     if (Selection != noListSelection) 
	       {
		  GenDB = Selection;
		  p = dbListHead;
		  while (Selection && p != NULL) 
		    {
		       Selection --;
		       p = p->next;
		    }
		  if (p == NULL)
		    return true;
		  if (p->type == 'DATA') 
		    {
		       Beam_Send_DB(p->Name, p->id, p->card);
		    }
	       }
	     return true;
	  }
	if (id == Generate_Delete)
	  {
	     Selection = LstGetSelection(GetObjectPointer(Generate_List));
	     if (Selection != noListSelection) 
	       {
		  GenDB = Selection;
		  p = dbListHead;
		  prev = NULL;
		  while (Selection && p != NULL) 
		    {
		       Selection --;
		       prev = p;
		       p = p->next;
		    }
		  if (p == NULL)
		    return true;
		  if (p->type == 'DATA') 
		    {
		       i = FrmCustomAlert(A_DeleteConfirm, p->Name, NULL, 
					  NULL);
		       if (i == 1)
			 {
			    DmDeleteDatabase(p->card, p->id);
			    if (prev == NULL)
			      dbListHead = p->next;
			    else
			      prev->next = p->next;
			    MemPtrFree(p);
			    MemPtrFree(dbListNames);
			    dbListNames = NULL;
			    dbListNum --;
			    Generate_ListDatabases();
			 }
		    }
	       }
	     return true;
	  }
     }
   if (event->eType == keyDownEvent)
     {
	if (event->data.keyDown.chr == pageUpChr)
	  {
	     LstScrollList(GetObjectPointer(Generate_List), winUp, 9);
	     return true;
	  }
	if (event->data.keyDown.chr == pageDownChr)
	  {
	     LstScrollList(GetObjectPointer(Generate_List), winDown, 9);
	     return true;
	  }
     }
   return false;
}
