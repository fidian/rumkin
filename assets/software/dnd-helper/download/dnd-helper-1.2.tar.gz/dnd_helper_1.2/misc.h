/* D&D Helper - Miscellaneous Functions (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

void DrawChars(char *String, unsigned char X, unsigned char Y,
	       unsigned char Alignment);
void DrawHex(UInt16, unsigned char X, unsigned char Y,
	     unsigned char Alignment);
void DrawString(UInt32 StringID, unsigned char X, unsigned char Y,
		unsigned char Alignment);
Int32 StrAToL(char *Source);
void AlertAndLeave(LocalID AlertID);
void *GetObjectPointer(LocalID id);
void SetListAndPopup(LocalID ListId, LocalID PopupId, UInt16 index);
void SetListIndex(LocalID id, UInt16 index);
UInt16 GetListIndex(LocalID id);
void SetObject(LocalID id, Boolean Viewable);
void SetAttributeString(LocalID id, char *buffer);
void SetAttributeNumber(LocalID id, Int32 value);
char *GetAttributeString(LocalID id);
Int32 GetAttributeNumber(LocalID id);
void MakeFieldActive(LocalID id);
void DrawCurrentForm(void);
Boolean FormScrollTable(Int16 Number, UInt16 *FirstRow, 
		     UInt16 TotalRows, UInt16 TableRows);
void CopyStringToLabel(LocalID LabelID, char *String);
void CopyNumberToLabel(LocalID id, Int32 Num);
UInt16 RollDie(UInt16 Sides);
char *FloatToString(float Value, Int16 Precision, Boolean TrimZeros);
void Buffer_Clear(void);
void Buffer_AddStringID(UInt32);
void Buffer_AddString(char *);
void Buffer_AddInt(Int32);
void *GetMemory(UInt32 Size, LocalID ErrStr);
UInt16 GenerateChance(void);