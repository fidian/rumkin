/* D&D Helper - Generation Functions (Include Files)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include "prefs.h"

UInt32 BinarySearch(DmOpenRef Db, UInt32 startRec, UInt32 NumRec, UInt16 Find,
		    Boolean Use8Bits);
sstring *GenerateData_GenCat00(DmOpenRef Db, UInt32 startRec, UInt16 NumRec,
			       db_category *CatInfo);
sstring *GenerateData_GenCat01(DmOpenRef Db, UInt32 startRec, UInt16 NumRec,
			       db_category *CatInfo, UInt16 Size);
sstring *GenerateData_GenCat02(DmOpenRef Db, UInt32 startRec, UInt16 NumRec,
			       db_category *CatInfo);
sstring *GenerateData_GenCategory(DmOpenRef Db, UInt32 startRec, 
				  UInt16 NumRec);
UInt16 GenerateData_GenCmd2(DmOpenRef Db, sstring *src, UInt32 CurrentPos,
			  UInt32 size, sstring *dest, db_header *hdr,
			  UInt32 hdr_size);
sstring *GenerateData_GenString(DmOpenRef Db, db_header *hdr, 
				UInt32 hdr_size);
void GenerateData_Gen(void);

/* GenerateDataEventHandler
 * 
 * Handles events on the Generate_DATA form.
 */
Boolean GenerateDataEventHandler(EventPtr event);
