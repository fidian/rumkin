/* D&D Helper - Super String Functions (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include "dnd_helper.h"
#include "misc.h"
#include "prefs.h"

sstring *String_New(void);
void String_AppendChars(sstring *str, char *c);
void String_AppendChar(sstring *str, char c);
void String_AppendString(sstring *str, sstring *more);
void String_AppendStringID(sstring *str, LocalID Id);
void String_Delete(sstring *s);
void String_DeleteAll(void);
