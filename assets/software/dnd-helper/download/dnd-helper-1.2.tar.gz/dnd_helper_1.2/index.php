<?PHP

header("Location: http://rumkin.com/software/dnd_helper/");
