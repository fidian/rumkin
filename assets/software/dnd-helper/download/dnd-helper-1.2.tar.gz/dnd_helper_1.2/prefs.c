/* D&D Helper - Preferences
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>
#include "prefs.h"

void Prefs_SetupDefaultPrefs(UInt32 BytesLoaded)
{
   if (BytesLoaded < 2) 
     {
	// Set everything to zero
	MemSet(Prefs, sizeof(PrefType), 0);
	
	// Initialize anything that shouldn't be zero
	// ... nothing at the moment.
	return;
     }

   /*
   if (BytesLoaded < sizeof(PrefType))
     {
	// Initialize just what we need to -- the things that
	// are not zero.
	return;
     }
    */
}
