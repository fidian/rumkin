/* D&D Helper - Main File
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#define DND_HELPER_C

#include <PalmOS.h>

#include "beam.h"
#include "die.h"
#include "dnd_helper.h"
#include "exp.h"
#include "generate.h"
#include "gen_data.h"
#include "input.h"
#include "misc.h"
#include "movement.h"
#include "prefs.h"
#include "sstring.h"
#include "table.h"
#include "turning.h"
#include "version.h"


Boolean DndHelperMainEventHandler(EventPtr event)
{
   if (event->eType == frmOpenEvent)
     {
	HelpText = S_StartHelp;
	DrawCurrentForm();
	return true;
     }
   return false;
}
  
void HandleMenuEvent(EventPtr event)
{
   int id;
   
   id = event->data.menu.itemID;

   if (id == Menu_Die)
     {
	FrmGotoForm(F_Die);
	return;
     }
   if (id == Menu_Experience)
     {
	FrmGotoForm(F_Experience);
	return;
     }
   if (id == Menu_Generate)
     {
	FrmGotoForm(F_Generate);
	return;
     }
   if (id == Menu_Movement)
     {
	FrmGotoForm(F_Movement);
	return;
     }
   if (id == Menu_Turning)
     {
	FrmGotoForm(F_Turning);
	return;
     }

   if (id == Menu_Table_AbilityMod)
     {
	TableToDisplay = TABLE_SHOW_ABILITIES;
	FrmGotoForm(F_Table);
	return;
     }
   if (id == Menu_Table_Levels)
     {
	TableToDisplay = TABLE_SHOW_LEVELS;
	FrmGotoForm(F_Table);
	return;
     }
   if (id == Menu_Table_TreasurePerEncounter)
     {
	TableToDisplay = TABLE_SHOW_TREASURE_PER_ENCOUNTER;
	FrmGotoForm(F_Table);
	return;
     }
   if (id == Menu_Table_WealthGain)
     {
	TableToDisplay = TABLE_SHOW_WEALTH_GAIN;
	FrmGotoForm(F_Table);
	return;
     }
   if (id == Menu_Table_TreasureEncounters)
     {
	TableToDisplay = TABLE_SHOW_TREASURE_ENCOUNTERS;
	FrmGotoForm(F_Table);
	return;
     }
   if (id == Menu_Table_Wealth)
     {
	TableToDisplay = TABLE_SHOW_CHARACTER_WEALTH;
	FrmGotoForm(F_Table);
	return;
     }
      
   if (id == Menu_About)
     {
	FrmCustomAlert(A_Version, APP_VERSION, COMPILE_DATE, NULL);
	return;
     }
   if (id == Menu_Credits)
     {
	FrmHelp(S_Credits);
	return;
     }
   if (id == Menu_Help)
     {
	FrmHelp(HelpText);
	return;
     }
   if (id == Menu_License)
     {
	FrmHelp(S_Disclaimer);
	return;
     }
}

// Select a new form
void FormLoadEvent(EventPtr event)
{
   int formID;
   FormPtr form;
   
   formID = event->data.frmLoad.formID;
   form = FrmInitForm(formID);
   FrmSetActiveForm(form);
   
   if (formID == F_Die)
     {
	FrmSetEventHandler(form, DieEventHandler);
	Prefs->LastForm = 1;
	return;
     }
   if (formID == F_Experience)
     {
	FrmSetEventHandler(form, ExperienceEventHandler);
	Prefs->LastForm = 2;
	return;
     }
   if (formID == F_Generate)
     {
	FrmSetEventHandler(form, GenerateEventHandler);
	Prefs->LastForm = 3;
	return;
     }
   if (formID == F_Generate_DATA)
     {
	FrmSetEventHandler(form, GenerateDataEventHandler);
	return;
     }
   if (formID == F_Movement)
     {
	FrmSetEventHandler(form, MovementEventHandler);
	Prefs->LastForm = 4;
	return;
     }
   if (formID == F_Table)
     {
	FrmSetEventHandler(form, TableEventHandler);
	Prefs->LastForm = 0;
	return;
     }   
   if (formID == F_Turning)
     {
	FrmSetEventHandler(form, TurnEventHandler);
	Prefs->LastForm = 5;
	return;
     }
   
   if (formID == F_Start)
     {
	FrmSetEventHandler(form, DndHelperMainEventHandler);
	Prefs->LastForm = 0;
	return;
     }
   if (formID == F_InputNumber)
     {
	FrmSetEventHandler(form, InputEventHandler);
	return;
     }
}


static void EventLoop(void)
{
   short err;
   EventType event;
   
   DoWinEnter = false;
   
   do
    {
       // Wait indefinitely for an event -- screw the null events
       EvtGetEvent(&event, -1);
       
       if (! SysHandleEvent(&event))
	 {
	    if (! MenuHandleEvent(MenuGetActiveMenu(), &event, &err))
	      {
		 if (event.eType == menuEvent)
		   HandleMenuEvent(&event);
		 else
		   {
		      if (event.eType == frmLoadEvent)
			FormLoadEvent(&event);
		      else
			FrmDispatchEvent(&event);
		   }
	      }
	 }
    } while (event.eType != appStopEvent);
}


static Boolean StartApplication(void)
{
   UInt16 Size;
   Int32 Result;
   
   // Load the preferences into allocated memory
   // Don't use GetMemory() here because we want to return true instead
   // of pressing the app launch button
   Size = sizeof(PrefType);
   
   Prefs = (PrefType *) MemPtrNew(Size);
   if (Prefs == (PrefType *) NULL)
     {
	SysCopyStringResource(MiscBuffer, S_LoadingThePreferences);
	SysCopyStringResource(&(MiscBuffer[40]), S_IMustExitDndHelper);
	FrmCustomAlert(A_OutOfMemory, MiscBuffer, &(MiscBuffer[40]), NULL);
	return true;
     }
   MemSet(Prefs, Size, 0);
   Result = PrefGetAppPreferences(APPLICATION_ID, 0, Prefs, &Size, 1);
   if (Result == noPreferenceFound || 
       Size != sizeof(PrefType))
     {
	Prefs_SetupDefaultPrefs(Size);
     }

   if (Prefs->LastForm == 1)
     FrmGotoForm(F_Die);
   else if (Prefs->LastForm == 2)
     FrmGotoForm(F_Experience);
   else if (Prefs->LastForm == 3)
     FrmGotoForm(F_Generate);
   else if (Prefs->LastForm == 4)
     FrmGotoForm(F_Movement);
   else if (Prefs->LastForm == 5)
     FrmGotoForm(F_Turning);
   else
     FrmGotoForm(F_Start);
   
   return 0;
}


static void StopApplication(void)
{
   dbListType *dbListPtr;
   
   if (Prefs != (PrefType *) NULL) 
     {
	// Save preferences
	PrefSetAppPreferences(APPLICATION_ID, 0, Version1, Prefs,
			      sizeof(PrefType), 1);
	
	// Deallocate memory
	MemPtrFree(Prefs);
     }
   
   while (dbListHead != NULL)
     {
	dbListPtr = dbListHead->next;
	MemPtrFree(dbListHead);
	dbListHead = dbListPtr;
     }
   
   if (dbListNames != NULL)
     MemPtrFree(dbListNames);
   
   String_DeleteAll();
	
   // Delete any open forms.
   // This seems stupid, but if there are any open forms, D&D Helper
   // might not get a frmCloseForm event for them, leaking memory.
   FrmCloseAllForms();
}


/* I am a stone  [Enemy at the Gates] */
UInt32  PilotMain (UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
   int error;
   UInt32 romVersion;

   // Make sure we are running on Palm OS 2.0 or later
   FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
   if (romVersion < sysMakeROMVersion(2, 0, 0, sysROMStageRelease, 0))
     {
	if ((launchFlags & (sysAppLaunchFlagNewGlobals |
			   sysAppLaunchFlagUIApp)) ==
	    (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
	  {
	     AlertAndLeave(A_RomIncompatible);
	  }
	
	return sysErrRomIncompatible;
     }
	
   if (cmd == sysAppLaunchCmdNormalLaunch)
     {	
	error = StartApplication();
	if (error) return error;
	
	EventLoop();
	
	StopApplication();
	return 0;
     }
   
   if (cmd == sysAppLaunchCmdSyncNotify)
     {
	// Register the MIME type on syncNotify so we don't need to be
	// ran before the program can receive data.
	if (romVersion >= 0x03000000)
	  {
	     ExgRegisterData(APPLICATION_ID, exgRegTypeID, MIME_TYPE);
	  }
	return 0;
     }
   
   // if (cmd == sysAppLaunchCmdExgAskUser)
   // {
   //    Just do the default behavior -- ask normally
   // }
   
   if (cmd == sysAppLaunchCmdExgReceiveData)
     {
	error = Beam_Receive_DB((ExgSocketPtr) cmdPBP);
	return error;
     }
   
   return 0;
}
