/* D&D Helper - Input Routines (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#define INPUT_TARGET_SHORT 0
#define INPUT_TARGET_SSHORT 1
#define INPUT_TARGET_INT 2
#define INPUT_TARGET_LONG 3

void InputNumber(LocalID Desc, void *Where, UInt8 type,
		 Boolean *IsThereNewData, Int32 Max, Int32 Min);
void InputDrawForm(void);
void InputDrawCurrentVal();
void InputStoreValue(void);
Boolean InputEventHandler(EventPtr event);