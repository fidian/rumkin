/* D&D Helper - Input Routines
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>
#include "prefs.h"
#include "dnd_helper.h"
#include "misc.h"
#include "input.h"


// Global variables to help figure out where things go
LocalID Input_Desc;
union 
{
   Int32 *AsLong;
   UInt8 *AsShort;
   Int8 *AsSShort;
   Int16 *AsInt;
} Input_Target;
UInt8 Input_Target_Type;
Int32 *Input_Number;
Int32 Input_CurrentVal;
Int32 Input_MaxVal;
Int32 Input_MinVal;
Boolean *DidIFillNumber;
Boolean FirstTouch;


// Input a number
void InputNumber(LocalID Desc, void *Where, UInt8 type,
		 Boolean *IsThereNewData, Int32 Max, Int32 Min)
{
   if (type == INPUT_TARGET_SHORT)
     {
	Input_Target.AsShort = Where;
	Input_CurrentVal = *Input_Target.AsShort;
     }
   else if (type == INPUT_TARGET_SSHORT)
     {
	Input_Target.AsSShort = Where;
	Input_CurrentVal = *Input_Target.AsSShort;
     }
   else if (type == INPUT_TARGET_INT)
     {
	Input_Target.AsInt = Where;
	Input_CurrentVal = *Input_Target.AsInt;
     }
   else
     {
	Input_Target.AsLong = Where;
	Input_CurrentVal = *Input_Target.AsLong;
     }
   Input_Target_Type = type;
   Input_Desc = Desc;
   DidIFillNumber = IsThereNewData;
   Input_MaxVal = Max;
   if (Input_MaxVal == 0)
     Input_MaxVal = 100000000;
   Input_MinVal = Min;
   if (Input_MinVal > 0)
     Input_MinVal = 0;
   FrmPopupForm(F_InputNumber);
}

void InputDrawForm(void)
{
   FormPtr formp;
   
   formp = FrmGetActiveForm();
   
   FrmDrawForm(formp);
   
   // Draw title
   SysCopyStringResource(MiscBuffer, Input_Desc);
   FrmCopyTitle(formp, MiscBuffer);

   InputDrawCurrentVal();
}


void InputDrawCurrentVal(void)
{
   SetAttributeNumber(Input_Value, Input_CurrentVal);
}


void InputStoreValue(void)
{
   if (Input_Target_Type == INPUT_TARGET_SHORT)
     *Input_Target.AsShort = (UInt8) Input_CurrentVal;
   else if (Input_Target_Type == INPUT_TARGET_SSHORT)
     *Input_Target.AsSShort = (Int8) Input_CurrentVal;
   else if (Input_Target_Type == INPUT_TARGET_INT)
     *Input_Target.AsInt = (Int16) Input_CurrentVal;
   else
     *Input_Target.AsLong = (Int32) Input_CurrentVal;

   if (DidIFillNumber != NULL)
     *DidIFillNumber = 1;
}


Boolean InputEventHandler(EventPtr event)
{
   LocalID id;
   Int32 TestVal;
   
   if (event->eType == frmOpenEvent)
     {
	InputDrawForm();
	if (Input_Target_Type == INPUT_TARGET_SSHORT)
	  SetObject(Input_ToggleMinus, true);
	FirstTouch = true;
	return true;
     }
   if (event->eType == ctlSelectEvent)
     {
	id = event->data.ctlEnter.controlID;

	if (id >= Input_0 && id <= Input_9)
	  {
	     if (FirstTouch)
	       Input_CurrentVal = 0;
	     FirstTouch = false;
	     CtlSetValue(GetObjectPointer(id), false);
	     TestVal = (Input_CurrentVal * 10) + (id - Input_0);
	     if (TestVal > Input_MaxVal || TestVal < Input_MinVal)
	       return true;
	     Input_CurrentVal *= (long) 10;
	     Input_CurrentVal += (long) (id - Input_0);
	     InputDrawCurrentVal();
	     return true;
	  }
        FirstTouch = false;
	if (id == Input_Ok)
	  {
	     CtlSetValue(GetObjectPointer(id), false);
	     InputStoreValue();
	     DoWinEnter = true;
	     FrmReturnToForm(0);
	     return true;
	  }
	if (id == Input_Cancel)
	  {
	     CtlSetValue(GetObjectPointer(id), false);
	     FrmReturnToForm(0);
	     return true;
	  }
	if (id == Input_Backspace)
	  {
	     CtlSetValue(GetObjectPointer(id), false);
	     Input_CurrentVal /= (long) 10;
	     InputDrawCurrentVal();
	     return true;
	  }
	if (id == Input_ToggleMinus)
	  {
	     CtlSetValue(GetObjectPointer(id), false);
	     if (-Input_CurrentVal > Input_MaxVal || 
		 -Input_CurrentVal < Input_MinVal)
	       return true;
	     Input_CurrentVal = - Input_CurrentVal;
	     InputDrawCurrentVal();
	     return true;
	  }
	if (id == Input_PlusOne)
	  {
	     CtlSetValue(GetObjectPointer(id), false);
	     if (Input_CurrentVal >= Input_MaxVal)
	       return true;
	     Input_CurrentVal ++;
	     InputDrawCurrentVal();
	     return true;
	  }
	if (id == Input_MinusOne)
	  {
	     CtlSetValue(GetObjectPointer(id), false);
	     if (Input_CurrentVal <= Input_MinVal)
	       return true;
	     Input_CurrentVal --;
	     InputDrawCurrentVal();
	     return true;
	  }
	if (id == Input_Clear)
	  {
	     CtlSetValue(GetObjectPointer(id), false);
	     Input_CurrentVal = 0;
	     InputDrawCurrentVal();
	     return true;
	  }
     }

   if (event->eType == keyDownEvent)
     {
	if (event->data.keyDown.chr == pageUpChr)
	  {
	     if (Input_CurrentVal >= Input_MaxVal)
	       return true;
	     Input_CurrentVal ++;
	     InputDrawCurrentVal();
	     return true;
	  }
	if (event->data.keyDown.chr == pageDownChr)
	  {
	     if (Input_CurrentVal <= Input_MinVal)
	       return true;
	     Input_CurrentVal --;
	     InputDrawCurrentVal();
	     return true;
	  }
     }
   
   return false;
}
