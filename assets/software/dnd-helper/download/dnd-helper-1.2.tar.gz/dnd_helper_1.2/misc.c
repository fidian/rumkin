/* D&D Helper - Miscellaneous Functions
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#define MISC_C

#include <PalmOS.h>
// include <StringMgr.h>
#include "misc.h"
#include "prefs.h"
#include "dnd_helper.h"

void DrawChars(char *String, UInt8 X, UInt8 Y, UInt8 Alignment)
{
   UInt16 length;
   
   length = StrLen(String);
   
   if (Alignment == 0)
     {
	WinDrawChars(String, length, X, Y);
     }
   else if (Alignment == 1)
     {
	WinDrawChars(String, length, X - (FntCharsWidth(String, length) / 2),
		     Y);
     }
   else
     {
	WinDrawChars(String, length, X - FntCharsWidth(String, length),
		     Y);
     }
}


void DrawHex(UInt16 Val, UInt8 X, UInt8 Y, UInt8 Alignment)
{
   char HexCodes[16] = "0123456789ABCDEF";
   
   MiscBuffer[0] = HexCodes[(Val / 16) & 0x0F];
   MiscBuffer[1] = HexCodes[(Val % 16) & 0x0F];
   MiscBuffer[2] = 0;
   
   DrawChars(MiscBuffer, X, Y, Alignment);
}


void DrawString(LocalID StringID, UInt8 X, UInt8 Y, UInt8 Alignment)
{
   SysCopyStringResource(MiscBuffer, StringID);
   DrawChars(MiscBuffer, X, Y, Alignment);
}


// The StrAToI, even though it says it returns a long, is limited to 
// two-byte integers.
Int32 StrAToL(char *Source)
{
   char Buffer[20];
   Int32 Val = 0;
   char Sign = 1;
   char Pos = 0;
   
   if (Source == NULL)
     return (Int32) 0;
   StrCopy(Buffer, Source);
   
   if (Buffer[Pos] == '-')
     {
	Sign = -1;
	Pos ++;
     }
   
   while (Buffer[Pos] >= '0' && Buffer[Pos] <= '9')
     {
	Val *= 10;
	Val += Buffer[Pos] - '0';
	Pos ++;
     }
   
   return Val * Sign;
}


void AlertAndLeave(LocalID AlertID)
{
   EventType newEvent;

   if (AlertID)
     FrmAlert(AlertID);
	
   // It looks like this is CodeWarrior only ... sysFileCDefaultApp
   // isn't resolved.
   // 
   // AppLaunchWithCommand(sysFileCDefaultApp, 
   //                      sysAppLaunchCmdNormalLaunch, NULL);
   //
   // alternate method:

   newEvent.eType = keyDownEvent;
   newEvent.data.keyDown.chr = launchChr;
   newEvent.data.keyDown.modifiers = commandKeyMask;
   EvtAddEventToQueue(&newEvent);
}


void *GetObjectPointer(LocalID id)
{
   FormPtr formPtr;
   
   formPtr = FrmGetActiveForm();
   return FrmGetObjectPtr(formPtr, FrmGetObjectIndex(formPtr, id));
}


void SetListAndPopup(LocalID ListId, LocalID PopupId, UInt16 index)
{
   ListPtr listp;
   ControlPtr popp;
   UInt16 Items;

   listp = GetObjectPointer(ListId);
   
   Items = LstGetNumberOfItems(listp);
   if (index < Items && index >= 0)
     {
	LstSetSelection(listp, index);
	LstMakeItemVisible(listp, index);
	LstDrawList(listp);
	popp = GetObjectPointer(PopupId);
	CtlSetLabel(popp, LstGetSelectionText(listp, index));
     }
}


void SetListIndex(LocalID id, UInt16 index) 
{
   ListPtr listp;
   UInt16 Items;

   listp = GetObjectPointer(id);
   
   Items = LstGetNumberOfItems(listp);
   if (index < Items && index >= 0)
     {
	LstSetSelection(listp, index);
	LstMakeItemVisible(listp, index);
	LstDrawList(listp);
     }
}


UInt16 GetListIndex(LocalID id)
{
   ListPtr listp;

   listp = GetObjectPointer(id);
   return LstGetSelection(listp);
}


// If you SetObject(X, true) and then SetObject(Y, false)
// and if X and Y are on top of each other, then whatever Y covers up of
// X will not be shown for older PalmOS versions.  Try to turn off all
// buttons that overlap before turning on buttons.
void SetObject(LocalID id, Boolean Viewable) 
{
   FormPtr formPtr;
   UInt16 index;

   formPtr = FrmGetActiveForm();
   index = FrmGetObjectIndex(formPtr, id);
   if (Viewable)
     {
	FrmShowObject(formPtr, index);
     }
   else
     {
	FrmHideObject(formPtr, index);
     }
}


void SetAttributeString(LocalID id, char *buffer)
{
   MemHandle targetHandle;
   char *targetText;
   FieldPtr targetPtr;

   targetPtr = GetObjectPointer(id);
   
   targetHandle = FldGetTextHandle(targetPtr);
   if (targetHandle)
     FldFreeMemory(targetPtr);

   targetHandle = MemHandleNew(StrLen(buffer) + 1);
   targetText = MemHandleLock(targetHandle);
   StrCopy(targetText, buffer);
   MemHandleUnlock(targetHandle);
   FldSetTextHandle(targetPtr, targetHandle);
   FldDrawField(targetPtr);
}


void SetAttributeNumber(LocalID id, Int32 value)
{
   char buffer[15]; 
   
   StrIToA(buffer, value); 
   SetAttributeString(id,buffer); 
}


char *GetAttributeString(LocalID id)
{
   char *d;
   static char Empty[1] = { 0 };
   
   d = FldGetTextPtr(GetObjectPointer(id));
   if (d)
     {
	return d;
     }
   return Empty;
}


Int32 GetAttributeNumber(LocalID id)
{
   return StrAToL(GetAttributeString(id));
}


void MakeFieldActive(LocalID id)
{
   FormPtr formPtr;
   
   formPtr = FrmGetActiveForm();
   return FrmSetFocus(formPtr, FrmGetObjectIndex(formPtr, id));
}


void DrawCurrentForm(void)
{
   FrmDrawForm(FrmGetActiveForm());
}


Boolean FormScrollTable(Int16 Number, UInt16 *FirstRow, 
			UInt16 TotalRows, UInt16 TableRows)
{
   UInt16 numRows;
   UInt16 OldFirstRow;
   
   OldFirstRow = *FirstRow;
   
   if (Number < 0)
     {
	if (*FirstRow < - Number)
	  *FirstRow = 0;
	else
	  *FirstRow += Number;
     }
   else
     {
	if (TotalRows <= TableRows)
	  *FirstRow = 0;
	else
	  {
	     numRows = TotalRows - TableRows;
	     if (*FirstRow + Number > numRows)
	       *FirstRow = numRows;
	     else
	       *FirstRow += Number;
	  }
     }
   
   if (OldFirstRow != *FirstRow)
     return true;
   return false;
}


void CopyStringToLabel(LocalID LabelID, char *String)
{
   FormPtr formp;
   LocalID ObjID;

   formp = FrmGetActiveForm();
   ObjID = FrmGetObjectIndex(formp, LabelID);
   FrmHideObject(formp, ObjID);
   FrmCopyLabel(formp, LabelID, String);
   FrmShowObject(formp, ObjID);
}


void CopyNumberToLabel(LocalID id, Int32 Num)
{
   char buffer[15];
   StrIToA(buffer, Num);
   CopyStringToLabel(id, buffer);
}


// Make sure Sides is less than 0x7FFF
UInt16 RollDie(UInt16 Sides)
{
   Int16 Max;
   Int16 Result;

   // If there is a number between Max and sysRandomMax, then
   // we must discard it in order to not bias the random numbers
   Max = sysRandomMax / Sides;
   Max *= Sides;
   
   do 
     {
	// Most likely, this will only be called once.
	Result = SysRandom(0);
     }
   while (Result >= Max);
   
   // Return a number from 1 to Sides
   return (Result % Sides) + 1;
}


char *FloatToString(float Value, Int16 Precision, Boolean TrimZeros)
{
   char Pos;
   double RoundingFactor;
   static char buffer[20];

   // Round the number here
   Pos = Precision;
   RoundingFactor = 0.5;
   while (Pos --)
     {
	RoundingFactor /= 10.0;
     }

   
   // Take care of the whole number part.
   // Handle negatives differently.
   Pos = 0;
   if (Value < 0.0)
     {
	// Can't just use StrIToA(buffer, (Long) Value) because if
	// Value is -0.1, (Long) Value is -0 which shows up as 0.
	buffer[0] = '-';
	Value = 0.0 - Value;
	Pos = 1;
     }

   Value += RoundingFactor;
   StrIToA(&(buffer[Pos]), (Int32) Value);
   Value -= (Int32) Value;
   Pos = StrLen(buffer);

   // At this point, buffer contains the integer part and sign
   // Pos is where the null is
   // Value is the remainder (no more whole numbers) and is positive
   
   if (Precision)
    {
       buffer[Pos ++] = '.';
       while (Precision)
	 {
	    Value *= 10.0;
	    buffer[Pos ++] = '0' + (UInt8) Value;
	    Value -= (UInt8) Value;
	    Precision --;
	 }
       buffer[Pos] = '\0';
       
       // Trim off trailing zeros if so desired
       if (TrimZeros)
	 {
	    Pos --;
	    while ((buffer[Pos] == '0' || buffer[Pos] == '.') && Pos >= 1)
	      {
		 if (buffer[Pos] == '.')
		   {
		      buffer[Pos] = '\0';
		      return buffer;
		   }
		 buffer[Pos] = '\0';
		 Pos --;
	      }
	 }
    }
   
   return buffer;
}


void *GetMemory(UInt32 Size, LocalID ErrStr)
{
   void *v;
   
   v = MemPtrNew(Size);
   
   if (v == NULL)
     {
	SysCopyStringResource(MiscBuffer, ErrStr);
	SysCopyStringResource(&(MiscBuffer[40]), S_IMustExitDndHelper);
	FrmCustomAlert(A_OutOfMemory, MiscBuffer, &(MiscBuffer[40]), NULL);
	AlertAndLeave(0);
     }
   
   return v;
}


UInt16 GenerateChance(void)
{
   UInt16 RandomChunk;
   UInt16 Result;
   
   // Since SysRandom() only returns values from 0 to 0x7FFF, I need to
   // make two calls to it.  Luckily, I can just take the lower byte of
   // each call and smoosh them together to make the result I want.
   RandomChunk = SysRandom(0) & 0xFF;
   Result = SysRandom(0) & 0xFF;
   Result |= RandomChunk << 8;
   
   return Result;
}
