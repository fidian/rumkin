/* D&D Helper - Table Display
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#define TABLE_C

#include <PalmOS.h>	// Pilot functions
#include "dnd_helper.h"	// The ID numbers for everything
#include "misc.h"
#include "table.h"
#include "prefs.h"


Int16 Table_Rows, Table_TopRow, Table_TotalRows;

UInt32 Table_LevelTreasurePerEncounter[] =
{
   300, 600, 900, 1200, 1600,
     2000, 2600, 3400, 4500, 5800,
     7500, 9800, 13000, 17000, 22000,
     28000, 36000, 47000, 61000, 80000
};
UInt32 Table_LevelWealthGain[] =
{
   900, 1800, 2700, 3600, 4000,
     6000, 8000, 9000, 13000, 17000, 
     22000, 22000, 40000, 50000, 60000,
     80000, 100000, 140000, 180000
};
UInt32 Table_LevelTreasureEncounters[] =
{
   3999, 7998, 11997, 15996, 21328,
     26660, 34658, 45322, 59985, 77314,
     99975, 130634, 173290, 126610, 293260,
     373240, 479880, 626510, 813130
};
UInt32 Table_LevelCharacterWealth[] =
{
   0, 900, 2700, 5400, 9000,
     13000, 19000, 27000, 36000, 49000,
     66000, 88000, 110000, 150000, 200000,
     260000, 340000, 440000, 580000, 760000
};


void Table_Update(Boolean UpdateScrollbar)
{
   TablePtr table;
   ScrollBarPtr bar;
   
   table = GetObjectPointer(Table_TheTable);
   TblMarkTableInvalid(table);
   TblRedrawTable(table);
   
   if (! UpdateScrollbar)
     return;
   
   if (Table_TotalRows <= Table_Rows) 
     {
	SetObject(Table_Scrollbar, false);
	return;
     }
   
   SetObject(Table_Scrollbar, 1);
   bar = GetObjectPointer(Table_Scrollbar);
   SclSetScrollBar(bar, Table_TopRow, 0, Table_TotalRows - Table_Rows,
		   Table_Rows - 1);
   SclDrawScrollBar(bar);
}


void Table_Scroll(Int16 Lines, Boolean UpdateScrollbar)
{
   Int16 numRows;
   Int16 OldFirstRow;
   
   OldFirstRow = Table_TopRow;
   
   if (Lines < 0)
     {
	if (Table_TopRow < - Lines)
	  Table_TopRow = 0;
	else
	  Table_TopRow += Lines;
     }
   else
     {
	if (Table_TotalRows <= Table_Rows)
	  Table_TopRow = 0;
	else
	  {
	     numRows = Table_TotalRows - Table_Rows;
	     if (Table_TopRow + Lines > numRows)
	       Table_TopRow = numRows;
	     else
	       Table_TopRow += Lines;
	  }
     }
   
   if (OldFirstRow != Table_TopRow)
     Table_Update(UpdateScrollbar);
}


void Table_DrawTableFunc(void *tableP, Int16 row, Int16 col,
			 RectanglePtr bounds)
{
   Int16 i;
   Int32 l;
   if (row + Table_TopRow > Table_TotalRows)
     {
	return;
     }
   if (TableToDisplay == TABLE_SHOW_ABILITIES)
     {
	i = 2 * (row + Table_TopRow);
	if (i == 0)
	  {
	     StrIToA(MiscBuffer, i + 1);
	  }
	else
	  {
	     StrIToA(MiscBuffer, i);
	     SysCopyStringResource(&(MiscBuffer[StrLen(MiscBuffer)]), 
				   S_Through);
	     StrIToA(&(MiscBuffer[StrLen(MiscBuffer)]), i + 1);
	  }
	
	StrIToA(&(MiscBuffer[40]), ((Int32) row + (Int32) Table_TopRow) - 
		(Int32) 5);
     }
   else if (TableToDisplay == TABLE_SHOW_LEVELS)
     {
	i = row + Table_TopRow + 1;
	StrIToA(MiscBuffer, i);
	l = 0;
	while (i) 
	  {
	     i --;
	     l += i;
	  }
	l *= 1000;
	StrIToA(&(MiscBuffer[40]), l);
     }
   else if (TableToDisplay == TABLE_SHOW_TREASURE_PER_ENCOUNTER)
     {
	i = row + Table_TopRow;
	StrIToA(MiscBuffer, i + 1);
	StrIToA(&MiscBuffer[40], Table_LevelTreasurePerEncounter[i]);
     }
   else if (TableToDisplay == TABLE_SHOW_WEALTH_GAIN)
     {
	i = row + Table_TopRow;
	StrIToA(MiscBuffer, i + 1);
	StrIToA(&MiscBuffer[40], Table_LevelWealthGain[i]);
     }
   else if (TableToDisplay == TABLE_SHOW_TREASURE_ENCOUNTERS)
     {
	i = row + Table_TopRow;
	StrIToA(MiscBuffer, i + 1);
	StrIToA(&MiscBuffer[40], Table_LevelTreasureEncounters[i]);
     }
   else // if (TableToDisplay == TABLE_SHOW_CHARACTER_WEALTH)
     {
	i = row + Table_TopRow;
	StrIToA(MiscBuffer, i + 1);
	StrIToA(&MiscBuffer[40], Table_LevelCharacterWealth[i]);
     }
   i = bounds->extent.x / 4;
   DrawChars(MiscBuffer, bounds->topLeft.x + i, bounds->topLeft.y, 1);
   DrawChars(&(MiscBuffer[40]), bounds->topLeft.x - i + bounds->extent.x,
	     bounds->topLeft.y, 1);
}


void Table_DrawTable(void)
{
   TablePtr table;
   Int16 i;
   
   table = GetObjectPointer(Table_TheTable);
   TblHasScrollBar(table, true);
   Table_Rows = TblGetNumberOfRows(table);
   for (i = 0; i < Table_Rows; i ++)
     {
	TblSetItemStyle(table, i, 0, customTableItem);
	TblSetRowSelectable(table, i, false);
     }
   TblSetColumnUsable(table, 0, true);
   TblSetCustomDrawProcedure(table, 0, Table_DrawTableFunc);
   Table_Update(true);
}


void Table_DrawHeadings(void)
{
   Int16 TitleString = 0, LeftString = 0, RightString = 0;
   
   if (TableToDisplay == TABLE_SHOW_ABILITIES)
     {
	TitleString = S_AbilityModifiers;
	LeftString = S_Score;
	RightString = S_Modifier;
	Table_TotalRows = 50;
     }
   else if (TableToDisplay == TABLE_SHOW_LEVELS)
     {
	TitleString = S_ExperienceLevels;
	LeftString = S_Level;
	RightString = S_Experience;
	Table_TotalRows = 75;
     }
   else if (TableToDisplay == TABLE_SHOW_TREASURE_PER_ENCOUNTER)
     {
	TitleString = S_TreasurePerEncounter;
	LeftString = S_Level;
	RightString = S_GPValue;
	Table_TotalRows = 20;
     }
   else if (TableToDisplay == TABLE_SHOW_WEALTH_GAIN)
     {
	TitleString = S_WealthGainByLevel;
	LeftString = S_Level;
	RightString = S_GPValue;
	Table_TotalRows = 19;
     }
   else if (TableToDisplay == TABLE_SHOW_TREASURE_ENCOUNTERS)
     {
	TitleString = S_TreasureFromEncounters;
	LeftString = S_Level;
	RightString = S_GPValue;
	Table_TotalRows = 19;
     }
   else if (TableToDisplay == TABLE_SHOW_CHARACTER_WEALTH)
     {
	TitleString = S_CharacterWealth;
	LeftString = S_Level;
	RightString = S_GPValue;
	Table_TotalRows = 20;
     }
   
   Table_TopRow = 0;
   SysCopyStringResource(MiscBuffer, TitleString);
   FrmCopyTitle(FrmGetActiveForm(), MiscBuffer);
   SysCopyStringResource(MiscBuffer, LeftString);
   CtlSetLabel(GetObjectPointer(Table_Left_Button), MiscBuffer);
   SysCopyStringResource(MiscBuffer, RightString);
   CtlSetLabel(GetObjectPointer(Table_Right_Button), MiscBuffer);
}


/* TableEventHandler
 * 
 * Handles events on the Table display.
 */
Boolean TableEventHandler(EventPtr event)
{
   if (event->eType == frmOpenEvent)
     {
	HelpText = S_TableHelp;
	DrawCurrentForm();
	Table_DrawHeadings();
	Table_DrawTable();
	return true;
     }
   if (event->eType == keyDownEvent)
     {
	if (event->data.keyDown.chr == pageUpChr)
	  {
	     Table_Scroll(1 - Table_Rows, true);
	     return true;
	  }
	if (event->data.keyDown.chr == pageDownChr)
	  {
	     Table_Scroll(Table_Rows - 1, true);
	     return true;
	  }
     }
   if (event->eType == sclRepeatEvent)
     {
	Table_Scroll(event->data.sclRepeat.newValue - 
		     event->data.sclRepeat.value, false);
	// Don't return true from this one
     }
	
   return false;
}
