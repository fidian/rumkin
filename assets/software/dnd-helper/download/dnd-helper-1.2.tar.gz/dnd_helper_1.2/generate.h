/* D&D Helper - Generate (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

void Generate_ListDatabases(void);


/* GenerateEventHandler
 * 
 * Handles events on the Generate form.
 */
Boolean GenerateEventHandler(EventPtr event);
