/* D&D Helper - Generation Functions
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

/* One big thing that should be kept in mind is that the Palm has a
 * very limited stack and should not use recursive functions.  Think
 * iteratively.
 */


#include <PalmOS.h>	// Pilot functions
#include "dnd_helper.h"	// The ID numbers for everything
#include "misc.h"
#include "gen_data.h"
#include "prefs.h"
#include "sstring.h"


// Use a binary search to find the specified record
// Returns the record that is equal to or the first one greater than Find
// Returns 0 if no records were found to be equal to or greater than Find
UInt32 BinarySearch(DmOpenRef Db, UInt32 startRec, UInt32 NumRec, 
		    UInt16 Find, Boolean Use8Bits)
{
   void *data;
   Int16 Diff;
   MemHandle Rec;
   Boolean keep_going = true;
   
   UInt32 MaxRec = startRec + NumRec;
   
   if (Use8Bits)
     {
	Find = Find & 0xFF;
     }

   while (NumRec > 1 && startRec + NumRec / 2 <= MaxRec)
     {
	NumRec /= 2;
	Rec = DmQueryRecord(Db, startRec + NumRec);
	data = MemHandleLock(Rec);
	
	if (Use8Bits)
	  Diff = *((UInt8 *) data) - Find;
	else
	  Diff = *((UInt16 *) data) - Find;
	
	MemHandleUnlock(Rec);

	if (Diff == 0)
	  return startRec + NumRec;
	if (Diff < 0)
	  startRec += NumRec;
     }

   while (keep_going && startRec <= MaxRec)
     {
	Rec = DmQueryRecord(Db, startRec);
	data = MemHandleLock(Rec);
	
	if (Use8Bits)
	  Diff = *((UInt8 *) data) - Find;
	else
	  Diff = *((UInt16 *) data) - Find;
	
	MemHandleUnlock(Rec);
	
	if (Diff >= 0)
	  keep_going = false;
	else
	  startRec ++;
     }
   
   if (keep_going)
     return 0;
   
   return startRec;
}


// Pick one record
sstring *GenerateData_GenCat00(DmOpenRef Db, UInt32 startRec, UInt16 NumRec,
			       db_category *CatInfo)
{
   sstring *s;
   UInt16 i, j, items, total_items;
   MemHandle Rec;
   db_data_random *RecData;
   UInt32 TargetRec;
   UInt16 Chance;
   char *c;
   
   s = String_New();
   
   // Find the record we want
   if (CatInfo->generic.Flags & 0x0001) 
     {
	// use chances
	Chance = GenerateChance();
	total_items = 0;
	for (i = 0; i < NumRec; i ++)
	  {
	     // Search this record for a hit.
	     Rec = DmQueryRecord(Db, i + startRec);
	     RecData = MemHandleLock(Rec);
	     
	     // Quick test for chances
	     items = RecData->MaxItemNumber * 2;
	     items -= 2;
	     if (RecData->ChanceOffset[items] >= Chance)
	       {
		  // We have the right record
		  for (j = 0; j < RecData->MaxItemNumber; j ++)
		    {
		       if (RecData->ChanceOffset[j * 2] >= Chance)
			 {
			    // We have the right entry
			    j = RecData->ChanceOffset[j * 2 + 1];
			    c = (char *) RecData;
			    String_AppendChars(s, &(c[j]));
			    i = NumRec;
			 }
		    }
	       }
	     total_items += RecData->MaxItemNumber;
	     MemHandleUnlock(Rec);
	  }
     }
   else
     {
	// pick one record at random
	i = RollDie(CatInfo->random.Items);
	TargetRec = BinarySearch(Db, startRec, NumRec, i, false);

	if (TargetRec >= startRec)
	  {
	     if (TargetRec > startRec)
	       {
		  Rec = DmQueryRecord(Db, TargetRec - 1);
		  RecData = MemHandleLock(Rec);
		  items = RecData->MaxItemNumber;
		  MemHandleUnlock(Rec);
	       }
	     else
	       items = 0;
	       
	     Rec = DmQueryRecord(Db, TargetRec);
	     RecData = MemHandleLock(Rec);
	     
	     // Find the right entry
	     c = (char *) RecData;
	     i -= items + 1;
	     String_AppendChars(s, &c[RecData->ChanceOffset[i]]);
	     MemHandleUnlock(Rec);
	  }
     }
   
   return s;
}


// Letter pairs
sstring *GenerateData_GenCat01(DmOpenRef Db, UInt32 startRec, UInt16 NumRec,
			       db_category *CatInfo, UInt16 CatInfoSize)
{
   char pair[2];
   UInt16 i, j, k;
   sstring *s;
   UInt32 TargetRec;
   MemHandle Rec;
   db_data_pairs_header *Hdr;
   char *RecData;
   Boolean loop_again;
   UInt16 Chance;
   union
     {
	char c[2];
	UInt16 i;
     } Test;
   char *dataStart;
   
   s = String_New();

   i = CatInfoSize - 5; // size of UInt16 * 2 + unsigned short
   dataStart = &(CatInfo->pairs.data[0]);
   if (CatInfo->pairs.Flags & 0x0001) 
     {
	// Generate the first two letters
	// Use chance information
	Chance = GenerateChance();
	i /= 4;
	
	pair[0] = 0;
	pair[1] = 0;
	
	for (j = 0; j < i; j ++)
	  {
	     Test.c[0] = dataStart[j * 4];
	     Test.c[1] = dataStart[j * 4 + 1];
	     
	     if (Test.i >= Chance)
	       {
		  pair[0] = dataStart[j * 4 + 2];
		  String_AppendChar(s, pair[0]);
		  pair[1] = dataStart[j * 4 + 3];
		  String_AppendChar(s, pair[1]);
		  j = i;
	       }
	  }

	// Just to be safe
	if (pair[0] == 0)
	  {
	     return s;
	  }
	
	// Generate rest of the word
	loop_again = true;
	while (loop_again && pair[1] &&
	       StrLen(s->data) < CatInfo->pairs.MaxLen)
	  {
	     loop_again = false;

	     // Find the right record
	     TargetRec = BinarySearch(Db, startRec, NumRec, pair[0], true);
	     if (TargetRec >= startRec)
	       {
		  // Locate the correct table entry
		  Rec = DmQueryRecord(Db, TargetRec);
		  Hdr = MemHandleLock(Rec);
		  i = 0;  // When done, it is the right table entry
		  j = 0;  // Number of possibilities before the ones we want

		  while (i < Hdr->possible &&
//			 Hdr->table[i].next_letter != pair[1])
			 Hdr->data[i * 2] != pair[1])
		    {
//		       j += Hdr->table[i].possible;  // Move start
		       j += Hdr->data[(i * 2) + 1];		      
		       i ++;  // Move table index
		    }
		  
		  // If we found a matching entry in the table, then the
		  // database is not faulty.  :-)
		  if (i < Hdr->possible)
		    {
		       RecData = &(Hdr->data[Hdr->possible * 2]);
//		       RecData = &(Hdr->table[Hdr->possible].next_letter);
		       Chance = GenerateChance();
//		       for (k = 0; k < Hdr->table[i].possible; k += 3)
		       for (k = 0; k < Hdr->data[(i * 2) + 1]; k ++)
			 {
			    Test.c[0] = ((char *) RecData)[(j + k) * 3];
			    Test.c[1] = ((char *) RecData)[(j + k) * 3 + 1];
			    if (Test.i >= Chance)
			      {
				 pair[0] = pair[1];
				 pair[1] = ((char *) RecData)[(j + k) * 3 + 2];
				 if (pair[1] != '\0')
				   String_AppendChar(s, pair[1]);
//				 k = Hdr->table[i].possible;
				 k = Hdr->data[(i * 2) + 1];
				 loop_again = true;
			      }
			 }
		    }
		  
		  MemHandleUnlock(Rec);
	       }
	  }
     }
   else
     {
	// Generate the first two letters
	// Pick ones at random
	i /= 2;
	i = RollDie(i);
	i --;
	i *= 2;
	
	pair[0] = dataStart[i];
	pair[1] = dataStart[i + 1];
	String_AppendChar(s, dataStart[i]);
	String_AppendChar(s, dataStart[i + 1]);
	
	// Generate rest of the word
	loop_again = true;
	while (loop_again && pair[1] && 
	       StrLen(s->data) < CatInfo->pairs.MaxLen)
	  {
	     loop_again = false;
	     
	     // Find the right record
	     TargetRec = BinarySearch(Db, startRec, NumRec, pair[0], true);
	     if (TargetRec >= startRec)
	       {
		  // Locate the correct table entry
		  Rec = DmQueryRecord(Db, TargetRec);
		  Hdr = MemHandleLock(Rec);
		  i = 0;  // When done, it is the right table entry
		  j = 0;  // Number of possibilities before the ones we want
		  
		  while (i < Hdr->possible &&
//			 Hdr->table[i].next_letter != pair[1])
			 Hdr->data[i * 2] != pair[1])
		    {
//		       j += Hdr->table[i].possible;  // Move start
		       j += Hdr->data[(i * 2) + 1];  // Move start
		       i ++;  // Move table index
		    }
		  
		  // If we found a matching entry in the table, then the
		  // database is not faulty.  :-)
		  if (i < Hdr->possible)
		    {
//		       RecData = &(Hdr->table[Hdr->possible].next_letter);
		       RecData = &(Hdr->data[Hdr->possible * 2]);
		       pair[0] = pair[1];
//		       k = RollDie(Hdr->table[i].possible) + j - 1;
		       k = RollDie(Hdr->data[(i * 2) + 1]) + j - 1;
		       pair[1] = RecData[k];
		       if (pair[1] != '\0')
			 String_AppendChar(s, pair[1]);
		       loop_again = true;
		    }
	     
		  MemHandleUnlock(Rec);
	       }
	  }
     }
   
   return s;
}


// Returns the rule for a specific record.  Does not deal with
// command characters.  It does work with chance data.
sstring *GenerateData_GenCat02_Rule(DmOpenRef Db, UInt32 recordNumber,
				    db_category *CatInfo)
{
   sstring *s;
   union
     {
	char c[2];
	UInt16 i;
     } Test;
   UInt16 Chance;
   MemHandle Rec;
   db_data_psr *RecData;
   UInt32 i = 0, j, Search;
   
   s = String_New();
   
   // Get record
   Rec = DmQueryRecord(Db, recordNumber);
   RecData = MemHandleLock(Rec);
   j = MemHandleSize(Rec) - 4; // Size of UInt16 * 2
   
   // If I need to use chance data ...
   if (RecData->Flags & 0x0001) 
     {
	// Generate chance
	Chance = GenerateChance();

	// Find proper section
	Search = 1;
	while (Search == 1)
	  {
	     if (i + 1 > j)
	       Search = 2;
	     else
	       {
		  Test.c[0] = RecData->data[i ++];
		  Test.c[1] = RecData->data[i ++];
		  if (Chance > Test.i)
		    {
		       while (i < j && RecData->data[i] != '\0')
			 i ++;
		       if (RecData->data[i] == '\0' && i < j)
			 i ++;
		    }
		  else
		    Search = 0;
	       }
	  }
     }
   else
     {
	// Find random section
	Search = RollDie(RecData->Items) - 1;

	// Find proper section
	while (Search && i < j)
	  {
	     if (RecData->data[i] == '\0')
	       Search --;
	     i ++;
	  }
     }
   
   if (Search)
     {
	String_AppendChars(s, "[Invalid database]");
	return s;
     }
   
   // Copy to string
   while (i < j && RecData->data[i] != '\0')
     {
	String_AppendChar(s, RecData->data[i]);
	i ++;
     }
   
   MemHandleUnlock(Rec);
   
   return s;
}


// Phrase structure rule
sstring *GenerateData_GenCat02(DmOpenRef Db, UInt32 startRec, UInt16 NumRec,
			       db_category *CatInfo)
{
   sstring *s, *t, *u;
   UInt32 Replacements, Loops = 0;
   UInt32 i, j;

   s = GenerateData_GenCat02_Rule(Db, startRec, CatInfo);
   Replacements = 1;
   while (Replacements)
     {
	Replacements = 0;
	Loops ++;
	j = StrLen(s->data);
	t = String_New();
	for (i = 0; i < j; i ++)
	  {
	     // At this moment, only care about 0x01
	     // 0x02, 0x07, and 0x08 are taken care of at a higher level
	     if (s->data[i] == 0x01)
	       {
		  if (Loops < 30)
		    {
		       Replacements ++;
		       
		       // Push the flags into the output stream
		       String_AppendChar(t, 0x07);
		       i ++;
		       String_AppendChar(t, s->data[i]);
		       i ++;
		       
		       u = GenerateData_GenCat02_Rule(Db, startRec - 1 +
						      ((UInt32) s->data[i]),
						      CatInfo);
		       String_AppendString(t, u);
		       String_Delete(u);
		    }
		  else
		    {
		       i += 2;
		       String_AppendChars(t, "[Recursion too deep]");
		    }
	       }
	     else if (s->data[i] == 0x02)
	       {
		  String_AppendChar(t, s->data[i]);
		  i ++;
		  String_AppendChar(t, s->data[i]);
		  i ++;
		  String_AppendChar(t, s->data[i]);
	       }
	     else if (s->data[i] == 0x07 || s->data[i] == 0x08)
	       {
		  String_AppendChar(t, s->data[i]);
		  i ++;
		  String_AppendChar(t, s->data[i]);
	       }
	     else
	       {
		  String_AppendChar(t, s->data[i]);
	       }
	  }
	String_Delete(s);
	s = t;
	t = NULL;
     }

   return s;
}


// Determines which type of data this category is and calls the appropriate
// GenerateData_GenCatXX (where XX is the hex code for the type of data).
sstring *GenerateData_GenCategory(DmOpenRef Db, UInt32 startRec, UInt16 NumRec)
{
   sstring *s = NULL;
   MemHandle Rec;
   UInt16 Size;
   db_category *RecData;

   Rec = DmQueryRecord(Db, startRec);
   Size = MemHandleSize(Rec);
   RecData = MemHandleLock(Rec);
   startRec ++;
   NumRec --;
   
   if (Size >= 4) 
     {
	if (RecData->generic.Type == 0)
	  {
	     // Type 0 = random
	     s = GenerateData_GenCat00(Db, startRec, NumRec, RecData);
	  }
	else if (RecData->generic.Type == 1)
	  {
	     // Type 1 = letter pairs
	     s = GenerateData_GenCat01(Db, startRec, NumRec, RecData, Size);
	  }
	else if (RecData->generic.Type == 2)
	  {
	     s = GenerateData_GenCat02(Db, startRec, NumRec, RecData);
	  }
     }
   
   MemHandleUnlock(Rec);
   return s;
}


// Responsible for generating data from the correct category
// Finds the starting record, number of records, and passes
// control over to GenerateData_GenCategory
UInt16 GenerateData_GenCmd2(DmOpenRef Db, sstring *src, UInt32 CurrentPos,
			  UInt32 size, sstring *dest, db_header *hdr,
			  UInt32 hdr_size)
{
   short flags;
   UInt32 startRec, i, Cat;
   sstring *s;

   // Make sure there's enough bytes
   if (CurrentPos + 2 >= size)
     return (size - CurrentPos);
   
   CurrentPos ++;
   flags = src->data[CurrentPos++];
   Cat = src->data[CurrentPos];
   
   // Make sure the category exists
   if (Cat == 0 || sizeof(UInt16) * (Cat - 2) + sizeof(db_header) > hdr_size)
     return 2;
   
   startRec = 1;
   Cat --;
   for (i = 0; i < Cat; i ++)
     startRec += hdr->RecCount[i];

   s = GenerateData_GenCategory(Db, startRec, hdr->RecCount[Cat]);
   
   if (flags) 
     {
	String_AppendChar(dest, 0x07);
	String_AppendChar(dest, flags);
     }
   
   String_AppendString(dest, s);
   String_Delete(s);
   return 2;
}


// Generates the word by calling GenerateData_GenCmd2
// Handles 0x07, 0x08, and 0x02
sstring *GenerateData_GenString(DmOpenRef Db, db_header *hdr, UInt32 hdr_size)
{
   sstring *tempString = NULL;
   sstring *doneString = NULL;
   Boolean loop_again = true;
   UInt32 i, j, loops = 0;
   UInt32 size;
   UInt16 flags;

   if (hdr->Version != 1)
     {
	doneString = String_New();
	String_AppendStringID(doneString, S_InvalidDBVersion);
	return doneString;
     }
   
   tempString = String_New();
   String_AppendStringID(tempString, S_GenerateBase);
	
   while (doneString == NULL && loops < 30)
     {
	loops ++;
	doneString = String_New();
	size = StrLen(tempString->data);

	for (i = 0; i < size; i ++)
	  {
	     if (tempString->data[i] == 0x02)
	       {
		  i += GenerateData_GenCmd2(Db, tempString, i, size, 
					    doneString, hdr, hdr_size);
		  loop_again = true;
	       }
	     else
	       {
		  String_AppendChar(doneString, tempString->data[i]);
	       }
	  }

	String_Delete(tempString);
	if (loop_again) 
	  {
	     tempString = doneString;
	     doneString = NULL;
	     loop_again = false;
	  }
	else
	  {
	     tempString = NULL;
	  }
     }
   tempString = doneString;
   doneString = String_New();
   
   size = StrLen(tempString->data);
   for (i = 0; i < size; i ++)
     {
	if (tempString->data[i] == 0x07)
	  {
	     i ++;
	     if (i < size)
	       {
		  flags = tempString->data[i];
		  // Flag 0x01 must be set so that the byte is not a NULL
		  if (flags & 0x02)
		    {
		       // Capitalize the next letter found
		       j = i + 1;
		       while (j < size && tempString->data[j] < 0x09 && 
			      tempString->data[j] > 0x00)
			 {
			    if (tempString->data[j] <= 0x02)
			      j ++;
			    j += 2;
			 }
		       if (tempString->data[j] >= 'a' &&
			   tempString->data[j] <= 'z')
			 {
			    tempString->data[j] += 'A' - 'a';
			 }
		    }
	       }
	  }
	else if (tempString->data[i] == 0x08)
	  {
	     i ++;
	     String_AppendChar(doneString, tempString->data[i]);
	  }
	else
	  String_AppendChar(doneString, tempString->data[i]);
     }

   String_Delete(tempString);
   
   return doneString;
}


// Opens the database, grabs the header record, calls GenerateData_GenString
void GenerateData_Gen(void) 
{
   DmOpenRef Db;
   MemHandle Rec;
   db_header *s;
   UInt16 Size;
   dbListType *p;
   sstring *tempString = NULL, *multiString = NULL;
   Int16 i;
   
   tempString = NULL;
   
   p = dbListHead;
   Size = GenDB;
   while (p != NULL && Size --)
     p = p->next;

   if (p != NULL)
     {
	CopyStringToLabel(GenerateData_Label, p->Name);
	
	Db = DmOpenDatabase(p->card, p->id, dmModeReadOnly);
	if (Db == false) 
	  {
	     tempString = String_New();
	     String_AppendStringID(tempString, S_ProblemOpeningDatabase);
	     SetAttributeString(GenerateData_Result, tempString->data);
	     String_Delete(generateString);
	     generateString = tempString;
	     return;
	  }
   
	Rec = DmQueryRecord(Db, 0);
	Size = MemHandleSize(Rec);
	s = MemHandleLock(Rec);

	SysCopyStringResource(MiscBuffer, S_Generating);
	SetAttributeString(GenerateData_Result, MiscBuffer);
	tempString = GenerateData_GenString(Db, s, Size);
	
	if (s->Flags & 0x01)
	  {
	     multiString = tempString;
	     for (i = 0; i < 9; i ++)
	       {
		  String_AppendStringID(multiString, S_GenerateMultipleSep);
		  tempString = GenerateData_GenString(Db, s, Size);
		  String_AppendString(multiString, tempString);
		  String_Delete(tempString);
	       }
	     tempString = multiString;
	  }
	
	MemHandleUnlock(Rec);
	DmCloseDatabase(Db);
     }

   if (tempString == NULL)
     tempString = String_New();
   if (tempString->data == NULL)
     String_AppendStringID(tempString, S_BadGenerateDatabase);
   SetAttributeString(GenerateData_Result, tempString->data);
   String_Delete(generateString);
   generateString = tempString;
}


void GenData_UpdateScrollbar(void)
{
   UInt16 topLine, totLines, visLines, maxValue;
   
   FldGetScrollValues(GetObjectPointer(GenerateData_Result),
		      &topLine, &totLines, &visLines);
   
   if (totLines > visLines)
     maxValue = totLines - visLines;
   else if (topLine)
     maxValue = topLine;
   else
     {
	maxValue = 0;
	SetObject(GenerateData_ResultBar, false);
     }
   
   SetObject(GenerateData_ResultBar, true);
   
   SclSetScrollBar(GetObjectPointer(GenerateData_ResultBar), topLine, 0,
		   maxValue, visLines - 1);
}


/* GenerateEventHandler
 * 
 * Handles events on the Generate form.
 */
Boolean GenerateDataEventHandler(EventPtr event)
{
   LocalID id;
   int lines;
   
   if (event->eType == frmOpenEvent)
     {
	HelpText = S_GenerateHelp;
	DrawCurrentForm();
	GenerateData_Gen();
	GenData_UpdateScrollbar();
	return true;
     }
   if (event->eType == ctlSelectEvent)
     {
	id = event->data.ctlEnter.controlID;
	
	if (id == GenerateData_Generate)
	  {
	     GenerateData_Gen();
	     GenData_UpdateScrollbar();
	     return true;
	  }
        if (id == GenerateData_Done)
	  {
	     FrmGotoForm(F_Generate);
	     return true;
	  }
     }
   if (event->eType == keyDownEvent)
     {
	if (event->data.keyDown.chr == pageUpChr)
	  {
	     FldScrollField(GetObjectPointer(GenerateData_Result), 9, winUp);
	     GenData_UpdateScrollbar();
	     return true;
	  }
	if (event->data.keyDown.chr == pageDownChr)
	  {
	     FldScrollField(GetObjectPointer(GenerateData_Result), 9, winDown);
	     GenData_UpdateScrollbar();
	     return true;
	  }
     }
   if (event->eType == sclRepeatEvent)
     {
	lines = event->data.sclRepeat.newValue -
	  event->data.sclRepeat.value;
	if (lines >= 0)
	  FldScrollField(GetObjectPointer(GenerateData_Result),
			 lines, winDown);
	else
	  FldScrollField(GetObjectPointer(GenerateData_Result),
			 - lines, winUp);
	// Do not return true from here
     }
   
   return false;
}

