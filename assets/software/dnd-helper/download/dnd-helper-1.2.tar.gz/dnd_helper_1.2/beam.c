/* D&D Helper - Beaming Functions
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>
#include "version.h"
#include "dnd_helper.h"

Int16 Beam_IsDBInROM(UInt16 card, LocalID lid)
{   
   if (MemLocalIDKind(lid) == memIDHandle)
     return false; // RAM
   
   if (MemPtrHeapID(MemLocalIDToPtr(lid, card)) == 4)
     return false; // Flash

   return true; // ROM
}

Err Beam_ReadThunk(void *datap, UInt32 *sizep, void *rock)
{
   Err error;
   ExgSocketType *sock = rock;
   
   *sizep = ExgReceive(sock, datap, *sizep, &error);
   
   return 0;
}

Boolean Beam_DeleteThunk(const char *name, UInt16 version, UInt16 card,
			 LocalID lid, void *rock)
{  
   Err err;
   char newname[dmDBNameLength], suffixbuf[dmDBNameLength];
   Int16 len, pos, len2;
   Boolean hadold = false;
   Boolean hadnum = false;
   Int16 vernum, verdigit;
   UInt16 attr;
   
   err = DmDatabaseInfo(card, lid, NULL, &attr, NULL, NULL, NULL, NULL, 
			NULL, NULL, NULL, NULL, NULL);
   if (err)
     return false;
   
   if (Beam_IsDBInROM(card, lid))
     return false;
   
   /* Generate an alternate name. If "zob" already exists, for example,
    *      rename it to "zob old", so that a new "zob" can be received. */
   
   len = StrLen(name);
   StrCopy(newname, name);
   
   pos = len;
   vernum = 0;
   verdigit = 1;
   
   while (pos > 0 && newname[pos - 1] >= '0' && newname[pos - 1] <= '9')
     {
	vernum += verdigit * (newname[pos - 1] - '0');
	verdigit *= 10;
	hadnum = true;
	pos --;
     }
   
   while(pos > 0 && newname[pos - 1] == ' ')
     pos--;
   
   if (pos > 3 && newname[pos - 1] == 'd' && newname[pos - 2] == 'l' && 
       newname[pos - 3] == 'o')
     {	
	pos -= 3;
	hadold = true;
	while (pos > 0 && newname[pos - 1] == ' ')
	  pos --;
     }
   
   if (hadold)
     len = pos;
   
   StrCopy(suffixbuf, " old");
   if (hadold)
     {
	if (!hadnum)
	  vernum = 2;
	else
	  vernum++;
	
	suffixbuf[4] = ' ';
	StrIToA(suffixbuf + 5, vernum);
     }
   
   len2 = StrLen(suffixbuf);
   
   if (len > 31 - len2)
     len = 31 - len2;
   
   StrCopy(newname + len, suffixbuf);
   
   /* Rename. */
   err = DmSetDatabaseInfo(card, lid, newname, NULL, NULL, NULL, NULL, 
			   NULL, NULL, NULL, NULL, NULL, NULL);
   if (err)
     return false;
   return true;
}


int Beam_Receive_DB(ExgSocketPtr sock)
{
   Err error = 0;
   LocalID lid;
   UInt16 card = 0;
   Boolean wantreset = false;
   
   // necessary for beaming to PalmOS 4.0 and later
   error = ExgAccept(sock);
   
   error = ExgDBRead(Beam_ReadThunk, Beam_DeleteThunk, sock, &lid, 
		     card, &wantreset, true);
   error = ExgDisconnect(sock, error);
   
   sock->goToCreator = 0;
   
   if (error)
     return error;
   
   if (wantreset)
     {
	Int16 res = FrmAlert(A_WantReset);
	if (res == 1)
	  SysReset();
     }

   return 0;
}


Err Beam_WriteThunk(const void *datap, UInt32 *sizep, void *rock)
{
   Err err = 0;
   ExgSocketType *sock = rock;
   
   *sizep = ExgSend(sock, datap, *sizep, &err);
   
   return err;
}


int Beam_Send_DB(char *name, UInt32 dbid, UInt32 card)
{
   ExgSocketType sock;
   Err err;
   UInt32 size;
   
   DmDatabaseSize(card, dbid, NULL, &size, NULL);
   MemSet(&sock, sizeof(ExgSocketType), 0);
   sock.description = name;
   sock.name = name;
   sock.count = 1;
   sock.length = size;
   sock.type = MIME_TYPE;
   
   err = ExgPut(&sock);
   if (err)
     {
	if (err == exgErrBadLibrary)
	  {
	     FrmAlert(A_CanNotBeam_ExgLib);
	     return err;
	  }
	if (err == exgErrStackInit)
	  {
	     FrmAlert(A_CanNotBeam_IR);
	     return err;
	  }
	if (err == exgMemError)
	  {
	     FrmAlert(A_CanNotBeam_Mem);
	     return err;
	  }
	FrmAlert(A_CanNotBeam_Unknown);
	return err;
     }

   err = ExgDBWrite(Beam_WriteThunk, &sock, name, dbid, card);
   
   err = ExgDisconnect(&sock, err);
   if (err && err != exgErrUserCancel)
     {
	FrmAlert(A_CanNotBeam_Unknown);
     }
   
   return err;
}