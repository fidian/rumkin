/* D&D Helper - Turning Undead
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */


#include <PalmOS.h>	// Pilot functions
#include "dnd_helper.h"	// The ID numbers for everything
#include "input.h"
#include "misc.h"
#include "turning.h"
#include "prefs.h"


void Turn_UpdateTriggers(void)
{
   if (Prefs->Turn_ChaMod < -5)
     Prefs->Turn_ChaMod = -5;
   if (Prefs->Turn_Level < 1)
     Prefs->Turn_Level = 1;

   CopyNumberToLabel(Turn_Charisma_Trigger, Prefs->Turn_ChaMod);
   CopyNumberToLabel(Turn_Level_Trigger, Prefs->Turn_Level);
}


void Turn_Print()
{
   Int16 MaxLevel;
   Int16 NumberTurned;
   
   // Roll a random Turn check
   MaxLevel = RollDie(20) + Prefs->Turn_ChaMod;
   if (MaxLevel <= 0)
     MaxLevel = -4;
   else if (MaxLevel >= 22)
     MaxLevel = 4;
   else
     MaxLevel = ((MaxLevel + 2) / 3) - 4;
   MaxLevel += Prefs->Turn_Level;
   
   // Roll Turning Damage
   NumberTurned = RollDie(6) + RollDie(6) + Prefs->Turn_ChaMod +
     Prefs->Turn_Level;
   
   // Fill in labels
   StrIToA(MiscBuffer, NumberTurned);
   CopyStringToLabel(Turn_Levels_Result, MiscBuffer);
   
   StrIToA(MiscBuffer, MaxLevel);
   CopyStringToLabel(Turn_Max_Result, MiscBuffer);
}


/* TurnEventHandler
 * 
 * Handles events on the Turning Undead form.
 */
Boolean TurnEventHandler(EventPtr event)
{
   LocalID id;
   
   if (event->eType == frmOpenEvent)
     {
	HelpText = S_TurningHelp;
	DrawCurrentForm();
	Turn_UpdateTriggers();
	Turn_Print();
	return true;
     }
   if (event->eType == winEnterEvent && DoWinEnter)
     {
	DoWinEnter = false;
	Turn_UpdateTriggers();
	return true;
     }
   if (event->eType == ctlSelectEvent)
     {
	id = event->data.ctlEnter.controlID;
	
	if (id == Turn_Charisma_Trigger)
	  {
	     InputNumber(S_CharismaModifier, &(Prefs->Turn_ChaMod),
			 INPUT_TARGET_SSHORT, NULL, 99, -5);
	     return true;
	  }
	if (id == Turn_Level_Trigger)
	  {
	     InputNumber(S_PlayerLevel, &(Prefs->Turn_Level), 
			 INPUT_TARGET_SHORT, NULL, 99, 0);
	     return true;
	  }
	if (id == Turn_Button)
	  {
	     Turn_Print();
	     return true;
	  }	
     }
   return false;
}
