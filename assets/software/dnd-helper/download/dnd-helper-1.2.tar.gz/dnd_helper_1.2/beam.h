/* D&D Helper - Beaming Functions (Include File)
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

Int16 Beam_IsDBInROM(UInt16 card, LocalID lid);
Err Beam_ReadThunk(void *datap, UInt32 *sizep, void *rock);
Boolean Beam_DeleteThunk(const char *name, UInt16 version, UInt16 card,
				LocalID lid, void *rock);
Int16 Beam_Receive_DB(ExgSocketPtr sock);
Int16 Beam_Writethunk(const void *datap, UInt32 *sizep, void *rock);
Int16 Beam_Send_DB(char *name, UInt32 dbid, UInt32 card);