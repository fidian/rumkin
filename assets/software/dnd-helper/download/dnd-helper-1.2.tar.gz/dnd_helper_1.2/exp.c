/* D&D Helper - Experience Calculator
 * 
 * Copyright (C) 2002-2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>	// Pilot functions
#include "dnd_helper.h"	// The ID numbers for everything
#include "exp.h"
#include "input.h"
#include "misc.h"
#include "prefs.h"
#include "sstring.h"


/* The experience charts follow some basic formulas with several noticeable
 * exceptions.
 *
 * The difference (the index here) between CR and average player level is
 * the "Diff" -- a team of 8th level players fighting one CR 9 monster has a
 * Diff of -1.
 * 
 * Formulas (X is the average player level)
 * 
 * Diff   Formula                Notes
 * -------------------------------------------------------------------
 *  -7    3600 * x
 *  -6    2400 * x
 *  -5    1800 * x
 *  -4    1200 * x
 *  -3    900 * x
 *  -2    600 * x
 *  -1    450 * x
 *   0    300 * x                Base score, ideal challenge rating
 *   1    200 * x
 *   2    150 * x
 *   3    100 * x
 *   4    75 * x
 *   5    56.25 * x        Round to nearest, .5 rounds up
 *   6    37.5 * x
 *   7    25 * x
 * 
 * As I said earlier, there are exceptions.  Here's the list.  Levels 2
 * and 1 are treated as level 3.
 * 
 * Lvl, CR, Exp
 */
unsigned int Exp_Exceptions[][3] =
{
     { 3, 1, 300 },
     { 3, 6, 2700 },
     { 3, 8, 5400 },
     { 3, 10, 10800 },
     { 4, 1, 300 },
     { 4, 5, 1600 },
     { 4, 7, 3200 },
     { 4, 9, 6400 },
     { 4, 11, 12800 },
     { 5, 1, 300 },
     { 6, 1, 300 },
     { 20, 15, 1000 }, // this was obviously to make numbers even.  :-(
     { 0, 0, 0 }
};

long Exp_BaseMultiplier[15] =
{ 
   360000, 240000, 180000, 120000, 90000, 60000, 45000, 
     30000, 
     20000, 15000, 10000, 7500, 5625, 3750, 2500 
};


long GetExp(int PlayerLvl, int Cr)
{
   int index = 0;
   long Exp;

   if (PlayerLvl < 3)
     PlayerLvl = 3;
   
   while (Exp_Exceptions[index][0] > 0) 
     {
	if (Exp_Exceptions[index][0] == PlayerLvl && 
	    Exp_Exceptions[index][1] == Cr)
	  return (long) Exp_Exceptions[index][2];
	index ++;
     }
   
   // index will now be the difference between levels
   index = PlayerLvl - Cr;
   
   if (index < -7 || index > 7)
     return 0;
   
   Exp = Exp_BaseMultiplier[index + 7] * (long) PlayerLvl;
   // round to nearest, .5 rounds up
   if (Exp % 100 >= 50)
     Exp += 100;
   return Exp / (long) 100;
}


void Exp_Print(void)
{
   long TotalExp;
   sstring *s;
   
   // Caution -- the prefs store the list indexes, not the actual numbers
   TotalExp = GetExp(Prefs->Exp_PlayerLvl, Prefs->Exp_EnemyCr);
   if (TotalExp > 0)
     {
	TotalExp *= (long) (Prefs->Exp_EnemyNum);
	
	StrIToA(MiscBuffer, TotalExp);
	CopyStringToLabel(Total_Exp_Result, MiscBuffer);
	
	TotalExp /= (long) (Prefs->Exp_PlayerNum);
	
	StrIToA(MiscBuffer, TotalExp);
	CopyStringToLabel(Player_Exp_Result, MiscBuffer);
     }
   else
     {
	s = String_New();
	String_AppendStringID(s, S_SeeHelp);
	CopyStringToLabel(Total_Exp_Result, s->data);
	CopyStringToLabel(Player_Exp_Result, s->data);
	String_Delete(s);
     }
}


void Exp_UpdateTriggers(void)
{
   if (Prefs->Exp_PlayerNum < 1)
     Prefs->Exp_PlayerNum = 1;
   if (Prefs->Exp_PlayerLvl < 1)
     Prefs->Exp_PlayerLvl = 1;
   if (Prefs->Exp_EnemyNum < 1)
     Prefs->Exp_EnemyNum = 1;
   if (Prefs->Exp_EnemyCr < 1)
     Prefs->Exp_EnemyCr = 1;

   CopyNumberToLabel(Exp_PlayerNum_Trigger, Prefs->Exp_PlayerNum);
   CopyNumberToLabel(Exp_PlayerLvl_Trigger, Prefs->Exp_PlayerLvl);
   CopyNumberToLabel(Exp_EnemyNum_Trigger, Prefs->Exp_EnemyNum);
   CopyNumberToLabel(Exp_EnemyCr_Trigger, Prefs->Exp_EnemyCr);
}


/* ExperienceEventHandler
 * 
 * Handles events on the Experience Calculator form.
 */
Boolean ExperienceEventHandler(EventPtr event)
{
   LocalID id;
   
   if (event->eType == frmOpenEvent)
     {
	HelpText = S_ExpHelp;
	DrawCurrentForm();
	Exp_UpdateTriggers();
	Exp_Print();
	return true;
     }
   if (event->eType == winEnterEvent && DoWinEnter)
     {
	DoWinEnter = false;
	Exp_UpdateTriggers();
	Exp_Print();
	return true;
     }
   if (event->eType == ctlSelectEvent)
     {
	id = event->data.ctlEnter.controlID;
	
	if (id == Exp_PlayerNum_Trigger)
	  {
	     InputNumber(S_NumberOfPlayers, &(Prefs->Exp_PlayerNum),
			 INPUT_TARGET_SHORT, NULL, 99, 0);
	     return true;
	  }
	if (id == Exp_PlayerLvl_Trigger)
	  {
	     InputNumber(S_AveragePlayerLevel, &(Prefs->Exp_PlayerLvl),
			 INPUT_TARGET_SHORT, NULL, 99, 0);
	     return true;
	  }
	if (id == Exp_EnemyNum_Trigger)
	  {
	     InputNumber(S_NumberOfEnemies, &(Prefs->Exp_EnemyNum),
			 INPUT_TARGET_SHORT, NULL, 99, 0);
	     return true;
	  }
	if (id == Exp_EnemyCr_Trigger)
	  {
	     InputNumber(S_EnemyChallengeRating, &(Prefs->Exp_EnemyCr),
			 INPUT_TARGET_SHORT, NULL, 99, 0);
	     return true;
	  }
     }
   return false;
}
