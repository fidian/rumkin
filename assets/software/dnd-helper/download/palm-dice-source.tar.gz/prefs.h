/* Palm Dice - Preferences (Include File)
 * 
 * Copyright (C) 2002-2004 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>


#ifndef PREFS_H
#define PREFS_H

#define SSTRING_BLOCK_SIZE 128

typedef struct
{
   // Palm OS does a four-byte alignment kind of thing.
   UInt16 PrefsVersion;

   UInt8 Die_Num;
   UInt8 Die_Sides;  // Word 1
   UInt8 Die_Modifier;
} PrefType;

typedef struct sstring
{
   char *data;
   UInt32 size;
   struct sstring *next;
} sstring;

#ifdef PALM_DICE_C
#define MAYBE_EXTERN
#else
#define MAYBE_EXTERN extern
#endif
MAYBE_EXTERN PrefType *Prefs;
MAYBE_EXTERN char MiscBuffer[80];
MAYBE_EXTERN LocalID HelpText;
MAYBE_EXTERN sstring *sstringHead;
MAYBE_EXTERN sstring *dieString;

void Prefs_SetupDefaultPrefs(UInt32);

#endif