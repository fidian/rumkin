/* Palm Dice - Main File
 * 
 * Copyright (C) 2002-2004 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#define PALM_DICE_C

#include <PalmOS.h>

#include "die.h"
#include "misc.h"
#include "palm_dice.h"
#include "prefs.h"
#include "sstring.h"
#include "version.h"


void HandleMenuEvent(EventPtr event)
{
   int id;
   
   id = event->data.menu.itemID;

   if (id == Menu_About)
     {
	FrmCustomAlert(A_Version, APP_VERSION, COMPILE_DATE, NULL);
	return;
     }
  if (id == Menu_Help)
     {
	FrmHelp(S_DieHelp);
	return;
     }
   if (id == Menu_License)
     {
	FrmHelp(S_Disclaimer);
	return;
     }
}


static void EventLoop(void)
{
   short err;
   EventType event;
   LocalID formID;
   FormPtr form;
   
   do
    {
       // Wait indefinitely for an event -- screw the null events
       EvtGetEvent(&event, -1);
       
       if (! SysHandleEvent(&event))
	 {
	    if (! MenuHandleEvent(MenuGetActiveMenu(), &event, &err))
	      {
		 if (event.eType == menuEvent)
		   HandleMenuEvent(&event);
		 else
		   {
		      if (event.eType == frmLoadEvent)
			{
			   formID = event.data.frmLoad.formID;
			   form = FrmInitForm(formID);
			   FrmSetActiveForm(form);
			   FrmSetEventHandler(form, DieEventHandler);
			}
		      else
			FrmDispatchEvent(&event);
		   }
	      }
	 }
    } while (event.eType != appStopEvent);
}


static Boolean StartApplication(void)
{
   UInt16 Size;
   Int32 Result;
   
   // Load the preferences into allocated memory
   // Don't use GetMemory() here because we want to return true instead
   // of pressing the app launch button
   Size = sizeof(PrefType);
   
   Prefs = (PrefType *) MemPtrNew(Size);
   if (Prefs == (PrefType *) NULL)
     {
	SysCopyStringResource(MiscBuffer, S_LoadingThePreferences);
	SysCopyStringResource(&(MiscBuffer[40]), S_IMustExitPalmDice);
	FrmCustomAlert(A_OutOfMemory, MiscBuffer, &(MiscBuffer[40]), NULL);
	return true;
     }
   MemSet(Prefs, Size, 0);
   Result = PrefGetAppPreferences(APPLICATION_ID, 0, Prefs, &Size, 1);
   if (Result == noPreferenceFound || 
       Size != sizeof(PrefType))
     {
	Prefs_SetupDefaultPrefs(Size);
     }

   FrmGotoForm(F_Start);
   
   return 0;
}


static void StopApplication(void)
{
   if (Prefs != (PrefType *) NULL) 
     {
	// Save preferences
	PrefSetAppPreferences(APPLICATION_ID, 0, Version1, Prefs,
			      sizeof(PrefType), 1);
	
	// Deallocate memory
	MemPtrFree(Prefs);
     }
   
   String_DeleteAll();
	
   // Delete any open forms.
   // This seems stupid, but if there are any open forms, Palm Dice
   // might not get a frmCloseForm event for them, leaking memory.
   FrmCloseAllForms();
}


/* I am a stone  [Enemy at the Gates] */
UInt32  PilotMain (UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{
   int error;
   UInt32 romVersion;

   // Make sure we are running on Palm OS 2.0 or later
   FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
   if (romVersion < sysMakeROMVersion(2, 0, 0, sysROMStageRelease, 0))
     {
	if ((launchFlags & (sysAppLaunchFlagNewGlobals |
			   sysAppLaunchFlagUIApp)) ==
	    (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
	  {
	     AlertAndLeave(A_RomIncompatible);
	  }
	
	return sysErrRomIncompatible;
     }
	
   if (cmd == sysAppLaunchCmdNormalLaunch)
     {	
	error = StartApplication();
	if (error) return error;
	
	EventLoop();
	
	StopApplication();
	return 0;
     }
   
   return 0;
}
