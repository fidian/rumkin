/* Palm Dice - Miscellaneous Functions
 * 
 * Copyright (C) 2002-2004 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#define MISC_C

#include <PalmOS.h>
// include <StringMgr.h>
#include "misc.h"
#include "prefs.h"
#include "palm_dice.h"

void AlertAndLeave(LocalID AlertID)
{
   EventType newEvent;

   if (AlertID)
     FrmAlert(AlertID);
	
   // It looks like this is CodeWarrior only ... sysFileCDefaultApp
   // isn't resolved.
   // 
   // AppLaunchWithCommand(sysFileCDefaultApp, 
   //                      sysAppLaunchCmdNormalLaunch, NULL);
   //
   // alternate method:

   newEvent.eType = keyDownEvent;
   newEvent.data.keyDown.chr = launchChr;
   newEvent.data.keyDown.modifiers = commandKeyMask;
   EvtAddEventToQueue(&newEvent);
}


void SetListAndPopup(LocalID ListId, LocalID PopupId, UInt16 index)
{
   ListPtr listp;
   ControlPtr popp;
   UInt16 Items;
   FormPtr formPtr;

   formPtr = FrmGetActiveForm();
   listp = FrmGetObjectPtr(formPtr, FrmGetObjectIndex(formPtr, ListId));
   
   Items = LstGetNumberOfItems(listp);
   if (index < Items && index >= 0)
     {
	LstSetSelection(listp, index);
	LstMakeItemVisible(listp, index);
	LstDrawList(listp);
	popp = FrmGetObjectPtr(formPtr, FrmGetObjectIndex(formPtr, PopupId));
	CtlSetLabel(popp, LstGetSelectionText(listp, index));
     }
}


UInt16 GetListIndex(LocalID id)
{
   ListPtr listp;
   FormPtr formPtr;
   
   formPtr = FrmGetActiveForm();
   listp = FrmGetObjectPtr(formPtr, FrmGetObjectIndex(formPtr, id));
   return LstGetSelection(listp);
}


void SetAttributeString(LocalID id, char *buffer)
{
   MemHandle targetHandle;
   char *targetText;
   FieldPtr targetPtr;
   FormPtr formPtr;
   
   formPtr = FrmGetActiveForm();
   targetPtr = FrmGetObjectPtr(formPtr, FrmGetObjectIndex(formPtr, id));
   
   targetHandle = FldGetTextHandle(targetPtr);
   if (targetHandle)
     FldFreeMemory(targetPtr);

   targetHandle = MemHandleNew(StrLen(buffer) + 1);
   targetText = MemHandleLock(targetHandle);
   StrCopy(targetText, buffer);
   MemHandleUnlock(targetHandle);
   FldSetTextHandle(targetPtr, targetHandle);
   FldDrawField(targetPtr);
}


void DrawCurrentForm(void)
{
   FrmDrawForm(FrmGetActiveForm());
}


// Make sure Sides is less than 0x7FFF
UInt16 RollDie(UInt16 Sides)
{
   Int16 Max;
   Int16 Result;

   // If there is a number between Max and sysRandomMax, then
   // we must discard it in order to not bias the random numbers
   Max = sysRandomMax / Sides;
   Max *= Sides;
   
   do 
     {
	// Most likely, this will only be called once.
	Result = SysRandom(0);
     }
   while (Result >= Max);
   
   // Return a number from 1 to Sides
   return (Result % Sides) + 1;
}


char *FloatToString(float Value, Int16 Precision, Boolean TrimZeros)
{
   char Pos;
   double RoundingFactor;
   static char buffer[20];

   // Round the number here
   Pos = Precision;
   RoundingFactor = 0.5;
   while (Pos --)
     {
	RoundingFactor /= 10.0;
     }

   
   // Take care of the whole number part.
   // Handle negatives differently.
   Pos = 0;
   if (Value < 0.0)
     {
	// Can't just use StrIToA(buffer, (Long) Value) because if
	// Value is -0.1, (Long) Value is -0 which shows up as 0.
	buffer[0] = '-';
	Value = 0.0 - Value;
	Pos = 1;
     }

   Value += RoundingFactor;
   StrIToA(&(buffer[Pos]), (Int32) Value);
   Value -= (Int32) Value;
   Pos = StrLen(buffer);

   // At this point, buffer contains the integer part and sign
   // Pos is where the null is
   // Value is the remainder (no more whole numbers) and is positive
   
   if (Precision)
    {
       buffer[Pos ++] = '.';
       while (Precision)
	 {
	    Value *= 10.0;
	    buffer[Pos ++] = '0' + (UInt8) Value;
	    Value -= (UInt8) Value;
	    Precision --;
	 }
       buffer[Pos] = '\0';
       
       // Trim off trailing zeros if so desired
       if (TrimZeros)
	 {
	    Pos --;
	    while ((buffer[Pos] == '0' || buffer[Pos] == '.') && Pos >= 1)
	      {
		 if (buffer[Pos] == '.')
		   {
		      buffer[Pos] = '\0';
		      return buffer;
		   }
		 buffer[Pos] = '\0';
		 Pos --;
	      }
	 }
    }
   
   return buffer;
}


void *GetMemory(UInt32 Size, LocalID ErrStr)
{
   void *v;
   
   v = MemPtrNew(Size);
   
   if (v == NULL)
     {
	SysCopyStringResource(MiscBuffer, ErrStr);
	SysCopyStringResource(&(MiscBuffer[40]), S_IMustExitPalmDice);
	FrmCustomAlert(A_OutOfMemory, MiscBuffer, &(MiscBuffer[40]), NULL);
	AlertAndLeave(0);
     }
   
   return v;
}
