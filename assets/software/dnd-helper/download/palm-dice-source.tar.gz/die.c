/* Palm Dice - Die Roller
 * 
 * Copyright (C) 2002-2004 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>	// Pilot functions
#include "palm_dice.h"	// The ID numbers for everything
#include "die.h"
#include "misc.h"
#include "prefs.h"
#include "sstring.h"

// Make sure this corresponds to the list!
UInt8 DieSides[] = { 2, 3, 4, 6, 8, 10, 12, 20, 100 };

// Sides must be less than 0x7FFF
void Die_Roll(UInt16 Dice, UInt16 Sides)
{
   Boolean addComma = false;
   UInt8 RandomDie;
   UInt32 Total = 0;
   float partial;
   sstring *s;

   s = String_New();
   while (Dice) 
     {
	RandomDie = (UInt8) RollDie(Sides) + (UInt8) Prefs->Die_Modifier;
	if (addComma) 
	  {
	     String_AppendStringID(s, S_ValueSeparator);
	  }
	else if (Prefs->Die_Modifier != 0)
	  {
	     String_AppendStringID(s, S_ModifiedRolls);
	  }

	StrIToA(MiscBuffer, RandomDie);
	String_AppendChars(s, MiscBuffer);
	
	Dice --;
	addComma = true;
	Total += RandomDie;
     }
   
   // Total
   String_AppendStringID(s, S_DieTotal);
   StrIToA(MiscBuffer, Total);
   String_AppendChars(s, MiscBuffer);
   
   // Half
   partial = Total;
   partial /= 2;
   String_AppendStringID(s, S_OneHalf);
   String_AppendChars(s, FloatToString(partial, 1, true));

   // One Quarter
   partial /= 2;
   String_AppendStringID(s, S_OneQuarter);
   String_AppendChars(s, FloatToString(partial, 2, true));

   SetAttributeString(Die_Result, s->data);
   
   String_Delete(dieString);
   dieString = s;
}


/* DieEventHandler
 * 
 * Handles events on the Die Roller form.
 */
Boolean DieEventHandler(EventPtr event)
{
   LocalID id;
   
   if (event->eType == frmOpenEvent)
     {
	if (Prefs->Die_Modifier > 10)
	  Prefs->Die_Modifier = 0;
	HelpText = S_DieHelp;
	DrawCurrentForm();
	SetListAndPopup(Die_Num_List, Die_Num_Popup, Prefs->Die_Num);
	SetListAndPopup(Die_Sides_List, Die_Sides_Popup, Prefs->Die_Sides);
	SetListAndPopup(Die_Modifier_List, Die_Modifier_Popup, 
			Prefs->Die_Modifier);
	return true;
     }
   if (event->eType == popSelectEvent)
     {
	Prefs->Die_Num = GetListIndex(Die_Num_List);
	Prefs->Die_Sides = GetListIndex(Die_Sides_List);
	Prefs->Die_Modifier = GetListIndex(Die_Modifier_List);
	// Don't return true and the OS will update our popup triggers
	return false;
     }
   if (event->eType == ctlSelectEvent)
     {
	id = event->data.ctlEnter.controlID;
	
	if (id == Die_Roll_Button)
	  {
	     Die_Roll(Prefs->Die_Num + 1, DieSides[Prefs->Die_Sides]);
	     return true;
	  }
     }
   return false;
}
