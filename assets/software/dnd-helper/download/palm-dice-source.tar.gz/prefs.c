/* Palm Dice - Preferences
 * 
 * Copyright (C) 2002-2004 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

#include <PalmOS.h>
#include "prefs.h"

void Prefs_SetupDefaultPrefs(UInt32 BytesLoaded)
{
   if (BytesLoaded < 2) 
     {
	// Set everything to zero
	MemSet(Prefs, sizeof(PrefType), 0);
	
	// Initialize
	Prefs->Die_Modifier = 10;   // 0
	return;
     }
   
   if (BytesLoaded < sizeof(PrefType))
     {
	// Initialize just what we need to
	Prefs->Die_Modifier = 10;  // 0
	return;
     }   
}
