/* Palm Dice - Miscellaneous Functions (Include File)
 * 
 * Copyright (C) 2002-2004 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for more information.
 * See http://rumkin.com/projects/dnd_helper/ for more information about
 * the software.
 * 
 * $Id$
 */

void AlertAndLeave(LocalID AlertID);
void SetListAndPopup(LocalID ListId, LocalID PopupId, UInt16 index);
UInt16 GetListIndex(LocalID id);
void SetAttributeString(LocalID id, char *buffer);
void DrawCurrentForm(void);
UInt16 RollDie(UInt16 Sides);
char *FloatToString(float Value, Int16 Precision, Boolean TrimZeros);
void *GetMemory(UInt32 Size, LocalID ErrStr);
