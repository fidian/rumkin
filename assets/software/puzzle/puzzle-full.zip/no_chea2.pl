#!/usr/bin/perl

print "Content-type: text/html\n\n";


# Delete old puzzle keys (older than 1 day)
opendir(DIR, "keys/");
@Files = readdir(DIR);
closedir(DIR);

foreach $File (@Files)
{
    next if (-d "keys/$File");		# Is it a directory?
    next if ($File !~ /^[0-9]+$/);	# Is the filename all numbers?
    next if (! -z "keys/$File");	# Is an empty file?
    
    # Good -- valid key file
    if (-M "keys/$File" > 86400)	# if last modified over 1 day ago
    {
        unlink("keys/$File");		# Delete
    }
}



# Generate the key
$PassedIn = $ENV{'QUERY_STRING'};
# Steal the length from the first character
$Length = substr($PassedIn, 0, 1);
$Key = substr($PassedIn, 1, $Length);
$PassedIn = substr($PassedIn, $Length + 1);

# Please see the no_cheat.cgi for comments below this point
$FirstKey = "";
$SecondKey = "";		
srand($Length . $Key);

$Num = int(rand(10));		
while ($Num > 0)		
{
    $Num --;
    $FirstKey .= int(rand(10));
}

$Num = int(rand(30));
while ($Num > 0)
{				
    $Num --;
    $SecondKey .= int(rand(10));
}


# At this point, we recreated the real key, length, second key, and the
# second half of the first key.  We now see if it matches.
if ($PassedIn =~ /^$FirstKey(.*)$SecondKey$/)
{
    $Moves = $1;
    if (-e "keys/$Key")
    {
	unlink ("keys/$Key");
    	GoodPage($Moves);
    }
    else
    {
        PossiblyHacker();
    }
}
else
{
    PossiblyHacker();
}


# If it is good, here is the routine you can alter to add their score to the
# high score list.
sub GoodPage
{
    my ($Moves) = @_;
    
    print "<HTML><HEAD><TITLE>Java Puzzle Applet</TITLE>
</HEAD><BODY BACKGROUND=\"backdrop.jpg\">
<H1 ALIGN=CENTER>Java Puzzle Applet - 'Secure' <FONT SIZE=+0>(Mickey)</FONT></H1>
<CENTER><P>
<HR WIDTH=\"100%\"></P></CENTER>

<P>You solved it in $Moves moves!</P>

<P><A HREF=\"index.html\">Back to the main puzzle page</a>.</p>

<IMG src=\"Mickey.jpg\">

</BODY>
</HTML>\n";
}

# Uh-ho ... possible cheater.  You might want to log IP addresses, the
# username of the person entering your site, the browser, etc.  That way
# if they figure out what we are doing (quite likely), then they could
# still be blocked.
sub PossiblyHacker
{
    print "<HTML><HEAD><TITLE>Java Puzzle Applet</TITLE>
</HEAD><BODY BACKGROUND=\"backdrop.jpg\">
<H1 ALIGN=CENTER>Java Puzzle Applet - 'Secure' <FONT SIZE=+0>(Mickey)</FONT></H1>
<CENTER><P>
<HR WIDTH=\"100%\"></P></CENTER>

<P>I detect a possible hack.  One of the following things happened:</P>

<ul>
<li>You hit 'back' and then re-solved the puzzle.  Please do not do that.
Use your browser's 'reload' or 'refresh' button on the puzzle page to get
a new puzzle sent to you, then solve it again.</li>
<li>You tried to change your number of moves.  Guess that didn't work.</li>
<li>Your browser doesn't fully support Java 1.0 -- find a different or newer
browser.</li>
<li>It took you over one day to solve the puzzle.  Try to solve them 
faster.</li>
</ul>

<P><A HREF=\"index.html\">Back to the main puzzle page</a>.</p>

</BODY>
</HTML>\n";
}
