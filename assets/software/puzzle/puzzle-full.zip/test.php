<HTML> 
  <HEAD> 
    <TITLE>Java Puzzle Applet</TITLE> 
  </HEAD> 
  <BODY BACKGROUND="backdrop.jpg"> 
    <H1 ALIGN="CENTER">Java Puzzle Applet - Swap <FONT
      SIZE="+0">(Mickey)</FONT></H1> <HR WIDTH="100%"> 
    <P>You solved it in <?= $moves ?> moves!</P> 
    <P><A HREF="index.html">Back to the main puzzle page</A>.</P>
    <P ALIGN="CENTER"><IMG SRC="distrib/Mickey.jpg" WIDTH="512" HEIGHT="385"></P>
    </BODY>
</HTML>
