#!/usr/bin/perl

# Print the response type
print "Content-type: text/html\n\n";


# Generate the key
$Key = int(time() / $$);	# Current time / process id
				# For this script, $Key must be <= to
			        # 9 digits long
$Length = length($Key);		# Figure out the length
$FirstKey = $Length . $Key;	# FirstKey = Key before moves
$SecondKey = "";		# SecondKey = Key after moves
srand($FirstKey);		# Seed the random number generator

$Num = int(rand(10));		# Generate up to 10 random digits and
while ($Num > 0)		# append to FirstKey
{
    $Num --;
    $FirstKey .= int(rand(10));
}

$Num = int(rand(30));		# Generate up to 30 random digits and
while ($Num > 0)		# make that SecondKey
{
    $Num --;
    $SecondKey .= int(rand(10));
}



# Now that the keys are generated, add them to the database.
# Please note that you should include file locking and other nifty features
# if you plan on having traffic.  You can use a real database, a directory
# with files in it, etc.  I will pick the directory, because that is easy
# to implement.

# Just make an empty file.
open(FILE, "> keys/$Key");
close(FILE);


# Print out the HTML page, making sure to specify the keys that were
# generated in the applet's tags.
print "<HTML><HEAD><TITLE>Java Puzzle Applet</TITLE>
</HEAD><BODY BACKGROUND=\"backdrop.jpg\">

<H1 ALIGN=CENTER>Java Puzzle Applet - Secure <FONT SIZE=+0>(Mickey)</FONT></H1>

<CENTER><P>
<HR WIDTH=\"100%\"></P></CENTER>

<P>This is a demo of my 'secure' applet.  Hope you like it.  You should know
how to play by now.</p>

<CENTER>
<P>
<APPLET code=\"puzzle.class\" width=512 height=405>
<PARAM name=numx value=6>
<PARAM name=numy value=4>
<PARAM name=src value=Mickey.jpg>
<PARAM name=url value=no_chea2.pl>
<PARAM name=prefixurl value="$FirstKey">
<PARAM name=postfixurl value="$SecondKey">
</APPLET>
</P>
</CENTER>

</BODY>
</HTML>\n";
