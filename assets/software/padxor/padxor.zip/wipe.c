/* Note:  This might actually not wipe the files.
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define VERSION "1.0"

#define USAGE "\n\
wipe:  Wipes a file repeatedly with random data, version %s\n\
\n\
Usage:\n\
    wipe <file> [passes]\n\
\n\
file:  The file to overwrite\n\
passes:  Optional parameter with the number of passes to wipe the file\n\
\n"


void WipeFile(FILE *fp)
{
   unsigned long bytes;
   unsigned int i;
   
   fseek(fp, 0, SEEK_END);
   bytes = ftell(fp);
   fseek(fp, 0, SEEK_SET);
   
   while (bytes --)
     {
	fputc(rand() & 0xFF, fp);
     }
}


int main(int argc, char **argv)
{
   unsigned long passes = 0;
   FILE *fp;

   srand((unsigned int) time(NULL));
   
   if (argc < 2)
     {
	printf(USAGE);
	return 1;
     }
   
   fp = fopen(argv[1], "r+");
   if (! fp)
     {
	printf("Unable to open file %s\n", argv[1]);
	return 2;
     }
   
   if (argc >= 3)
     {
	passes = atol(argv[2]);
     }
   if (passes < 1)
     passes = 1;
   
   printf("Wiping file with %ld passes\n", passes);
   
   while (passes --)
     {
	WipeFile(fp);
     }

	printf("Done.\n");

	return 0;
}
