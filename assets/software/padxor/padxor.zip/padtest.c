/* Code taken from otp.c 0.9.4
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>	/* log() - linux: use gcc -lm */

#define VERSION "1.0"

#define USAGE "\n\
padtest:  Tests a One Time Pad for randomness\n\
\n\
Usage:\n\
    padtest <file>\n\
\n\
file:  The pad to test.\n\
\n"

int main(int argc, char **argv)
{
   FILE *fp; 
   long il, n, fo[256], mt[256]; 
   int i, x, y;
   double fe, chisq, sval, mv, md, sxy, syy, r, m;
   static int chisq_df255[2][10] = /* chisq |-> significance */
     {{ 310, 293, 284, 270, 254, 239, 227, 219, 205,   0 },
	  {   1,   5,  10,  25,  50,  75,  90,  95,  99, 100 }};

   if (argc < 2)
     {
	printf(USAGE);
	return 1;
     }
   
   for (i = 0, sxy = syy = m = 0.0; i < 256; i++) 
     mt[i] = fo[i] = 0;
   
   fp = fopen(argv[1], "rb");
   if (! fp)
     {
	printf("Error opening file %s\n", argv[1]);
	return 2;
     }
   
   fseek(fp, 0, SEEK_END);
   if (!(n = ftell(fp))) 
     { 
	printf("No data!\n");
	return 3;
     }
   
   fe = n/256.0; 
   rewind(fp);

   x = getc(fp); 
   sval = x; 
   fo[x]++; 
   il = 0;
   
   while ((y = getc(fp)) != EOF) 
     {
	sval += y; 
	fo[y]++;
	sxy  += (x - 127.5) * (y - 127.5); 
	syy += (y - 127.5) * (y - 127.5); 
	x = y;
	if (il >= 2560) 
	  { 
	     m += log(il - mt[y])/0.693147180559945; 
	  } 
	mt[y] = il++;
     }

   mv = sval/n; 
   md = (mv - 127.5) * (mv - 127.5) * n / 127.5; /* kludge */
   
   printf("\n For %ld bytes, mean value = %.4f (random = 127.5) - %s\n",
	  n, mv, (md > 300) ?  "SUSPICIOUS" : "PASS");

   if (syy) 
     r = sxy/syy; 
   else 
     r = 1.0; /* Pearson's r (simplified) */
   
   printf(" Serial correlation = %.4f (random = 0.0) - %s\n",
	  r, (int) (r * 100) ?  "SUSPICIOUS" : "PASS");
   
   m = (m/(n - 2560) - 7.1836656) / 1.799; /* -> N(0,1) */
   
   printf(" Maurer's universal = %.4f (random = 0.0) - %s\n",
	  m, (int) (m * 10) ?  "SUSPICIOUS" : "PASS");

   for (i = 0, chisq = -n; i < 256; i++) 
     chisq += (double) fo[i] * fo[i] / fe;
   for (i = 0; i < 10; i++) 
     if (chisq_df255[0][i] <= chisq) 
       break;
   
   printf(" Chi-square = %.1f, exceeded by %c%d%% of random sequences - %s\n",
	  chisq, (i == 0) ? '<' : (i == 8) ? '>' : '~', chisq_df255[1][i],
	  (i < 2 || i > 7 || n < 5*256) ? "SUSPICIOUS" : "PASS");
   
	printf("\nAnalysis complete.\n");

	return 0;
}
