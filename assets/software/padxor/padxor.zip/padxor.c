#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define VERSION "1.0"

#define USAGE "\n\
padxor: En/Decrypt a file with a One Time Pad, version %s\n\
\n\
Usage:\n\
    padxor [options] <infile> <padfile> <outfile>\n\
\n\
Options:\n\
    -s <byte>    Start using the padfile at the byte specified\n\
    -l           Loop the padfile when running out of bytes (bad security!)\n\
    -b           Show what byte was last used in the pad file\n\
    -r           Start at a random byte in the pad file (interesting)\n\
    -x <num>     XOR each byte in the padfile with <num> (from 0 to 255)\n\
    -i           Increment -x number by 1 for every loop when using -l\n\
\n\
infile:  The file to encrypt\n\
padfile:  The One Time Pad\n\
outfile:  The file to write\n\
\n", VERSION


// Show the usage
void ShowUsage(void)
{
   printf(USAGE);
   exit(1);
}


// The XOR function
void CryptFile(FILE *infp, FILE *padfp, FILE *outfp, int do_loop, int xor_pad,
	       int xor_inc)
{
	int i, j;

	printf("Encrypting/Decrypting file ...\n");
	i = fgetc(infp);
	while (i != EOF)
     {
	j = fgetc(padfp);
	if (j == EOF)
	  {
	     if (do_loop)
	       {
		  rewind(padfp);
		  j = fgetc(padfp);
		  if (xor_inc)
		    xor_pad = (xor_pad + 1) & 0xFF;
	       }
	     
	     // To avoid problems with a 0-byte pad file
	     if (j == EOF)
	       {
		  printf("ERROR:  Ran out of bytes in the pad file\n");
		  printf("Aborting.\n");
		  exit(10);
	       }
	  }
	fputc(i ^ j ^ xor_pad, outfp);
	i = fgetc(infp);
     }
}


// The main function
int main(int argc, char **argv)
{
   unsigned long startByte = 0;
   double d;
   int do_loop = 0, show_lastbyte = 0, start_random = 0, arg, xor_pad = 0,
     xor_inc = 0;
   char *infile = NULL, *padfile = NULL, *outfile = NULL;
   FILE *infp, *padfp, *outfp;
   
   // Process arguments
   for (arg = 1; arg < argc; arg ++)
     {
	if (argv[arg][0] == '-')
	  {
	     if (argv[arg][1] == 's')
	       {
		  arg ++;
		  if (arg < argc)
		    startByte = atol(argv[arg]);
		  else
		    ShowUsage();
	       }
	     else if (argv[arg][1] == 'l')
	       {
		  do_loop = 1;
	       }
	     else if (argv[arg][1] == 'b')
	       {
		  show_lastbyte = 1;
	       }
	     else if (argv[arg][1] == 'r')
	       {
		  start_random = 1;
	       }
	     else if (argv[arg][1] == 'x')
	       {
		  arg ++;
		  if (arg < argc)
		    xor_pad = atoi(argv[arg]);
		  else
		    ShowUsage();
	       }
		  else if (argv[arg][1] == 'i')
	       {
		  xor_inc = 1;
	       }
	     else
	       ShowUsage();
	  }
	else
	  {
	     if (infile == NULL)
	       infile = argv[arg];
	     else if (padfile == NULL)
	       padfile = argv[arg];
	     else if (outfile == NULL)
	       outfile = argv[arg];
	     else
	       ShowUsage();
	  }
     }
   
   if (outfile == NULL)
     ShowUsage();
	     
   printf("padxor %s\n", VERSION);
   
   infp = fopen(infile, "rb");
   if (! infp)
     {
	printf("Error opening input file %s\n", infile);
	return 2;
     }

   padfp = fopen(padfile, "rb");
   if (! padfp)
     {
	printf("Error opening input file %s\n", padfile);
	return 3;
     }
   
   fseek(padfp, startByte, SEEK_SET);
   
   if (start_random)
     {
	fseek(padfp, 0, SEEK_END);
	startByte = ftell(padfp);
	srand((unsigned int) time(NULL));
	d = (double) rand() / (double) RAND_MAX;
	d *= (double) startByte;
	startByte = (unsigned long) d;
	fseek(padfp, startByte, SEEK_SET);
	printf("Starting at byte %ld\n", startByte);
     }

   outfp = fopen(outfile, "wb");
   if (! outfp)
     {
	printf("Error opening input file %s\n", outfile);
	return 4;
     }
   
   CryptFile(infp, padfp, outfp, do_loop, xor_pad, xor_inc);
   
   if (show_lastbyte)
     {
	startByte = ftell(padfp) - 1;
	printf("Last byte used:  %ld\n", startByte);
     }

   printf("Done.\n");
   
   // No problems, leave now.
   return 0;
}
