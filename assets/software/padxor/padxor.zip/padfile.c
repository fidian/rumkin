#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define VERSION "1.0"

#define USAGE "\n\
padfile: Generate a random One Time Pad from a file, version %s\n\
\n\
Usage:\n\
    padfile <output_file> <input_file> [input_file [...]]\n\
\n\
input_file:  The source file\n\
output_file:  The pad file to write\n\
\n\
It is a good idea to use a large, detailed .jpg file or a compressed file\n\
as the input file because they can create fairly good pad files.\n\
\n\
You will require a file (or set of files) over twice the size of the\n\
pad file you intend on generating.  You can use multiple files in a\n\
row to generate a large single pad file.\n\
\n", VERSION


/* The method I use is to read 16k of the file to initialize the 4k buffer,
 * then for every 4k I read, write 2k of data.
 * 
 * 1) Read 4k into a read buffer
 * 2) xor data buffer with read buffer
 * 3) if 16k of data hasn't been read, go to step 2
 * 4) xor the first half of the data buffer with the second half and
 *    write results to pad file
 * 5) go to step 2
 */

unsigned char data_buffer[4096];
unsigned char read_buffer[4096];


int ReadData(FILE *fp, int startbyte)
{
   int readbytes;
   
   readbytes = 4096 - startbyte;
   
   readbytes = fread(&(read_buffer[startbyte]), 1, readbytes, fp);
   
   return startbyte + readbytes;
}


int main(int argc, char **argv)
{
   FILE *infp, *outfp;
   int i, bytes, filenum;

   if (argc < 3)
     {
	printf(USAGE);
	exit(-1);
     }

   for (i = 0; i < 4096; i ++)
     data_buffer[i] = 0;
   
   outfp = fopen(argv[1], "wb");
   if (! outfp)
     {
	printf("Error opening output pad file.\n");
	exit(-2);
     }
   
   filenum = 2;
   infp = fopen(argv[2], "rb");
   if (! infp)
     {
	fclose(outfp);
	printf("Error opening input file.\n");
	exit(-3);
     }
   
   
   i = 0;
   bytes = 0;
   while (1)
     {
	bytes = ReadData(infp, bytes);
	if (bytes == 4096)
	  {
	     for (bytes = 0; bytes < 4096; bytes ++)
	       {
		  data_buffer[bytes] ^= read_buffer[bytes];
	       }
	     if (i < 4)
	       {
		  i ++;
	       }
	     else
	       {
		  for (bytes = 0; bytes < 2048; bytes ++)
		    {
		       read_buffer[bytes] = data_buffer[bytes] ^ 
			 data_buffer[bytes + 2048];
		    }
		  fwrite(read_buffer, 1, 2048, outfp);
	       }
	     bytes = 0;
	  }
	else
	  {
	     filenum ++;
	     if (argc > filenum)
	       {
		  fclose(infp);
		  infp = fopen(argv[filenum], "rb");
		  if (! infp)
		    {
		       fclose(outfp);
		       printf("Error opening input file %s\n", argv[filenum]);
		       exit(-4);
		    }
	       }
	     else
	       {
		  fclose(outfp);
		  fclose(infp);
		  if (i < 4)
		    {
		       printf("Ran out of data while initializing pad.\n");
		       exit(-5);
		    }
		  else
		    {
		       printf("Pad created.\n");
		       exit(0);
		    }
	       }
	  }
     }

   return 0;
}
