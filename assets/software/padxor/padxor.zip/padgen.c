#include <stdio.h>
#include <stdlib.h>
#include <time.h>


#define VERSION "1.0"

#define USAGE "\n\
padgen: Generate a random One Time Pad, version %s\n\
\n\
Usage:\n\
    padgen <file> <bytes>\n\
\n\
file:  The file to write\n\
bytes:  How many bytes of random data to write\n\
\n", VERSION


// Returns 8 bytes of random goodness.
unsigned int GetRandomByte(void)
{
   // Use your favorite random number procuring technique here.
   // I used the simple rand() function.
   static int is_initialized = 0;
   
   if (! is_initialized)
     {
	is_initialized = 1;
	srand((unsigned int) time(NULL));
     }
   
   return rand() & 0xFF;
}


// Writes random data to the opened file
void WriteData(FILE *fp, unsigned long l)
{
   while (l --)
     {
	fputc(GetRandomByte(), fp);
     }
}


// The main function
int main(int argc, char **argv)
{
   unsigned long l;
   FILE *fp;
   
   // Check to make sure the user knows what they are doing
   if (argc < 3)
     {
	printf(USAGE);
	return 1;
     }
   
   printf("padgen %s\n", VERSION);
   
   l = atol(argv[2]);
   if (l < 1)
     {
	printf("Error with bytes parameter -- you need to specify a number ");
	printf("bigger than 0.\n");
	return 2;
     }

   fp = fopen(argv[1], "wb");
   if (! fp)
     {
	printf("Error opening %s\n", argv[1]);
	return 3;
     }
   
   printf("Writing data ...\n");
   WriteData(fp, l);
   printf("Done.\n");
   fclose(fp);
   
   // No problems, leave now.
   return 0;
}
