Floater 1.0 TXT
By Daniel Werner
Modified by Tyler Akins to use a .txt file instead of a directory (for USB-sticks!)

email: fidian@rumkin.com
web:   http://rumkin.com/software/floater/


1. Description

    Floater is a little toolbar program that Daniel Werner.  It used to reside on
    talismanic.net, but that site has since bit the dust.  Floater is very simple, but
    I find it useful.  The source code is supplied with it so you can add any features
    you need if you have a little knowledge of C and the Win32 API.


2. Quick Start

    Create a text file called Floater.txt in the same folder as Floater.exe.  In it,
    specify one file per line, with a description, a pipe symbol, and then the filename.
    Below are a few examples:
    
    Notepad|c:\Windows\notepad.exe
    Internet Explorer|c:\program files\Internet Explorer\iexplore.exe
    
    You do not need to specify a full path, which makes this great for USB-sticks.
    Also, a description is not needed.  If you leave it out, you should also leave
    out the | symbol.  Below is an example line for starting the calculator and running
    a program relative to Floater.
    
    c:\windows\calc.exe
    ..\Utils\somefile.exe
    
    Shortcuts are not sorted and are shown in the same order they appear in Floater.txt.
    Icons are removed if the file does not exist, which will make this work well for
    both Windows 2000 and XP machines:
    
    Notepad|c:\Windows\notepad.exe
    Notepad|c:\WinNT\notepad.exe
   
    Launch the shortcuts by clicking on them.  Open files by dragging documents onto the
    shortcuts.


2. License

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.