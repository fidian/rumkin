MathLib version 1.1, 13 April 1999, by Rick Huebner (rhuebner@radiks.net)
The latest version, source code, bug reports, etc. are available at the
MathLib Information web page: http://www.radiks.net/~rhuebner/mathlib.html


Files included in this (modified) archive:

MathLDoc.htm: HTML documentation for MathLib; use your web browser to read
MathLib.prc:  MathLib shared library, ready to use


If you just want to get the latest version of MathLib to load into your
Pilot, all you need is MathLib.prc.  Install it like any regular Pilot
application and it'll be available to any program that needs it.
