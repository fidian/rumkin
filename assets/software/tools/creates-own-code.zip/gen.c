#include <stdio.h>

char data[] = "";
int offset = 68;

int main(void)
{
   int i, j;
   
   for (i = 0; data[i] != 0; i += 2)
     {
	j = (((data[i] - 'A') << 4) & 0xF0) | ((data[i+1] - 'A') & 0x0F);
	putc(j, stdout);
	if (i == offset)
	  {
	     for (j = 0; data[j] != 0; j ++)
	       {
		  putc(data[j], stdout);
	       }
	  }
     }
   return 0;
}
	