These programs will make a program that generates a copy of its own source
code as output.  That's somewhat an interesting challenge.

Anyway, I figure that the easiest way is to keep a copy of the source in the
program itself, and use that copy to write itself out.

The program that does the decoding of the data in the program is called
gen.c, and it is almost complete.  The data[] array at the top needs to be
populated with info that contains the source to gen.c.

gen2.c will create a program that will massage the data needed for the
data[] array in gen.c.

The whole thing together will look like gen_full.c.

1)  Compile gen2.c
    gcc -o gen2 gen2.c
    
2)  Pipe gen.c into gen2.c
    ./gen2 < gen.c > gen_data.txt

3)  Make a copy of gen.c somewhere
    cp gen.c gen_test.c
    
4)  Use your favorite text editor to insert the contents of gen_data.txt
    into gen.c -- do not add newlines!

5)  Compile gen_test.c
    gcc -o gen_test gen_test.c
    
6)  Test the whole thing out with at least a couple generations
    ./gen_test > gen_test2.c
    gcc -o gen_test2 gen_test2.c
    ./gen_test2 > gen_test3.c
    diff gen_test2.c gen_test3.c

You're done!