#include <stdio.h>

int main(void)
{
   int a;
   
   while ((a = getc(stdin)) != EOF)
     {
	putc('A' + ((a >> 4) & 0x0F), stdout);
	putc('A' + (a & 0x0F), stdout);
     }
}
