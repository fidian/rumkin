[Languages]
key0=0804
key1=0404
key2=0009
Default=0009
key3=040c
count=7
key4=0011
key5=0416
key6=000a

