Calcul-8!

Copyright 2002 David E.H.Griffiths.
All rights reserved.

----------------------------------

For more info and updates visit:

  www.nutcom.fsnet.co.uk/palm/

Calcul-8! is freeware. Use at your
own risk. Comments and suggestions
to:

  palm@nutcom.fsnet.co.uk

----------------------------------

Installation
============
Install Calcul-8!.prc. If you have a Palm device that supports QVGA screen
mode (e.g. Handera 330), then install Calcul-8!_QVGA.prc instead.


Revision History
================

Version 1.1.2 - 14th Apr 2002
----------------------------------
- Added QVGA support for Handera 330


Version 1.1.1 - 6th Apr 2002
----------------------------------
- Now built using newer GNU development tools. Some issues picked up by debug ROMs have been
resolved.

- Added copy and paste buttons to command bar (v3.5 OS and above only).



Version 1.1.0 - 23rd Mar 2002
----------------------------------
- Overhauled the look of the buttons. User can choose between a range of button types.

- Store and recall of memories now list the memory values.

- Memories displayed using the current number mode and preferences.

- Added tips to many dialogs.

- Added trig result truncation option.

- Added option for sticky Inv and Hyp buttons.

- Fixed bug with temperature conversion where choosing no conversion still did one.

- Units added to constants.



Version 1.0.2 - 28th Feb 2002
----------------------------------

- Added comma digit grouping



Version 1.0.1 - 25th Feb 2002
----------------------------------

- Added cut and paste support with new edit menu.

- Added general preferences dialog which now contains tick box for copying numbers as full
precision float, rather than the digits/characters displayed.

- Fixed problem where accessing memory stores causes current input to be lost.

- Correct version string for Calcul-8! is now displayed when viewing version info on applications.

- In menus with ... used proper character rather that three dots.



Version 1.0.0 - 20th Feb 2002
----------------------------------

First release.
