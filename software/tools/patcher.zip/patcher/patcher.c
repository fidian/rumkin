/* Patcher.c
 *
 * See patcher.txt for help.
 *
 * Copyright 1998, Tyler Akins <fidian@tiny.net>
 *
 * Placed in the public domain in February 2004.
 */

#include <stdio.h>
#include <stdlib.h>


/* Reads a string, cleans it up, returns the string */
char *ReadString(void)
{
    char String[256];
    char *Str2;

    fgets(String, 256, stdin);
    Str2 = (char *) strstr(String, "\n");
    if (Str2 != (char *) NULL)
    {
	*Str2 = '\0';
    }

    Str2 = malloc(strlen(String) + 1);
    strcpy(Str2, String);

    return Str2;
}


/* Main structure for holding all of the changes, and for sorting the
 * changes so that they happen in sequence.
 */
struct PatchChange
{
    unsigned long offset;
    int from;
    int to;
    struct PatchChange *next;
};


/* Generic error handler */
void Error(char *String)
{
    printf("Error : %s\n", String);
    printf("Patch process aborted!\n");

    exit(__LINE__);
}


/* Hexadecimal to Integer conversion */
int htoi(char c)
{
    if (c <= '9')
	return (int) (c - '0');

    if (c >= 'a' && c <= 'z')
	c += 'A' - 'a';

    c -= 'A';
    c += 10;

    return (int) c;
}


/* Displays up to and including the \n in a file */
void DisplayLine(FILE *fp)
{
    int temp;

    temp = fgetc(fp);

    while (temp != '\n' && !feof(fp))
    {
	fputc(temp, stdout);
	temp = fgetc(fp);
    }

    if (!feof(fp))
	fputc(temp, stdout);
}


/* Inserts a new change into the linked list, making sure that the
 * insertion is in the proper place.
 */
struct PatchChange *InsertPatch(struct PatchChange *Node, struct
    PatchChange *List)
{
    struct PatchChange *Runner;

    if (Node == (struct PatchChange *) NULL)
	return List;

    if (List == (struct PatchChange *) NULL)
	return Node;

    /* Place this one patch in the correct spot, so all patches */
    /* are in incrementing order, according to offset value */

    if (Node -> offset < List -> offset)
    {
	/* Is it smaller than the head of the list? */
	Node -> next = List;
	return Node;
    }

    Runner = List;
    while (Runner -> next != (struct PatchChange *) NULL)
    {
	/* Is it smaller than any other member of the list? */
	if (Node -> offset < Runner -> next -> offset)
	{
	    Node -> next = Runner -> next;
	    Runner -> next = Node;
	    return List;
	}
	Runner = Runner -> next;
    }

    Runner -> next = Node;
    return List;
}


/* Read Patches
 * Main work for getting everything squared away.  Dragged kicking and
 * and screaming into its own function due to size.
 */
struct PatchChange *ReadPatches(char *Path)
{
    FILE *pfile;
    int i, temp;
    int lastpatch;  // Was the last patch accepted??
    unsigned long l;
    int AlwaysPatch = 0;
    struct PatchChange *PatchList = (struct PatchChange *) NULL;
    struct PatchChange *PatchTemp;

    pfile = fopen(Path, "r");

    if (pfile == (FILE *) NULL)
	Error("Error opening patch file");

    printf("\nPatchfile Name:  ");
    DisplayLine(pfile);

    printf("\nCreated by:  ");
    DisplayLine(pfile);

    temp = fgetc(pfile);
    lastpatch = 0;
    if (feof(pfile))
	Error("Patch File Corrupted -- EOF 1");
    while (temp != '\n')
    {
	/* Allocate memory */
	PatchTemp = (struct PatchChange *) malloc(sizeof(struct PatchChange));
	if (PatchTemp == (struct PatchChange *) NULL)
	    Error("Out of Memory");
	PatchTemp -> next = (struct PatchChange *) NULL;

	/* Determine the offset */
	l = 0;
	while (temp != ' ')
	{ 
	    l *= 10;
	    l += temp - '0';
	    temp = fgetc(pfile);
	    if (feof(pfile))
		Error("Patchfile corrupted -- EOF 2");
	}
	PatchTemp -> offset = l;

	i = htoi(fgetc(pfile)) << 4;
	i += htoi(fgetc(pfile));
	PatchTemp -> from = i;

	if (feof(pfile))
	    Error("Patchfile corrupted -- EOF 3");

	/* Contine to get method. */
	if (fgetc(pfile) != ' ')
	    Error("Patchfile corrupted -- NS 1");

	i = fgetc(pfile);
	switch (i)
	{
	    case '0':  /* Manditory patch */
		if (fgetc(pfile) != ' ')
		    Error("Patchfile corrupted -- NS 2");

		i = htoi(fgetc(pfile)) << 4;
		i += htoi(fgetc(pfile));

		PatchTemp -> to = i;

		printf("\n\nAutomatically applying patch: ");
		DisplayLine(pfile);

		lastpatch = 1;

		break;

	    case '1':  /* Yes, No, Always */
		if (fgetc(pfile) != ' ')
		    Error("Patchfile corrupted -- NS 3");

		i = htoi(fgetc(pfile)) << 4;
		i += htoi(fgetc(pfile));

		PatchTemp -> to = i;

		printf("\n\nPatch for: ");
		DisplayLine(pfile);

		if (AlwaysPatch)
		{
		    printf("\nAlways Patch -- Automatically applying patch.\n");
		} 
		else
		{
		    temp = '*';
		    printf("  Yes, No, Always?  ");
		    temp = fgetc(stdin);
		    while (temp != 'Y' && temp != 'N' && temp != 'A' &&
			temp != 'y' && temp != 'n' && temp != 'a')
		    {
			while (temp != '\n')
			    temp = fgetc(stdin);
			printf("\n  Yes, No, Always?  ");
			temp = fgetc(stdin);
		    }

		    if (temp == 'A' || temp == 'a')
			AlwaysPatch ++;

		    if (temp == 'N' || temp == 'n')
		    {
			printf("Patch will be skipped.\n");
			free(PatchTemp);
			PatchTemp = (struct PatchChange *) NULL;
			lastpatch = 0;
		    }
		    else
		    {
			printf("Patch will be applied.\n");
			lastpatch = 1;
		    }

		    while (temp != '\n')
			temp = fgetc(stdin);
		}
		break;

	    case '2':  /* User-defined */
		printf("\n\nUser-defined patch found.\nPatch: ");
		DisplayLine(pfile);

		printf("Only one character is allowed.  Press Enter to ");
		printf("not change.\nCurrent data:  %c\nYour choice:  ",
		    (char) PatchTemp -> from);
		temp = fgetc(stdin);

		if (temp == '\n')
		{
		    free(PatchTemp);
		    PatchTemp = (struct PatchChange *) NULL;
		    lastpatch = 0;
		}
		else
		{
		    PatchTemp -> to = temp;
		    while (temp != '\n')
			temp = fgetc(stdin);
		    lastpatch = 1;
		}
		break;

	    case '3':  /* Continuation */
		printf("Continuation of previous patch found.\n");
		if (lastpatch != 0)
		{
		    printf("  Automatically patching.\n");

		    if (fgetc(pfile) != ' ')
			Error("Patchfile corrupted -- NS 3");

		    i = htoi(fgetc(pfile)) << 4;
		    i += htoi(fgetc(pfile));

		    PatchTemp -> to = i;
		}
		else
		{
		    free(PatchTemp);
		    PatchTemp = (struct PatchChange *) NULL;
		    printf("  Automatically ignoring.\n");
		}

		i = 0;
		while (i != '\n')
		    i = fgetc(pfile);
		break;

	    default:
		Error("Patchfile corrupted -- Method");
	}

	PatchList = InsertPatch(PatchTemp, PatchList);
	PatchTemp = (struct PatchChange *) NULL;

	if (feof(pfile))
	    Error("Patchfile corrupted -- EOF 4");

	temp = fgetc(pfile);
    }

    fclose(pfile);

    return PatchList;
}

int main(int argc, char **argv)
{
    struct PatchChange *PatchList = (struct PatchChange *) NULL;
    struct PatchChange *PatchRunner;
    unsigned long Offset = 0;
    FILE *infile, *outfile;
    int temp;
    char *Patch_Path, *In_Path, *Out_Path;

    printf("Patcher 2.3 by Fidian <fidian@juno.com>\n");

    if (argc < 2)
    {
	printf("Path and file name of patch file:  ");
	Patch_Path = ReadString();
    }
    else
    {
	Patch_Path = argv[1];
    }

    if (argc < 3)
    {
	printf("Input filename:  ");
	In_Path = ReadString();
    }
    else
    {
	In_Path = argv[2];
    }

    if (argc < 4)
    {
	printf("Output filename:  ");
	Out_Path = ReadString();
    }
    else
    {
	Out_Path = argv[3];
    }

    printf("User takes full responsibility for program and its effects.\n");
    printf("Patches may make undesireable changes, apply at your own risk.\n");
    printf("Make a backup of any file before patching.\n");
    printf("\nPress Enter to continue, or Control-C to quit.\n");

    temp = fgetc(stdin);
    while (temp != '\n')
	temp = fgetc(stdin);

    PatchList = ReadPatches(Patch_Path);


    infile = fopen(In_Path, "rb");

    if (infile == (FILE *) NULL)
	Error("Error opening input file");

    outfile = fopen(Out_Path, "wb");

    if (outfile == (FILE *) NULL)
	Error("Error opening output file");

    printf("\n\nPatching.\n");

    while (!feof(infile) && PatchList != (struct PatchChange *) NULL)
    {
	temp = fgetc(infile);
	if (PatchList -> offset == Offset)
	{
	    if (PatchList -> from != temp)
		Error("Bytes do not match up -- ABORTING!");
	    fputc(PatchList -> to, outfile);

	    PatchRunner = PatchList -> next;
	    free(PatchList);
	    PatchList = PatchRunner;
	}
	else
	{
	    fputc(temp, outfile);
	}
	Offset ++;
    }

    if (feof(infile) && PatchList != (struct PatchChange *) NULL)
	Error("Ran out of input file, but more left to patch.");

    while (!feof(infile))
    {
	fputc(fgetc(infile), outfile);
    }

    printf("Done.\n");

    return 0;
}
