/* Diff generating program
 * Only works for very simple patches
 *
 * Copyright 1998, Tyler Akins <fidian@tiny.net>
 *
 * Placed in the public domain in February 2004.
 */

#include <stdio.h>

int main(int argc, char **argv)
{
    FILE *pfile, *infile, *outfile;
    int i, j, method;
    unsigned long offset;

    printf("Differ 2.1 by Fidian <fidian@juno.com>\n");

    if (argc < 4)
    {
	printf("Syntax:  differ <patchfile> <in file> <out file>\n");
	printf("  patchfile = file to write with patch information\n");
	printf("  in file = file to patch with no modifications\n");
	printf("  out file = file to patch with modifications made\n");

	return __LINE__;
    }

    pfile = fopen(argv[1], "w");

    if (pfile == (FILE *) NULL)
    {
	printf("Error opening patch file.\n");

	return __LINE__;
    }

    infile = fopen(argv[2], "rb");

    if (infile == (FILE *) NULL)
    {
	printf("Error opening input file.\n");

	fclose(pfile);

	return __LINE__;
    }

    outfile = fopen(argv[3], "rb");

    if (outfile == (FILE *) NULL)
    {
	printf("Error opening output file.\n");

	fclose(pfile);
	fclose(infile);

	return __LINE__;
    }

    printf("Files opened.\n");

    printf("Name of patch:  ");
    fflush(stdout);

    i = fgetc(stdin);
    while (i != '\n')
    {
	fputc(i, pfile);
	i = fgetc(stdin);
    }
    fputc(i, pfile);

    printf("Your name:  ");
    fflush(stdout);

    i = fgetc(stdin);
    while (i != '\n')
    {
	fputc(i, pfile);
	i = fgetc(stdin);
    }
    fputc(i, pfile);

    printf("Scanning for changes.\n");

    i = fgetc(infile);
    j = fgetc(outfile);
    offset = 0;

    while (!feof(infile) && !feof(outfile))
    {
	if (i != j)
	{
	    printf("Change found at offset %lu : %x -> %x\n", offset, i, j);
	    fprintf(pfile, "%lu %02x ", offset, i);

	    i = '\n';

	    while (i < '0' || i > '3')
	    {
		if (i == '?')
		{
		    printf("  0 :: Unconditional change\n");
		    printf("  1 :: Confirm the change\n");
		    printf("  2 :: User-supplied data for patch\n");
		    printf("  3 :: Group with previous patch (for big patches)\n");
		}

		while (i != '\n')
		    i = fgetc(stdin);

		printf("Type of mod (? for options):  ");

		i = fgetc(stdin);
	    }

	    method = i;

	    switch (method)
	    {
		case '0':
		    fprintf(pfile, "0 %02x ", j);
		    break;

		case '1':
		    fprintf(pfile, "1 %02x ", j);
		    break;

		case '2':
		    fprintf(pfile, "2 ");
		    break;

		case '3':
		    fprintf(pfile, "3 %02x ", j);
		    break;
	    }

	    while (i != '\n')
		i = fgetc(stdin);

	    if (method != '3')
	    {
		printf("Reason for mod:  ");
		fflush(stdout); 

		i = fgetc(stdin);
		while (i != '\n')
		{
		    fputc(i, pfile);
		    i = fgetc(stdin);
		}
	    }

	    fputc(i, pfile);
	}

	i = fgetc(infile);
	j = fgetc(outfile);
	offset ++;
    }

    fprintf(pfile, "\n");

    printf("Closing files.\n");
    fclose(pfile);
    fclose(infile);
    fclose(outfile);
    printf("Done.\n");

    return 0;
}
