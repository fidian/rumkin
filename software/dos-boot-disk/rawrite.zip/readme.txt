Alternate versions of rawrite:

NAME       VERSION  DESCRIPTION
===================================================================
rawrite2   2.0      DOS/9x - Strongly suggest using this one
rawrit12   1.2      Alternate for rawrite2
rawrit13   1.3      Alternate for rawrite2
rawri133   1.3.3    Alternate for rawrite2
rawri_nt   1.0      For Windows NT, 2000
rawri_xp   ?        For Windows XP
raread     ?        Read an image from a floppy drive

To use one, this will write an image to the A: drive.

    rawrite2 -f IMAGE_FILE.img -d A
