************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** INFO *********** 
**************************** 

Swahili language, also called KISWAHILI, or KISWAHILI, Bantu language spoken either as a mother tongue or as a fluent
second language on the east coast of Africa in an area extending from Lamu Island, Kenya, in the north to the southern
border of Tanzania in the south.

**************************** 
*********** ABOUT ********** 
**************************** 

This Wordlist is based on Dave Fawthrop's work(see his readme below).
I sorted it and removed dupes.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 16735 Words
184934 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

This wordlist was produced from a translation of the New Testament of
the Bible into Swahili, obtained from nic.funet.fi/pub/doc/bible/swahili.
Users should be aware that it contains many specifically Christian
words. Words may appear several times in capitalised, initial capital
and lower case form.

I am hoping to create similar wordlists in several languages except
the Major European languages, which are already covered.  I am
specifically interested in the Eastern European languages.  If users
are aware of text in any other languages, please contact Dave Fawthrop
hyphen@ibmpcug.co.uk.  Computer Hyphenation Ltd, Hyphen House, 8
Cooper Grove, Shelf, Halifax, HX3 7RF. United Kingdom Phone\Fax\Answer
+44 (0)274 733317
