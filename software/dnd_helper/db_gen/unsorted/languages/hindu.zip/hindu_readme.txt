************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** INFO *********** 
**************************** 

Hindi language, official language of the Republic of India, a central Indo-Aryan language claimed as a mother tongue
by more than 150,000,000 speakers.<br>
Literary Hindi, written in the Devanagari script, shows a strong influence of Sanskrit as a source for borrowings;
it is based on the Khari Boli dialect, to the north and east of Delhi. 
Also commonly treated as dialects of Hindi are Braj Bhasa, which was an important literary medium from the 15th to
the 17th century; Avadhi, also a literary medium; and Bagheli, Chattisgarhi, Bundeli, and Kanauji.

**************************** 
*********** ABOUT ********** 
**************************** 

This Hindu Wordlist was created by an unknown author(no readme).
I sorted it and removed dupes.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 750 Words
6169 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

The hindu-names was cannibalized from a news article:

From: B.Kumar@cs.ucl.ac.uk
Newsgroups: soc.culture.indian
Subject: FAQ: list of Hindu names..
Message-ID: <3273@ucl-cs.uucp>
Date: 26 Nov 92 12:49:10 GMT

I know nothing of Hindi (I do not even know whether all the names
here are Hindi...) but I did it, anyway.  I was even so bold as to
add a few names I know I _think_ are Indian.  The blame is mine,
the kudos is B. Kumar's.

++jhi@ftp.funet.fi;
