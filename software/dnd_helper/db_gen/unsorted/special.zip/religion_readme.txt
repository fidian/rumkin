************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** ABOUT ********** 
**************************** 
 
This Wordlist was created by Dan Klein, Sheila Palevsky and several unknown authors(see below).

I combined several lists to a single wordlist, sorted the
result and removed dupes.
Then I removed words of any other languages(including English) from this list.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 406 Words
3479 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

"A Dictionary of Fabulous Beasts", R. Barber & A. Riches, Walker & Co, NY
and Sheila Palevsky
Beasts and characters from mythology and legends
cat KJbible/* | tr -cs A-Za-z '\012' | tr A-Z a-z | sort | uniq
From the on-line version of the King James bible, acquired by doing:
Taken from AD&D games, Bulfinches Mythology, and
we should have used Leo Rosten's "The Joy of Yiddish") by Dan Klein
Yiddish and Yinglish words and phrases, from memory (although really

Religious terms:

the on-line version of the King James bible
the Koran
Beasts and characters from mythology and legends
Yiddish and Yinglish

by Dan Klein, Sheila Palevsky and several unknown authors
