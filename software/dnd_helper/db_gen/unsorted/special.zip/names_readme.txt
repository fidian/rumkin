************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** ABOUT ********** 
**************************** 
 
This Wordlist consists of many "names"-wordlists from many Languages(see below).

I combined those lists to a single wordlist, sorted the
result and removed dupes.
Then I removed words of any languages(including English) from this list.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 217387 Words
2018406 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

From: Pablo <pcr@alumni.cs.colorado.edu>
Most common surnames, UK

From Population Trends #4, HMSO 1976 pp.9-11.  Compiled from the 
births, deaths, and marriage registers for the first quarter of 1975.  
Provided by the Office of Population, Censuses & Surveys, London 
(fax 71-396-2576).  50 names.

From: Pablo <pcr@alumni.cs.colorado.edu>
Given names of boys, Canada
Information provided by the Ontario Ministry of Consumer and Commercial 
Relations, Registration Division, Office of the Registrar General 
(fax 807-343-7411), for 1992 births.  

From: Pablo <pcr@alumni.cs.colorado.edu>
Most common surnames, USA
From American Surnames by Elsdon C. Smith, Chilton Book Company, New 
York 1969.  From a 1964 Social Security tabulation of their files since 
1936, with emendations by the author.  1500 names.

From: Pablo <pcr@alumni.cs.colorado.edu>
Given names of Girls, USA

From The Facts on File Dictionary of First Names, Facts on File 
Publications, New York 1983 - Table showing top 50 for 1925, '50, '70, 
'82, and '83, duplicates removed from older lists.  Entered recent/top to 
oldest/bottom.  

From: Pablo <pcr@alumni.cs.colorado.edu>
Given names of girls, Canada
Information provided by the Ontario Ministry of Consumer and Commercial 
Relations, Registration Division, Office of the Registrar General 
(fax 807-343-7411), for 1992 births.

From: Pablo <pcr@alumni.cs.colorado.edu>
Given names of boys, England and Wales

From The Facts on File Dictionary of First Names, Facts on File 
Publications, New York 1983 - Table showing top 50 for 1925, '50, '65, 
'75, and '81, duplicates removed from older lists.  Entered recent/top to 
oldest/bottom.  

From: Pablo <pcr@alumni.cs.colorado.edu>
Given names of boys, USA

From The Facts on File Dictionary of First Names by Dunkling and Gosling, 
Facts on File Publications, New York 1983 - Table showing top 50 for 
1925, '50, '70, '82, and '83, duplicates removed from older lists.  Entered 
recent/top to oldest/bottom.  

From: Pablo <pcr@alumni.cs.colorado.edu>
Given names of Girls, England and Wales.

From The Facts on File Dictionary of First Names by Dunkling and Gosling, 
Facts on File Publications, New York 1983 - Table showing top 50 for 
1925, '50, '65, '75, and '81, duplicates removed from older lists.  Entered 
recent/top to oldest/bottom. 
br@wucs1.wustl.edu (Bill Ross)

surnames file from nic.funet.fi

From andyb@coat.com (Andy Behrens)
Ftp'd from ftp.cs.vu.nl -- French names

From  Dick Dramstad <rad@mbunix.mitre.org>

Italian given names
from black.ox.ac.uk

Italian family names
from black.ox.ac.uk

A collection of male names
source unknown

A collection of female names
source unknown

A collection of proper names
source unknown

A collection of Norwegian names
source unknown

original name of file: names.canada
source unknown

A collection of unclassified names
source unknown

Contributed by Peter E. Yee <yee@trident.arc.nasa.gov>

Names of members of the US Congress
from black.ox.ac.uk
List from David C. Kovar <daedalus!corwin@talcott.harvard.edu>
Obtained from Stephen E. Hansen <hansen@talbotts.stanford.edu>

A collection of surnames (probably from the Usenet)
source unknown

From mansur@lll-crg.llnl.gov (Doug Mansur)
From the SPI dictionary set

Names, possibly derived from some source at HP (?)
from black.ox.ac.uk

From jrs@magic.ecn.purdue.edu (Jeff Schwab)
compiled from user lists at Purdue

A collection of Norwegian names
Compiled by Anders Ellefsrud <anders@ifi.uio.no>

From Bruce Barnett <barnett@grymoire.crd.ge.com> and compiled
from an employee database somewhere.

Various famous people

From Bob Baldwin's collection from MIT
Augmented by Matt Bishop and Daniel Klein

These are names derived from the password files at several
Berkeley machines.

Compiled by Brent Chapman <brent@capmkt.com>
Names of men from lots of languages

From Bob Baldwin's collection from MIT
Augmented by Matt Bishop and Daniel Klein

Names of women from lots of languages

From Bob Baldwin's collection from MIT
Augmented by Matt Bishop and Daniel Klein

List of all names from the Indiana University phonebook that
appear more than 9 times each.

From Steve Hayman <sahayman@iuvax.cs.indiana.edu>
First names garnered from a number of password files.  We get
a good hit rate from these.  Probably couldbe culled somewhat.

By Daniel Klein

From Gene Spafford <spaf@cs.purdue.edu>
These have been compiled over the last 5 years from Usenet postings, 
phone databases, and miscellaneous other sources.

Various names of people (usually) whose gender it is
difficult to determine.

From Bob Baldwin's collection from MIT
Augmented by Matt Bishop and Daniel Klein

