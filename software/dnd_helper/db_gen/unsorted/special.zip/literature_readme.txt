************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** ABOUT ********** 
**************************** 
 
This Wordlist consists of wordlists from Matt Bishop, Daniel Klein, Don Olivier and Bob Baldwin(see below).

I combined those lists to a single wordlist, sorted the
result and removed dupes.
Then I removed words of any other languages(including English) from this list.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 3562 Words
35384 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

A collection of characters and titles from comic books
A list of both dramatis personae and locations from the collected works
Augmented by Matt Bishop and Daniel Klein
Augmented by Matt Bishop and Daniel Klein & Gene Spafford
cartoon names and places
cast of characters from The Complete Moby(tm) Shakespeare world.std.com:/obi/
Collected by Dan Klein
Comic strips from Douglas Krause's files at UCI 
Don Olivier	don@hsph.harvard.edu
Don Olivier, Harvard School of Public Health 	   don@hsph.harvard.edu
From Bob Baldwin's collection from MIT
glossary from Shakespeare
glossary from The Complete Moby(tm) Shakespeare world.std.com:/obi/
of the Bard.
Proper nouns from Bulfinch's Age of Fable: Classic myths
Proper nouns from the Aeneid (plus a little junk)
Proper nouns from the Iliad (plus a little junk)
Proper nouns from the Odyssey (plus a little junk)
some characters and miscellany
titles
Various science fiction characters, authors, books.
