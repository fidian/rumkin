#ifndef DBF_H
#define DBF_H

typedef struct
{
   char dbf_id;  // 0x03 for dbase dbf, 0x83 = dbase DBF with memo
   char last_update[3]; // shorts (Year, month, day)
   long last_rec;  // # of records
#ifdef __linux__
   // two bytes
   unsigned short data_offset;  // What byte the data begins on
   unsigned short rec_size;  // How many bytes per record + 1
#else
   // two bytes
   unsigned data_offset;
   unsigned rec_size;
#endif
   char filler[20];
} DBF_HEAD;


typedef struct
{
   char field_name[11];  // Field name, padded with zeros
   char field_type;  // Type (Memo, Numeric, ?)
   char dummy[4];
   union
     {
#ifdef __linux
	unsigned short char_len;  // Size of Character field
#else
	unsigned char_len;
#endif
	struct
	  {
	     unsigned char len;  // Length of numeric field
	     char dec;  // Implied decimal places
	  } num_size;
     } len_info;
   char filler[14];
} FIELD_REC;


#endif
