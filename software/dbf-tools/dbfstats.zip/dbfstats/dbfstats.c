#include <stdio.h>
#include <stdlib.h>
#include <zlib.h>
#include <unistd.h>
#include <string.h>
#include <time.h>
#include "dbf.h"


// For determining which dates are "valid"
#define START_YEAR 1997
#define NUMBER_OF_YEARS 10 


// The various output types -- Default is 0
// CSV does not show the date breakdown
#define OUTPUT_TEXT 0
#define OUTPUT_HTML 1
#define OUTPUT_CSV  2


typedef struct FieldList_s
{
   char name[12];
   char type;
   unsigned int len;
   unsigned int dec;
   
   unsigned long empty;
   void *minimum, *maximum;
   unsigned short entered;  // Was the min and max seeded yet?
   unsigned long t, f;  // for logic (true/false) and char (max/min length)
   unsigned long *dates, invalid_dates;  // for dates
   
   struct FieldList_s *next;
} FieldList;


typedef struct DBInfo_s
{
   unsigned long processed_records;
   unsigned long declared_records;
   unsigned fields;
   unsigned record_length;
   unsigned record_length_from_header;
} DBInfo;


DBInfo DB_Info;
FieldList *head;
int debug;
time_t start_time;


void FastForward(gzFile *gz, signed int bytes)
{
   unsigned char *spot;
   if (bytes > 0)
     {
	spot = malloc(bytes);
	gzread(gz, spot, bytes);
	free(spot);
     }
}


int LoadHeader(gzFile *gz)
{
   DBF_HEAD header;
   FIELD_REC field;
   FieldList *l, *p = NULL;
   unsigned int bytes_read = 0;
   short header_done = 0;
   
   DB_Info.processed_records = 0;
   DB_Info.fields = 0;
   DB_Info.record_length = 1;  // no-mark (0x20), mark (0x2A), EOF (0x1A)
   
   if (gzread(gz, &header, sizeof(DBF_HEAD)) != sizeof(DBF_HEAD))
     {
	fprintf(stderr, "Not enough bytes to read in header.\n");
	return 2;
     }
   bytes_read += sizeof(DBF_HEAD);
   
   DB_Info.declared_records = header.last_rec;
   DB_Info.record_length_from_header = header.rec_size;

   while (header_done == 0 &&
	  bytes_read < header.data_offset &&
	  gzread(gz, &field, 1) == 1)
     {
	bytes_read ++;
	if (field.field_name[0] == '\x0D')
	  {
	     header_done = 1;
	  }
	else
	  {
	     if (gzread(gz, &(field.field_name[1]), sizeof(FIELD_REC) - 1) !=
		 sizeof(FIELD_REC) - 1)
	       {
		  fprintf(stderr, "Not enough bytes to read in field.\n");
		  return 3;
	       }
	     bytes_read += sizeof(FIELD_REC) - 1;
	
	     l = (FieldList *) malloc(sizeof(FieldList));
	     strncpy(l->name, field.field_name, 11);
	     l->name[11] = '\0';
	     l->type = field.field_type;
	     l->len = field.len_info.num_size.len;
	     l->dec = field.len_info.num_size.dec;
	     l->next = NULL;
	     l->entered = 0;
	     l->minimum = malloc(l->len);
	     l->maximum = malloc(l->len);
	     l->empty = 0;
	     l->t = 0;
	     l->f = 0;
	     if (l->type == 'D')
	       {
		  l->dates = malloc(sizeof(unsigned long) * NUMBER_OF_YEARS * 12);
		  memset(l->dates, 0, sizeof(unsigned long) * NUMBER_OF_YEARS * 12);
	       }
	     else
	       l->dates = NULL;
	     l->invalid_dates = 0;
	     
	     DB_Info.fields ++;
	     DB_Info.record_length += l->len;
	
	     if (p == NULL)
	       {
		  head = l;
	       }
	     else
	       {
		  p->next = l;
	       }
	     
	     p = l;
	     
	     if (debug)
	       {
		  fprintf(stderr, "Name:  %s\n", l->name);
		  fprintf(stderr, "Type:  %c\n", l->type);
		  fprintf(stderr, "Len:  %u\n", l->len);
		  fprintf(stderr, "Dec:  %d\n", l->dec);
		  fprintf(stderr, "\n");
	       }
	  }
	
     }

   FastForward(gz, header.data_offset - bytes_read);
   
   return 0;
}


void ShowStatus(unsigned long cur, unsigned long total)
{
   char line[80], line2[80], line3[80], c;
   int i, j, k;
   double d;
   int h, m, s;
   unsigned long eta;
   int err = 0;
   
   sprintf(line, "\r%lu/%lu ", cur, total);
   if (total > 0)
     {
	sprintf(&(line[strlen(line)]), "(%d%%) ", 
		(int) (((float) cur / (float) total) * 100));
     }
	     
   d = time(NULL) - start_time;
   if (d != 0)
     {
	d /= (double) cur;
	d *= (double) (total - cur);
     }
   
   eta = (unsigned long) d;
   s = eta % 60;
   eta /= 60;
   m = eta % 60;
   eta /= 60;
   h = eta;
   
   if (h)
     sprintf(line2, " %u:%02d:%02d", h, m, s);
   else
     sprintf(line2, " %d:%02d", m, s);
   
   i = 79 - strlen(line) - strlen(line2);
   d = (double) cur / (double) total;
   if (d > 1.0)
     {
	d = 1.0;
	err = 1;
     }
   d *= (double) i;
   j = (int) d;
   c = '#';
   if (err)
     c = 'E';
   for (k = 0; k <= j; k ++)
     {
	line3[k] = c;
     }
   for (;k <= i; k ++)
     {
	line3[k] = '-';
     }
   line3[k] = '\0';
   
   fprintf(stderr, "%s%s%s", line, line3, line2);
}


int WorkFields(gzFile gz, int ProgressMeter)
{
   FieldList *l;
   char Mark = 0x1A;
   int maxsize = 0;
   char *data;
   long long ll;
   int i, j;
   time_t update_time = 0;
   long ld;
   
   for (l = head; l != NULL; l = l->next)
     {
	if (maxsize < l->len)
	  maxsize = l->len;
     }
   
   data = (char *) malloc(maxsize + 1);
   
   while (gzread(gz, &Mark, 1) == 1 && (Mark == 0x2A || Mark == 0x20))
     {
	if (ProgressMeter)
	  {
	     if (update_time != time(NULL))
	       {
		  time(&update_time);
		  ShowStatus(DB_Info.processed_records, 
			     DB_Info.declared_records);
	       }
	  }
	
	DB_Info.processed_records ++;
	l = head;
	if (debug == 1)
	  fprintf(stderr, "Record %lu Mark %x\n", 
		  DB_Info.processed_records, Mark);
	while (l != NULL)
	  {
	     if (gzread(gz, data, l->len) != l->len)
	       {
		  fprintf(stderr, "Ran out of data while reading field %s\n",
			  l->name);
		  if (debug)
		    {
		       fprintf(stderr, "Record number is %lu\n", 
			       DB_Info.processed_records);
		       if (l == head)
			 fprintf(stderr, "Mark is %x\n", Mark);
		    }
		  free(data);
		  return 5;
	       }
	     
	     if (debug > 1)
	       {
		  fprintf(stderr, "Record %lu, field %s\n", 
			  DB_Info.processed_records, l->name);
		  for (i = 0; i < l->len; i ++)
		    {
		       fputc(data[i], stderr);
		    }
		  fprintf(stderr, "\n");
	       }

	     switch (l->type)
	       {
		  // N-byte ASCII
		case 'C':  // Character, Character Binary
		  for (i = l->len; i > 0 && data[i-1] == ' '; i --)
		    {
		    }
		  if (i == 0)
		    l->empty ++;
		  else
		    { 
		       if (l->entered)
			 {
			    if (i < l->f)
			      l->f = i;
			    else if (i > l->t)
			      l->t = i;
			 }
		       else
			 {
			    l->f = i;
			    l->t = i;
			    l->entered = 1;
			 }
		    }
		  break;
		  
		  // 8-byte numbers in binary
		  // Can do min and max
		case 'Y':  // Currency (8 bytes)
		  memcpy(&ll, data, 8);
		  if (ll == 0)
		    {
		       l->empty ++;
		    }
		  else
		    {
		       if (l->entered)
			 {
			    if (ll < *((long long *) l->minimum))
			      {
				 *((long long *) l->minimum) = ll;
			      }
			    else if (ll > *((long long *) l->maximum))
			      {
				 *((long long *) l->maximum) = ll;
			      }
			 }
		       else
			 {
			    *((long long *) l->minimum) = ll;
			    *((long long *) l->maximum) = ll;
			    l->entered = 1;
			 }
		    }
		  break;

		  // N-byte numbers in ASCII
		  // Can do min and max
		case 'F':  // Float
		case 'N':  // Numeric
		case 'D':  // Date
		  for (i = 0; i < l->len; i ++)
		    {
		       if (data[i] < '1' || data[i] > '9')
			 {
			    if (i && data[i-1] == '-')
			      {
				 data[i-1] = ' ';
				 data[i] = '-';
			      }
			    else if (data[i] != '-')
			      data[i] = ' ';
			 }
		       else
			 i = l->len + 1;
		    }
		  if (i == l->len || (l->type == 'D' && 
				      strncmp("99991231", data, l->len) == 0))
		    {
		       l->empty ++;
		    }
		  else
		    {
		       if (l->entered)
			 {
			    if (strncmp(data, (char *) l->minimum, l->len) < 
				0)
			      {
				 strncpy((char *) l->minimum, data, l->len);
			      }
			    else if (strncmp(data, (char *) l->maximum, 
					     l->len) > 0)
			      {
				 strncpy((char *) l->maximum, data, l->len);
			      }
			 }
		       else
			 {
			    strncpy((char *) l->minimum, data, l->len);
			    strncpy((char *) l->maximum, data, l->len);
			    l->entered = 1;
			 }
		       
		       // not empty, so collect the date
		       if (l->type == 'D')
			 {
			    i = data[0] - '0';
			    i *= 10;
			    i += data[1] - '0';
			    i *= 10;
			    i += data[2] - '0';
			    i *= 10;
			    i += data[3] - '0';
			    if (i < START_YEAR || 
				i >= START_YEAR + NUMBER_OF_YEARS)
			      {
				 l->invalid_dates ++;
			      }
			    else
			      {
				 i -= START_YEAR;
				 i *= 12;
				 j = data[4] - '0';
				 j *= 10;
				 j += data[5] - '0';
				 if (j < 1 || j > 12)
				   {
				      l->invalid_dates ++;
				   }
				 else
				   {
				      l->dates[i + j - 1] ++;
				   }
			      }
			 }
		    }
		  break;
		  
		case 'L':  // Logical
		  if (data[0] == 'T' || data[0] == 't' || 
		      data[0] == 'Y' || data[0] == 'y')
		    l->t ++;
		  else if (data[0] == 'F' || data[0] == 'f' || 
			   data[0] == 'N' || data[0] == 'n')
		    l->f ++;
		  else
		    l->empty ++;
		  break;
		  
		case 'I':  // Integer (4 bytes)
		  memcpy(&ld, data, 4);
		  if (ld == 0)
		    {
		       l->empty ++;
		    }
		  else
		    {
		       if (l->entered)
			 {
			    if (ld < *((long *) l->minimum))
			      {
				 *((long *) l->minimum) = ld;
			      }
			    else if (ld > *((long *) l->maximum))
			      {
				 *((long *) l->maximum) = ld;
			      }
			 }
		       else
			 {
			    *((long *) l->minimum) = ld;
			    *((long *) l->maximum) = ld;
			    l->entered = 1;
			 }
		    }
		  break;

		case 'T':  // Datetime
		case 'B':  // Double
		case 'M':  // Memo, Memo Binary
		case 'G':  // General
		default:
		  fprintf(stderr, "I don't know how to handle type '%c'\n", 
			  l->type);
		  return 6;
	       }
	     
	     l = l->next;
	  }
	FastForward(gz, DB_Info.record_length_from_header - DB_Info.record_length);
	Mark = 0x1A;
     }
   
   free(data);
   
   if (Mark != 0x1A)
     {
	fprintf(stderr, "Mark is invalid!  %x\n", Mark);
	return 4;
     }
   
   if (ProgressMeter)
     {
	ShowStatus(DB_Info.processed_records, DB_Info.declared_records);
	fprintf(stderr, "\n");
     }
   
   return 0;
}


void FreeList(void)
{
   FieldList *l, *n;
   n = head;
   while (n != NULL)
     {
	l = n->next;
	free(n->minimum);
	free(n->maximum);
	if (n->dates != NULL)
	  free(n->dates);
	free(n);
	n = l;
     }
}


void DumpDateTables(int OutputMode)
{
   FieldList *l;
   int y, m, firstYear, lastYear, size;
   int show_years[NUMBER_OF_YEARS];
   unsigned long ul;
   char format[80];
   int add_spaces = 0;  // for formatting text -- add spaces between tables

   if (OutputMode == OUTPUT_TEXT)
     {
	printf("\n");
	printf("\n");
	printf("Valid dates fall from January 1, %d, to December 31, %d\n",
	       START_YEAR, START_YEAR + NUMBER_OF_YEARS - 1);
	printf("\n");
     }
   else
     {
	printf("<p>Valid dates fall from January 1, %d, to ", START_YEAR);
	printf("December 31, %d</p>\n", START_YEAR + NUMBER_OF_YEARS - 1);
     }
   
   l = head;
   while (l != NULL)
     {
	if (l->type == 'D')
	  {
	     // Determine which years to print and how big the numbers are
	     firstYear = 0;
	     lastYear = 0;
	     for (y = 0; y < NUMBER_OF_YEARS; y ++)
	       {
		  show_years[y] = 0;
		  for (m = 0; m < 12; m ++)
		    {
		       if (l->dates[y * 12 + m])
			 {
			    ul = l->dates[y * 12 + m];
			    size = 1;
			    while (ul > 9)
			      {
				 ul /= (unsigned long) 10;
				 size ++;
			      }
			    
			    if (show_years[y] < size)
			      show_years[y] = size;
			    
			    if (firstYear == 0)
			      {
				 firstYear = y + 1;
				 lastYear = y + 1;
			      }
			    else
			      {
				 lastYear = y + 1;
			      }
			 }
		    }
	       }
	     
	     for (y = firstYear - 1; y < lastYear; y ++)
	       {
		  if (show_years[y] < 4)
		    show_years[y] = 4;
	       }
	     
	     if (OutputMode == OUTPUT_TEXT)
	       {
		  if (add_spaces == 0)
		    add_spaces = 1;
		  else
		    printf("\n\n");
		  printf("[ %s ]\n", l->name);
		  if (firstYear == 0)
		    printf("No dates fall within the valid range.\n");
		  else
		    {
		       printf("MO");
		       size = 0;
		       for (y = 0; y < NUMBER_OF_YEARS; y ++)
			 {
			    if (show_years[y])
			      {
				 sprintf(format, "  %%%dd", show_years[y]);
				 printf(format, START_YEAR + y);
				 size += show_years[y] + 2;
			      }
			 }
		       printf("\n");
		       printf("--");
		       while (size --)
			 printf("-");
		       printf("\n");
		    }
	       }
	     else
	       {
		  printf("<h3>%s</h3>\n", l->name);
		  if (firstYear == 0)
		    printf("<p>No dates fall within the valid range.</p>\n");
		  else
		    {
		       printf("<table border=1 cellpadding=5 cellspacing=0>\n");
		       printf("<tr><th>MO</th>");
		       for (y = 0; y < NUMBER_OF_YEARS; y ++)
			 {
			    if (show_years[y])
			      {
				 printf("<th>%d</th>", START_YEAR + y);
			      }
			 }
		       printf("</tr>\n");
		    }
	       }

	     for (m = 0; m < 12 && firstYear != 0; m ++)
	       {
		  if (OutputMode == OUTPUT_TEXT)
		    {
		       printf("%2d", m + 1);
		    }
		  else
		    {
		       printf("<tr><th>%d</th>", m + 1);
		    }
		  
		  for (y = 0; y < NUMBER_OF_YEARS; y ++)
		    {
		       if (show_years[y])
			 {
			    if (OutputMode == OUTPUT_TEXT)
			      {
				 sprintf(format, "  %%%dlu", show_years[y]);
				 printf(format, l->dates[y * 12 + m]);
			      }
			    else
			      {
				 printf("<td align=right>%lu</td>", 
					l->dates[y * 12 + m]);
			      }
			 }
		    }
		  
		  if (OutputMode == OUTPUT_TEXT)
		    {
		       printf("\n");
		    }
		  else
		    {
		       printf("</tr>\n");
		    }
	       }
		  
	     
	     if (OutputMode == OUTPUT_TEXT)
	       {
		  printf("Dates out of range:  %lu\n", l->invalid_dates);
	       }
	     else
	       {
		  printf("</table>\n");
		  printf("<p>Dates out of range:  %lu</p>\n", 
			 l->invalid_dates);
	       }
	  }
	
	l = l -> next;
     }
}


void ShowResults(int OutputMode, char *filename)
{
   FieldList *l;
   int i;
   int DumpDates = 0;
   char stdin_string[] = "stdin";
   
   l = head;
   if (filename == NULL)
     filename = stdin_string;
   
   if (OutputMode == OUTPUT_CSV)
     {
	printf("FIELD,TYPE,LENGTH,DEC,FULL,EMPTY,PERCENT,MIN,MAX\n");
     }
   else if (OutputMode == OUTPUT_TEXT)
     {
	printf("Database Name:  %s\n", filename);
	printf("\n");
	printf("Number of Records:  %lu\n", DB_Info.processed_records);
	if (debug)
	  printf("Records Expected:  %lu\n", DB_Info.declared_records);
	printf("Number of Fields:  %u\n", DB_Info.fields);
	printf("Record Length:  %u\n", DB_Info.record_length);
	printf("\n");
	printf("FIELD        TYPE  LEN  DEC     FULL    EMPTY  PERCENT  MIN / MAX\n");
	printf("-----------------------------------------------------------------\n");
     }
   else
     {
	printf("<html><head><title>Statistics for %s</title></head>\n",
	       filename);
	printf("<body bgcolor=\"#FFFFFF\">\n");
	printf("<pre>Database Name:  %s\n", filename);
	printf("\n");
	printf("Number of Records:  %lu\n", DB_Info.processed_records);
	if (debug)
	  printf("Records Expected:  %lu\n", DB_Info.declared_records);
	printf("Number of Fields:  %u\n", DB_Info.fields);
	printf("Record Length:  %u\n", DB_Info.record_length);
	printf("</pre>\n");
	printf("<table border=1 cellpadding=5 cellspacing=0>\n");
	printf("<tr><th>FIELD</th><th>TYPE</th><th>LENGTH</th>");
	printf("<th>DEC</th><th>FULL</th><th>EMPTY</th><th>PERCENT</th>");
	printf("<th>MIN</th><th>MAX</th></tr>\n");
     }

   while (l != NULL)
     {
	if (OutputMode == OUTPUT_CSV)
	  {
	     printf("%s,%c,%d,%d,%ld,%ld,", l->name, l->type,
		    l->len, l->dec, DB_Info.processed_records - l->empty,
		    l->empty);
	     if (DB_Info.processed_records)
	       printf("%02f,", ((float) l->empty / 
				(float) DB_Info.processed_records) * 
		      100.00);
	     else
	       printf(",");
	  }
	else if (OutputMode == OUTPUT_TEXT)
	  {
	     printf("%-13s%-6c%3d  %3d%9ld%9ld  ", l->name, l->type,
		    l->len, l->dec, DB_Info.processed_records - l->empty,
		    l->empty);
	     if (DB_Info.processed_records)
	       printf("%7.02f  ", ((float) l->empty / 
				   (float) DB_Info.processed_records) * 
		      100.00);
	     else
	       printf("         ");
	  }
	else
	  {
	     printf("<tr><th align=left>%s</th><td>%c</td>",
		    l->name, l->type);
	     printf("<td align=center>%d</td><td align=right>%d</td>",
		    l->len, l->dec);
	     printf("<td align=right>%ld</td><td align=right>%ld</td>",
		    DB_Info.processed_records - l->empty,
		    l->empty);
	     if (DB_Info.processed_records)
	       printf("<td align=right>%.02f</td>", 
		      ((float) l->empty / (float) DB_Info.processed_records) * 
		      100.00);
	     else
	       printf("<td>&nbsp;</td>");
	  }
	
	switch (l->type)
	  {
	   case 'Y':  // Currency
	     if (l->entered)
	       {
		  if (OutputMode == OUTPUT_TEXT)
		    {
		       printf("%lld.%lld / %lld.%lld", 
			      *((long long *) l->minimum) / 10000,
			      *((long long *) l->minimum) % 10000,
			      *((long long *) l->maximum) / 10000,
			      *((long long *) l->maximum) % 10000);
		    }
		  else if (OutputMode == OUTPUT_CSV)
		    {
		       printf("%lld.%lld,%lld.%lld",
			      *((long long *) l->minimum) / 10000,
			      *((long long *) l->minimum) % 10000,
			      *((long long *) l->maximum) / 10000,
			      *((long long *) l->maximum) % 10000);
		    }
		  else
		    {
		       printf("<td align=right>%lld.%lld</td>",
			      *((long long *) l->minimum) / 10000,
			      *((long long *) l->minimum) % 10000);
		       printf("<td align=right>%lld.%lld</td>",
			      *((long long *) l->maximum) / 10000,
			      *((long long *) l->maximum) % 10000);
		    }
	       }
	     else
	       {
		  if (OutputMode == OUTPUT_TEXT)
		    {
		    }
		  else if (OutputMode == OUTPUT_CSV)
		    {
		       printf(",");
		    }
		  else
		    {
		       printf("<td>&nbsp;</td><td>&nbsp;</td>");
		    }
	       }
	     break;
	     
	   case 'C':  // Character, Character Binary
	     if (l->entered)
	       {
		  if (OutputMode == OUTPUT_CSV)
		    printf("%lu,%lu", l->f, l->t);
		  else if (OutputMode == OUTPUT_TEXT)
		    printf("%lu / %lu", l->f, l->t);
		  else
		    printf("<td align=right>%lu</td><td align=right>%lu</td>",
			   l->f, l->t);
	       }
	     else
	       {
		  if (OutputMode == OUTPUT_CSV)
		    printf(",");
		  else if (OutputMode == OUTPUT_HTML)
		    printf("<td>&nbsp;</td><td>&nbsp;</td>");
	       }
	     break;
	     
	   case 'D':  // Date
	     DumpDates = 1;
	   case 'F':  // Float
	   case 'N':  // Numeric
	     if (l->entered)
	       {
		  if (OutputMode == OUTPUT_HTML)
		    printf("<td align=right>");
		  
		  for (i = 0; i < l->len && ((char *) l->minimum)[i] == ' '; 
		       i ++)
		    {
		    }
		  while (i < l->len)
		    {
		       putchar(((char *) l->minimum)[i]);
		       i ++;
		    }
		  
		  if (OutputMode == OUTPUT_TEXT)
		    printf(" / ");
		  else if (OutputMode == OUTPUT_CSV)
		    printf(",");
		  else
		    printf("</td><td align=right>");
		  
		  for (i = 0; i < l->len && ((char *) l->maximum)[i] == ' '; 
		       i ++)
		    {
		    }
		  while (i < l->len)
		    {
		       putchar(((char *) l->maximum)[i]);
		       i ++;
		    }
		  
		  if (OutputMode == OUTPUT_HTML)
		    printf("</td>");
	       }
	     else
	       {
		  if (OutputMode == OUTPUT_CSV)
		    {
		       printf(",");
		    }
		  else if (OutputMode == OUTPUT_HTML)
		    {
		       printf("<td>&nbsp;</td><td>&nbsp;</td>\n");
		    }
	       }
	     break;

	   case 'L':  // Logical
	     if (OutputMode == OUTPUT_TEXT)
	       printf("F=%lu / T=%lu", l->f, l->t);
	     else if (OutputMode == OUTPUT_CSV)
	       printf("F=%lu,T=%lu", l->f, l->t);
	     else
	       printf("<td><i>F=</i>%lu</td><td><i>T=</i>%lu</td>",
		      l->f, l->t);
	     break;
	     
	   case 'I':  // Integer
	     if (l->entered)
	       {
		  if (OutputMode == OUTPUT_TEXT)
		    {
		       printf("%ld / %ld", 
			      *((long *) l->minimum),
			      *((long *) l->maximum));
		    }
		  else if (OutputMode == OUTPUT_CSV)
		    {
		       printf("%ld,%ld",
			      *((long *) l->minimum),
			      *((long *) l->maximum));
		    }
		  else
		    {
		       printf("<td align=right>%ld</td>",
			      *((long *) l->minimum));
		       printf("<td align=right>%ld</td>",
			      *((long *) l->maximum));
		    }
	       }
	     else
	       {
		  if (OutputMode == OUTPUT_TEXT)
		    {
		    }
		  else if (OutputMode == OUTPUT_CSV)
		    {
		       printf(",");
		    }
		  else
		    {
		       printf("<td>&nbsp;</td><td>&nbsp;</td>");
		    }
	       }
	     break;
	     
	   case 'T':  // Datetime
	   case 'B':  // Double
	   case 'M':  // Memo, Memo Binary
	   case 'G':  // General
	   default:
	     if (OutputMode == OUTPUT_TEXT)
	       printf("? / ?");
	     else if (OutputMode == OUTPUT_CSV)
	       printf("?,?");
	     else
	       printf("<td align=right><i>?</i></td><td align=right><i>?</td></i>");
	  }
	if (OutputMode == OUTPUT_TEXT)
	  printf("\n");
	else if (OutputMode == OUTPUT_CSV)
	  printf("\n");
	else
	  printf("</tr>\n");
	
	l = l->next;
     }
   
   if (OutputMode == OUTPUT_HTML)
     printf("</table>\n");
   
   if (DumpDates && OutputMode != OUTPUT_CSV)
     DumpDateTables(OutputMode);
}


int main(int argc, char **argv)
{
   FILE *fp;
   int option;
   int err;
   gzFile gz;
   int OutputMode = 0, ProgressMeter = 0;

   
   while ((option = getopt(argc, argv, "cdhpt")) != -1)
     {
	switch (option)
	  {
	   case 'c':
	     OutputMode = OUTPUT_CSV;
	     break;
	     
	   case 'd':
	     debug ++;
	     break;
	     
	   case 'h':
	     fprintf(stderr, "Usage:   %s [opts] [filename]\n", argv[0]);
	     fprintf(stderr, "\n");
	     fprintf(stderr, "Options:  -h = help\n");
	     fprintf(stderr, "          -c = CSV output%s\n",
		     (OUTPUT_CSV == 0)?" (Default)":"");
	     fprintf(stderr, "          -t = Text output%s\n",
		     (OUTPUT_TEXT == 0)?" (Default)":"");
	     fprintf(stderr, "          -l = HTML output%s\n",
		     (OUTPUT_HTML == 0)?" (Default)":"");
	     fprintf(stderr, "          -p = Progress meter while loading\n");
	     fprintf(stderr, "          -d = Increase debugging level by 1\n");
	     fprintf(stderr, "\n");
	     fprintf(stderr, "Filename is the DBF (or compressed DBF) that you want to analyze.\n");
	     fprintf(stderr, "If not specified, it assumes the file will be passed in via the\n");
	     fprintf(stderr, "command line.\n");
	     fprintf(stderr, "\n");
	     fprintf(stderr, "Returns 0 if all went well.\n");
	     return 0;
	     
	   case 'l':
	     OutputMode = OUTPUT_HTML;
	     break;
	     
	   case 'p':
	     ProgressMeter = 1;
	     break;
	     
	   case 't':
	     OutputMode = OUTPUT_TEXT;
	     break;
	     
	   default:
	     fprintf(stderr, "Unknown option \"%c\"\n", option);
	     fprintf(stderr, "Try %s -h\n", argv[0]);
	     return 0;
	  }
     }
   
   if (debug)
     fprintf(stderr, "debug level is %d\n", debug);

   time(&start_time);
   
   // Filename is an optional parameter
   
   if (optind < argc)
     {
	fp = fopen(argv[optind], "rb");
	if (! fp)
	  {
	     fprintf(stderr, "Can not open \"%s\"\n", argv[optind]);
	     return 1;
	  }
     }
   else
     {
	fp = stdin;
     }
   
   // File can be compressed data.  If it is not, zlib will transparently
   // read the file (no decompression).
   gz = gzdopen(fileno(fp), "rb");
   
   // Read DBF header
   err = LoadHeader(gz);
   if (err)
     {
	FreeList();
	return err;
     }
   
   // Process fields
   err = WorkFields(gz, ProgressMeter);
   if (err)
     {
	FreeList();
	return err;
     }
   
   // Dump the results
   if (optind < argc)
     ShowResults(OutputMode, argv[optind]);
   else
     ShowResults(OutputMode, NULL);

   // Cleanup
   gzclose(gz);
   FreeList();

   return 0;
}
