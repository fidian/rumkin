/* UNTGZ Decompression Utiliy 0.95 Copyright (c) 1996,97 Tillmann Steinbrecher
 * Ripped to shreds by Tyler Akins, 2005.
 * If you want error messages, debugging information, or some well-written comments,
 * look for the source to untgz proper (not this hacked version)
 * This freeware program may be distributed according to the terms of the
 * GNU general public license version 2 - see file 'copying' for details.
 */
 
#include <stdio.h>
#include <ctype.h>
#include <conio.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <string.h>
#include <errno.h>
#include <io.h>
#include <dos.h>
#include <process.h>
#include <stdlib.h>
#ifdef __BORLANDC__
	#include <alloc.h>
	#include <dir.h>
#endif

#define PROG_NAME "untgzs"
#define UNC_OUTBUFSIZ 8192
#define OUTBUFSIZ  2048
#define WSIZE 0x8000 /* at least 32k, must be a power of 2 */

#define NEEDBITS(n) {while(k<(n)){b|=ReadByte()<<k;k+=8;}}
#define DUMPBITS(n) {b>>=(n);k-=(n);}

/* If BMAX needs to be larger than 16, then h and x[] should be ULONG. */
#define BMAX 16 /* maximum bit length of any code (16 for explode) */
#define N_MAX 288  /* maximum number of codes in any set */

/* gzip header bit flag definitions */
#define IS_MULTI 2
#define IS_EXTRA 4
#define IS_FILENAME 8
#define IS_COMMENT 16
#define IS_ENCRYPT 32

typedef unsigned char byte;
typedef char  boolean;
typedef long  longint;
typedef unsigned short UWORD;
typedef unsigned long ULONG;
typedef unsigned char  uch;

typedef struct {
	UWORD magic;
	byte method;
	byte flags;
	ULONG time;
	byte extra_flags;
	byte os;
} gzip_hdr;

typedef struct {
	ULONG crc32;
	ULONG size;
} gzip_end;

struct huft {
	byte e;
	byte b;
	union {
		UWORD n;
		struct huft *t;
	} v;
};

typedef struct {
	char name[100];
	char operm[8];
	char ouid[8];
	char ogid[8];
	char osize[12];
	char otime[12];
	char ocsum[8];
	char flags;
	char filler[355];
} TARHEADER;

unsigned char slide[WSIZE];
unsigned wp;  /* current position in slide */
FILE* in;
ULONG bb;  /* bit buffer */
unsigned bk;  /* bits in bit buffer */
int lbits = 9;  /* bits in base literal/length lookup table */
int dbits = 6;  /* bits in base distance lookup table */
unsigned hufts;  /* track memory usage */
int outfile;
long position = -1, size;
long datapos = 0;
char skip = 0;
ULONG outsiz = 0;
byte *outbuf;
byte *outptr;
int outcnt;
gzip_hdr gz_header;

/* Tables for deflate from PKZIP's appnote.txt. */
static unsigned border[] = {
	/* Order of the bit length code lengths */
	16, 17, 18, 0, 8, 7, 9, 6, 10, 5, 11, 4, 12, 3, 13, 2, 14, 1, 15
};

static UWORD cplens[] = {
	/* Copy lengths for literal codes 257..285 */
	3, 4, 5, 6, 7, 8, 9, 10, 11, 13, 15, 17, 19, 23, 27, 31,
	35, 43, 51, 59, 67, 83, 99, 115, 131, 163, 195, 227, 258, 0, 0
};

/* note: see note #13 above about the 258 in this list. */
static UWORD cplext[] = {
	/* Extra bits for literal codes 257..285 */
	0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 2, 2, 2, 2,
	3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 0, 99, 99
} ;

/* 99==invalid */
static UWORD cpdist[] = {
	/* Copy offsets for distance codes 0..29 */
	1, 2, 3, 4, 5, 7, 9, 13, 17, 25, 33, 49, 65, 97, 129, 193,
	257, 385, 513, 769, 1025, 1537, 2049, 3073, 4097, 6145,
	8193, 12289, 16385, 24577
};

static UWORD cpdext[] = {
	/* Extra bits for distance codes */
	0, 0, 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 6, 6,
	7, 7, 8, 8, 9, 9, 10, 10, 11, 11,
	12, 12, 13, 13
};

UWORD mask_bits[] = {
	0x0000,
	0x0001, 0x0003, 0x0007, 0x000f, 0x001f, 0x003f, 0x007f, 0x00ff,
	0x01ff, 0x03ff, 0x07ff, 0x0fff, 0x1fff, 0x3fff, 0x7fff, 0xffff
};

int istarheader(unsigned char *hdr, long csum);
void createnewdir(char *name);
void create_path(char *path);
int openfile(char *name);
void untarstream(unsigned char *data, unsigned long datasize);
unsigned long ReadByte(void);
int huft_build(unsigned *b, unsigned n, unsigned s, UWORD *d, UWORD *e,
struct huft **t, int *m);
int huft_free(struct huft *t);
void flush(unsigned w);
int inflate_codes(struct huft *tl, struct huft *td, int bl, int bd);
int inflate_stored(void);
int inflate_fixed(void);
int inflate_dynamic(void);
int inflate_block(int *e);
int inflate_entry(void);
unsigned long updcrc(unsigned char *s, unsigned long n);
long OctalToLong(char *c);
#ifndef WIN32
void dos_pathname(char *name);
#endif
void FlushOutput(void);
int SkipToNull(void);
int extract_tar(void);
int check_valid(void);
int read_tar_header(void);
int read_gzip_header(void);
int main(int argc, char **argv);


unsigned long ReadByte(void)
{
	int x;

	x=getc(in);
	if(x==EOF)
	{
		puts(PROG_NAME": error - unexpected end of file");
		exit(2);
	}
	return (unsigned long) x;
}


int huft_build(unsigned *b, unsigned n, unsigned s, UWORD *d, UWORD *e,
struct huft **t, int *m)
{
	unsigned a;
	/* counter for codes of length k */
	unsigned c[BMAX+1];
	/* bit length count table */
	unsigned f;
	/* i repeats in table every f entries */
	int g;
	/* maximum code length */
	int h;
	/* table level */
	register unsigned i;
	/* counter, current code */
	register unsigned j;
	/* counter */
	register int k;
	/* number of bits in current code */
	int l;
	/* bits per table (returned in m) */
	register unsigned *p;
	/* pointer into c[], b[], or v[] */
	register struct huft *q;
	/* points to current table */
	struct huft r;
	/* table entry for structure assignment */
	struct huft *u[BMAX];
	/* table stack */
	unsigned v[N_MAX];
	/* values in order of bit length */
	register int w;
	/* bits before this table == (l * h) */
	unsigned x[BMAX+1];
	/* bit offsets, then code stack */
	unsigned *xp;
	/* pointer into x */
	int y;
	/* number of dummy codes added */
	unsigned z;
	/* number of entries in current table */
	/* Generate counts for each bit length */
	memset(c, 0, sizeof(c));
	p = b;
	i = n;
	do {
		c[*p++]++;
		/* assume all entries <= BMAX */
	} while (--i);
	if (c[0] == n)
		return 2;
	/* bad input--all zero length codes */
	/* Find minimum and maximum length, bound *m by those */
	l = *m;
	for (j = 1; j <= BMAX; j++)
	{
		if (c[j])
			break;
	}
	k = j;
	/* minimum code length */
	if ((unsigned)l < j)
		l = j;
	for (i = BMAX; i; i--)
	{
		if (c[i])
			break;
	}
	g = i;
	/* maximum code length */
	if ((unsigned)l > i)
		l = i;
	*m = l;
	/* Adjust last length count to fill out codes, if needed */
	for (y = 1 << j; j < i; j++, y <<= 1)
	{
		if ((y -= c[j]) < 0)
			return 2;
	}
	/* bad input: more codes than bits */
	if ((y -= c[i]) < 0)
		return 2;
	c[i] += y;
	/* Generate starting offsets into the value table for each length */
	x[1] = j = 0;
	p = c + 1;
	xp = x + 2;
	while (--i)
	{
		/* note that i == g from above */
		*xp++ = (j += *p++);
	}
	/* Make a table of values in order of bit lengths */
	p = b;
	i = 0;
	do {
		if ((j = *p++) != 0)
		v[x[j]++] = i;
	} while (++i < n);
	/* Generate the Huffman codes and for each, make the table entries */
	x[0] = i = 0;
	/* first Huffman code is zero */
	p = v;
	/* grab values in bit order */
	h = -1;
	/* no tables yet--level -1 */
	w = -l;
	/* bits decoded == (l * h) */
	u[0] = (struct huft *)NULL;
	/* just to keep compilers happy */
	q = (struct huft *)NULL;
	/* ditto */
	z = 0;
	/* ditto */
	/* go through the bit lengths (k already is bits in shortest code) */
	for (; k <= g; k++)
	{
		a = c[k];
		while (a--)
		{
			/* here i is the Huffman code of length k bits for value *p */
			/* make tables up to required level */
			while (k > w + l)
			{
				h++;
				w += l;
				/* previous table always l bits */
				/* compute minimum size table less than or equal to l bits */
				z = (z = g - w) > (unsigned)l ? l : z;
				/* upper limit on table size */
				if ((f = 1 << (j = k - w)) > a + 1) /* try a k-w bit table */
				{
					/* too few codes for k-w bit table */
					f -= a + 1;
					/* deduct codes from patterns left */
					xp = c + k;
					while (++j < z)	 /* try smaller tables up to z bits */
					{
						if ((f <<= 1) <= *++xp)
							break;
						/* enough codes to use up j bits */
						f -= *xp;
						/* else deduct codes from patterns */
					}
				}
				z = 1 << j;
				/* table entries for j-bit table */
				/* allocate and link in new table */
				q = (struct huft *) malloc((z + 1) * sizeof(struct huft));
				if (q == (struct huft *) NULL)
				{
					if (h)
						huft_free(u[0]);
					puts(PROG_NAME ": error - inflate out of memory");
					return 3;
					/* not enough memory */
				}
				hufts += z + 1;
				/* track memory usage */
				*t = q + 1;
				/* link to list for huft_free() */
				*(t = &(q->v.t)) = (struct huft *)NULL;
				u[h] = ++q;
				/* table starts after link */
				/* connect to last table, if there is one */
				if (h)
				{
					x[h] = i;
					/* save pattern for backing up */
					r.b = (byte)l;
					/* bits to dump before this table */
					r.e = (byte)(16 + j);
					/* bits in this table */
					r.v.t = q;
					/* pointer to this table */
					j = i >> (w - l);
					/* (get around Turbo C bug) */
					u[h-1][j] = r;
					/* connect to last table */
				}
			}
			/* set up table entry in r */
			r.b = (byte)(k - w);
			if (p >= v + n)
				r.e = 99;
			/* out of values--invalid code */
			else if (*p < s)
			{
				r.e = (byte)(*p < 256 ? 16 : 15);
				/* 256 is end-of-block code */
				r.v.n = *p++;
				/* simple code is just the value */
			}
			else
			{
				r.e = (byte)e[*p - s];
				/* non-simple--look up in lists */
				r.v.n = d[*p++ - s];
			}
			/* fill code-like entries with r */
			f = 1 << (k - w);
			for (j = i >> w; j < z; j += f)
				q[j] = r;
			/* backwards increment the k-bit code i */
			for (j = 1 << (k - 1); i & j; j >>= 1)
				i ^= j;
			i ^= j;
			/* backup over finished tables */
			while ((i & ((1 << w) - 1)) != x[h])
			{
				h--;
				/* don't need to update q */
				w -= l;
			}
		}
	}
	/* Return true (1) if we were given an incomplete table */
	return y != 0 && n != 1;
}


int huft_free(struct huft *t)
{
	register struct huft *p, *q;
	/* Go through linked list, freeing from the malloced (t[-1]) address. */
	p = t;
	while (p != (struct huft *)NULL)
	{
		q = (--p)->v.t;
		free(p);
		p = q;
	}
	return 0;
}


void flush(unsigned w)
{
	unsigned n;
	byte *p;
	p = slide;
	while (w)
	{
		n = (n = OUTBUFSIZ - outcnt) < w ? n : w;
		memcpy(outptr, p, n);
		/* try to fill up buffer */
		outptr += n;
		if ((outcnt += n) == OUTBUFSIZ)
			FlushOutput();
		/* if full, empty */
		p += n;
		w -= n;
	}
}


int inflate_codes(struct huft *tl, struct huft *td, int bl, int bd)
{
	register unsigned e;
	/* table entry flag/number of extra bits */
	unsigned n, d;
	/* length and index for copy */
	unsigned w;
	/* current window position */
	struct huft *t;
	/* pointer to table entry */
	unsigned ml, md;
	/* masks for bl and bd bits */
	register ULONG b;
	/* bit buffer */
	register unsigned k;
	/* number of bits in bit buffer */
	/* make local copies of globals */
	b = bb;
	/* initialize bit buffer */
	k = bk;
	w = wp;
	/* initialize window position */
	/* inflate the coded data */
	ml = mask_bits[bl];
	/* precompute masks for speed */
	md = mask_bits[bd];
	while (1)  /* do until end of block */
	{
		NEEDBITS((unsigned)bl)
		if ((e = (t = tl + ((unsigned)b & ml))->e) > 16)
		do {
			if (e == 99)
				return 1;
			DUMPBITS(t->b)
			e -= 16;
			NEEDBITS(e)
		} while ((e = (t = t->v.t + ((unsigned)b & mask_bits[e]))->e) > 16);
		DUMPBITS(t->b)
		if (e == 16) /* then it's a literal */
		{
			slide[w++] = (byte)t->v.n;
			if (w == WSIZE)
			{
				flush(w);
				w = 0;
			}
		}
		else /* it's an EOB or a length */
		{
			/* exit if end of block */
			if (e == 15)
				break;
			/* get length of block to copy */
			NEEDBITS(e)
			n = t->v.n + ((unsigned)b & mask_bits[e]);
			DUMPBITS(e);
			/* decode distance of block to copy */
			NEEDBITS((unsigned)bd)
			if ((e = (t = td + ((unsigned)b & md))->e) > 16)
			{
				do {
					if (e == 99)
						return 1;
					DUMPBITS(t->b)
					e -= 16;
					NEEDBITS(e)
				} while ((e = (t = t->v.t + ((unsigned)b & mask_bits[e]))->e) > 16);
			}
			DUMPBITS(t->b)
			NEEDBITS(e)
			d = w - t->v.n - ((unsigned)b & mask_bits[e]);
			DUMPBITS(e)
			/* do the copy */
			do {
				n -= (e = (e = WSIZE - ((d &= WSIZE-1) > w ? d : w)) > n ? n : e);
				do {
					slide[w++] = slide[d++];
				} while (--e);
				if (w == WSIZE)
				{
					flush(w);
					w = 0;
				}
			} while (n);
		}
	}
	/* restore the globals from the locals */
	wp = w;
	/* restore global window pointer */
	bb = b;
	/* restore global bit buffer */
	bk = k;
	/* done */
	return 0;
}


int inflate_stored()
{
	unsigned n;
	/* number of bytes in block */
	unsigned w;
	/* current window position */
	register ULONG b;
	/* bit buffer */
	register unsigned k;
	/* number of bits in bit buffer */
	/* make local copies of globals */
	b = bb;
	/* initialize bit buffer */
	k = bk;
	w = wp;
	/* initialize window position */
	/* go to byte boundary */
	n = k & 7;
	DUMPBITS(n);
	/* get the length and its complement */
	NEEDBITS(16)
	n = ((unsigned)b & 0xffff);
	DUMPBITS(16)
	NEEDBITS(16)
	if (n != (unsigned)((~b) & 0xffff))
		return 1;
	/* error in compressed data */
	DUMPBITS(16)
	/* read and output the compressed data */
	while (n--)
	{
		NEEDBITS(8)
		slide[w++] = (byte)b;
		if (w == WSIZE)
		{
			flush(w);
			w = 0;
		}
		DUMPBITS(8)
	}
	/* restore the globals from the locals */
	wp = w;
	/* restore global window pointer */
	bb = b;
	/* restore global bit buffer */
	bk = k;
	return 0;
}


int inflate_fixed()
{
	int i;
	/* temporary variable */
	struct huft *tl;
	/* literal/length code table */
	struct huft *td;
	/* distance code table */
	int bl;
	/* lookup bits for tl */
	int bd;
	/* lookup bits for td */
	unsigned l[288];
	/* length list for huft_build */
	/* set up literal table */
	for (i = 0; i < 144; i++)
		l[i] = 8;
	for (; i < 256; i++)
		l[i] = 9;
	for (; i < 280; i++)
		l[i] = 7;
	for (; i < 288; i++)  /* make a complete, but wrong code set */
		l[i] = 8;
	bl = 7;
	if ((i = huft_build(l, 288, 257, cplens, cplext, &tl, &bl)) != 0)
		return i;
	/* set up distance table */
	for (i = 0; i < 30; i++)  /* make an incomplete code set */
		l[i] = 5;
	bd = 5;
	if ((i = huft_build(l, 30, 0, cpdist, cpdext, &td, &bd)) > 1)
	{
		huft_free(tl);
		return i;
	}
	/* decompress until an end-of-block code */
	if (inflate_codes(tl, td, bl, bd))
		return 1;
	/* free the decoding tables, return */
	huft_free(tl);
	huft_free(td);
	return 0;
}
int inflate_dynamic()
{
	int i;
	/* temporary variables */
	unsigned j;
	unsigned l;
	/* last length */
	unsigned m;
	/* mask for bit lengths table */
	unsigned n;
	/* number of lengths to get */
	struct huft *tl;
	/* literal/length code table */
	struct huft *td;
	/* distance code table */
	int bl;
	/* lookup bits for tl */
	int bd;
	/* lookup bits for td */
	unsigned nb;
	/* number of bit length codes */
	unsigned nl;
	/* number of literal/length codes */
	unsigned nd;
	/* number of distance codes */
	unsigned ll[286+30];
	/* literal/length and distance code lengths */
	register ULONG b;
	/* bit buffer */
	register unsigned k;
	/* number of bits in bit buffer */
	/* make local bit buffer */
	b = bb;
	k = bk;
	/* read in table lengths */
	NEEDBITS(5)
	nl = 257 + ((unsigned)b & 0x1f);
	/* number of literal/length codes */
	DUMPBITS(5)
	NEEDBITS(5)
	nd = 1 + ((unsigned)b & 0x1f);
	/* number of distance codes */
	DUMPBITS(5)
	NEEDBITS(4)
	nb = 4 + ((unsigned)b & 0xf);
	/* number of bit length codes */
	DUMPBITS(4)
	if (nl > 286 || nd > 30)
		return 1;
	/* bad lengths */
	/* read in bit-length-code lengths */
	for (j = 0; j < nb; j++)
	{
		NEEDBITS(3)
		ll[border[j]] = (unsigned)b & 7;
		DUMPBITS(3)
	}
	for (; j < 19; j++)
		ll[border[j]] = 0;
	/* build decoding table for trees--single level, 7 bit lookup */
	bl = 7;
	if ((i = huft_build(ll, 19, 19, NULL, NULL, &tl, &bl)) != 0)
	{
		if (i == 1)
			huft_free(tl);
		return i;
		/* incomplete code set */
	}
	/* read in literal and distance code lengths */
	n = nl + nd;
	m = mask_bits[bl];
	i = l = 0;
	while ((unsigned)i < n)
	{
		NEEDBITS((unsigned)bl)
		j = (td = tl + ((unsigned)b & m))->b;
		DUMPBITS(j)
		j = td->v.n;
		if (j < 16) /* length of code in bits (0..15) */
			ll[i++] = l = j;
		/* save last length in l */
		else if (j == 16) /* repeat last length 3 to 6 times */
		{
			NEEDBITS(2)
			j = 3 + ((unsigned)b & 3);
			DUMPBITS(2)
			if ((unsigned)i + j > n)
				return 1;
			while (j--)
				ll[i++] = l;
		}
		else if (j == 17) /* 3 to 10 zero length codes */
		{
			NEEDBITS(3)
			j = 3 + ((unsigned)b & 7);
			DUMPBITS(3)
			if ((unsigned)i + j > n)
				return 1;
			while (j--)
				ll[i++] = 0;
			l = 0;
		}
		else /* j == 18: 11 to 138 zero length codes */
		{
			NEEDBITS(7)
			j = 11 + ((unsigned)b & 0x7f);
			DUMPBITS(7)
			if ((unsigned)i + j > n)
				return 1;
			while (j--)
				ll[i++] = 0;
			l = 0;
		}
	}
	/* free decoding table for trees */
	huft_free(tl);
	/* restore the global bit buffer */
	bb = b;
	bk = k;
	/* build the decoding tables for literal/length and distance codes */
	bl = lbits;
	if ((i = huft_build(ll, nl, 257, cplens, cplext, &tl, &bl)) != 0)
	{
		if (i == 1)
			huft_free(tl);
		return i;
		/* incomplete code set */
	}
	bd = dbits;
	if ((i = huft_build(ll + nl, nd, 0, cpdist, cpdext, &td, &bd)) != 0)
	{
		if (i == 1)
			huft_free(td);
		huft_free(tl);
		return i;
		/* incomplete code set */
	}
	/* decompress until an end-of-block code */
	if (inflate_codes(tl, td, bl, bd))
		return 1;
	/* free the decoding tables, return */
	huft_free(tl);
	huft_free(td);
	return 0;
}


int inflate_block(int *e)
{
	unsigned t;
	/* block type */
	register ULONG b;
	/* bit buffer */
	register unsigned k;
	/* number of bits in bit buffer */
	/* make local bit buffer */
	b = bb;
	k = bk;
	/* read in last block bit */
	NEEDBITS(1)
	*e = (int)b & 1;
	DUMPBITS(1)
	/* read in block type */
	NEEDBITS(2)
	t = (unsigned)b & 3;
	DUMPBITS(2)
	/* restore the global bit buffer */
	bb = b;
	bk = k;
	/* inflate that block type */
	if (t == 2)
		return inflate_dynamic();
	if (t == 0)
		return inflate_stored();
	if (t == 1)
		return inflate_fixed();
	/* bad block type */
	return 2;
}


int inflate_entry()
{
	int e;
	/* last block flag */
	int r;
	/* result code */
	unsigned h;
	/* maximum struct huft's malloc'ed */
	/* initialize window, bit buffer */
	wp = 0;
	bk = 0;
	bb = 0;
	/* decompress until the last block */
	h = 0;
	do {
		hufts = 0;
		if ((r = inflate_block(&e)) != 0)
			return r;
		if (hufts > h)
			h = hufts;
	} while (!e);
	/* flush out slide */
	flush(wp);
	/* return success */
	return 0;
}


unsigned long updcrc(unsigned char *s, unsigned long n)
{
	unsigned long crc_calc;
	unsigned short i;
	static unsigned long crc = 0xffffffffL;
	/* shift register contents */
	if (s == (unsigned char *)NULL)
		crc = 0xffffffffL;
	else
	{
		while (n--)
		{
			crc_calc = ((int) crc ^ (* s++)) & 0xff;
			for (i = 0; i < 8; i ++)
			{
				if (crc_calc & 1)
					crc_calc = (crc_calc >> 1) ^ 0xedb88320;
				else
					crc_calc >>= 1;
			}
			crc = crc_calc ^ (crc >> 8);
		}
	}
	return crc ^ 0xffffffffL;
}


long OctalToLong(char *c)
{
	int i = 0;
	long l = 0;
	while (c[i] >= '0' && c[i] <= '7')
	{
		l *= 8;
		l += c[i] - '0';
		i ++;
	}
	return l;
}


#ifndef WIN32
void dos_pathname(char *name)
{
	int pos=0,length=1,newpos=0,max=8;
	while(name[pos])
	{
		if(name[pos]=='.')
		{
			if(length!=1)
			{
				if(max!=3)
				{
					max=3;
					length=0;
				}
				else
				{
					length=max+1;
				}
			}
			else if(name[pos+1]!='/')
				pos++;
		}
		if(length<=max)
		{
			name[newpos]=name[pos];
			if (name[newpos] == ',' || name[newpos] == '+' ||
				name[newpos] == '=')
				name[newpos]='_';
			if(name[newpos]=='\\')
				name[newpos]='\\';
			newpos++;
		}
		pos++;
		length++;
		if(name[pos]=='/')
		{
			max=8;
			length=0;
		}
	}
	name[newpos]=0;
}
#endif


int istarheader(unsigned char *hdr, long csum)
{
	long newsum=0;
	int cnt;
	
	for(cnt=0; cnt<=147; cnt++)
		newsum+=*(hdr+cnt);
	for(cnt=156; cnt<512; cnt++)
		newsum+=*(hdr+cnt);
	newsum+=256;
	if(newsum==csum)
		return 1;
	return 0;
}


void createnewdir(char *name)
{
	char stat;
	if (name[strlen(name)-1] == '/')
		name[strlen(name)-1] = 0;
#ifdef GNUDOS
	stat = mkdir(name,0);
#else
	stat = mkdir(name);
#endif
	if (stat && errno != EACCES)
	{
		puts(PROG_NAME ": error - unable to create directory");
	}
}


void create_path(char *path)
{
	char pos;
	
	for(pos=0; path[pos]; pos++)
	{
		if(path[pos]=='/')
		{
			path[pos]='\0';
			createnewdir(path);
			path[pos] = '/';
		}
	}
}


int openfile(char *name)
{
	outfile = open(name, O_WRONLY|O_BINARY|O_CREAT|O_EXCL, S_IWRITE|S_IREAD);
	if (outfile < 0 && errno==ENOENT)
	{
		create_path(name);
		outfile = open(name, O_WRONLY|O_BINARY|O_CREAT|O_EXCL, S_IWRITE|S_IREAD);
	}
	if (outfile < 0 && errno==EEXIST)
	{
		outfile=open(name, O_WRONLY|O_BINARY|O_TRUNC, S_IWRITE|S_IREAD);
	}
	if(outfile<0)
	{
		puts(PROG_NAME ": error - can't create file, skipping file:");
		puts(name);
		return 1;
	}
	return 0;
}


void untarstream(unsigned char *data, unsigned long datasize)
{
	unsigned long dsize=0;
	TARHEADER header;
	long csum;
	datapos=0;
	while (1)
	{
		if(position==-1)
		{
			do {
				memcpy( &header, data+datapos,512);
				if (header.name[0] == 0)
					break;
				csum = OctalToLong(header.ocsum);
				size = OctalToLong(header.osize);
				datapos+=512;
				if (datapos>datasize)
					return;
			} while(!istarheader((char*)&header,csum));
			if (header.name[0] == 0)
				break;
			position=0;
			skip=0;
#ifndef WIN32
			dos_pathname(header.name);
#endif
			if (header.flags=='5'||header.name[strlen(header.name)-1]=='/')
			{
				if (header.name[strlen(header.name)-1] == '/')
					header.name[strlen(header.name)-1] = 0;
				createnewdir(header.name);
				skip=1;
				/* Directory ??? */
			}
			else
			{
				skip=openfile(header.name);
			}
		}
		if ((size-position) <= (datasize-datapos))
		{
			dsize = size-position;
		}
		else
			dsize = (datasize-datapos);
		if (!skip)
		{
			if (write(outfile, data+datapos, dsize) < dsize)
			{
				puts(PROG_NAME ": error - can't write file, disk full?");
				exit(2);
			}
		}
		position += dsize;
		datapos += dsize;
		if (size == position)
		{
			if (!skip)
			{
				close(outfile);
			}
			position = -1;
			if (datapos % 512)
				datapos=((datapos / 512) + 1) * 512;
		}
		if (datasize==datapos)
			return;
		/* Finished processing buffer */
	}
}


void FlushOutput(void)
{
	if (outcnt)
	{
		updcrc(outbuf,outcnt);
		untarstream(outbuf,outcnt);
		outsiz += outcnt;
		outptr = outbuf;
		outcnt = 0;
	}
}


int SkipToNull(void)
{
	int c;

	c = getc(in);
	while (c != EOF && c)
	{
		c = getc(in);
	}
	return (c == EOF);
}


int extract_tar(void)
{
	char* buffer;
	int cnt;
	
	buffer = malloc(UNC_OUTBUFSIZ);
	if(buffer == 0)
	{
		puts(PROG_NAME": error - can't allocate memory");
		return -1;
	}
	while (!feof(in))
	{
		cnt = fread(buffer, 1, UNC_OUTBUFSIZ, in);
		untarstream(buffer, cnt);
	}
	return 0;
}


int check_valid(void)
{
	gzip_end end_info;
	ULONG new_crc32;
	
	new_crc32=updcrc(outbuf,0);
	if(fread(&end_info,1,sizeof(end_info),in)<sizeof(end_info))
	{
		fseek(in,(-8),SEEK_CUR);
		/* If we couldn't get it the first
		time, then we'll seek back and try again */
		if(fread(&end_info,1,sizeof(end_info),in)<sizeof(end_info))
		{
			puts(PROG_NAME ": error - can't read stored crc");
			return -1;
		}
	}
	if (new_crc32 != end_info.crc32)
	{
		puts(PROG_NAME ": error - broken file(s), crc32 error!");
		return -1;
	}
	return 0;
}


int read_tar_header(void)
{
	TARHEADER unc_hdr;
	long csum;

	fread(&unc_hdr, 512, 1, in);
	csum = OctalToLong(unc_hdr.ocsum);
	if (istarheader((char *) &unc_hdr, csum))
	{
		fseek(in, 0, SEEK_SET);
		return 0;
	}
	return 1;
}


int read_gzip_header(void)
{
	fread(&gz_header, sizeof(gz_header), 1, in);
	if (gz_header.magic != 0x8b1f)
		return 1;
	if (gz_header.flags & (IS_MULTI|IS_EXTRA|IS_ENCRYPT) ||
		gz_header.method != 8)
	{
		puts(PROG_NAME ": error - can't handle this type of .gz file");
		return -1;
	}
	if(gz_header.flags & IS_FILENAME)
	{
		if(SkipToNull())
		{
			puts(PROG_NAME ": error - unexpected end of file");
			return -1;
		}
	}
	if(gz_header.flags & IS_COMMENT)
	{
		if(SkipToNull())
		{
			puts(PROG_NAME ": error - unexpected end of file");
			return -1;
		}
	}
	updcrc(NULL,0);
	/* Initialize CRC engine */
	return 0;
}


int main(int argc, char **argv)
{
	int stat;

	if(argc<2)
	{
		puts("UNTGZ - TAR/TGZ Decompression Utility -- freeware -- version 0.95b\n"
		"Copyright (c) 1996,97 Tillmann Steinbrecher\n"
		"Stripped down by Tyler Akins, 2005\n"
		"USAGE: UNTGZ2 <filename> to extract from TGZ/TAR archive\n"
		" This freeware program may be distributed according to\n"
		" the terms of the GNU general public license version 2.\n\n");
		return 1;
	}
	in = fopen(argv[1], "rb");
	if (in == 0)
	{
		puts(PROG_NAME ": error - can't open input file");
		return 1;
	}
	stat=read_gzip_header();
	if(!stat)
	{
		if((outbuf=(byte*)malloc(OUTBUFSIZ))==0)
		{
			puts(PROG_NAME": error - can't allocate memory for write buffer");
			return -1;
		}
		outptr=outbuf;
		if (inflate_entry())
			puts(PROG_NAME ": bad compressed data");
		FlushOutput();
		check_valid();
		return 0;
	}
	if (stat == -1)
		return -1;
	fseek(in, 0, SEEK_SET);
	stat = read_tar_header();
	if (!stat)
		extract_tar();
	else
		puts(PROG_NAME": error - not a supported archive type");
	return 0;
}
