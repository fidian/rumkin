untgzs.exe = Small version of untgz, limited to DOS 8.3 filename convention
untgzs32.exe = 32-bit Windows console version, supports long file names

To run either, specify the .tgz or .tar file on the command line:

untgzs the_file.tgz


CHANGES
=======
removed file timestamps
removed most of the output to the user
removed all of the options
removed almost all of the #ifdefs because I didn't like how they looked
removed CRC lookup table (a little slower, but shouldn't even be noticed)
replaced printf() with puts()
replaced sscanf() with OctalToLong()
removed anything that mission in life was to extract the file
Made it just one big file instead of including little subfiles (they
   reference each other, so might as well...)
removed code that wasn't used anymore
tweaked optimization flags
used upx -9 to compress further
