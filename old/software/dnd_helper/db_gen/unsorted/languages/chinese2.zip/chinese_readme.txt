************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** INFO *********** 
**************************** 

Chinese languages, also called SINITIC, Chinese HAN, the principal language group of eastern Asia, belonging to
the Sino-Tibetan language family.<br>
Chinese exists in a number of varieties that are popularly called dialects but that are usually classified as
separate languages by scholars.<br>
More people speak a variety of Chinese as a native language than any other language in the world, 
and Modern Standard Chinese is one of the five official languages of the United Nations.

**************************** 
*********** ABOUT ********** 
**************************** 

This Chinese Wordlist was created by Jim Tomayko(see his readme below).
I sorted it and removed dupes(just to be sure that it is really sorted).

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 442 Words
2464 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

Single Chinese syllables,
The Chinese sounds are the Pinyin Romanization System, which has been the
world standard for over a decade. However, Taiwan native Chinese still use
the Wade-Giles system, so this sound list won't cover all of that.  Also,
this is for the Beijing dialect, which is also the national standard, but
if some wise-guy Fukienese uses his own dialect, you will not detect it.

Donated by Jim Tomayko

