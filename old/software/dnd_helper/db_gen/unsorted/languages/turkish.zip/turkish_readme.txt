************************************** 
************************************** 
***** brought to you by          ***** 
*****                            ***** 
***** The Wordlist Project       ***** 
***** http://wordlists.cjb.net   ***** 
***** b4a@gmx.net                ***** 
************************************** 
**************************************

**************************** 
*********** INFO *********** 
**************************** 

Turkish language, Turkish T&Uuml;RKCE, member of the Turkic language family (a subfamily of the Altaic language group)
spoken in Turkey, Cyprus, and elsewhere in southeastern Europe and the Middle East.<br>
With Azerbaijani (Azeri), Turkmen, and Gagauz, it forms the southwestern, or Oguz, division of the Turkic languages.


**************************** 
*********** ABOUT ********** 
**************************** 

This Turkish Wordlist was created by an unknown author(no readme).
I sorted it and removed dupes.

I hope it will be useful!

  Thomas

The Wordlist Project
 --> http://wordlists.cjb.net

The Windows Spying Project
 --> http://spywin.cjb.net

Email
 --> b4a@gmx.net

The Karanet BBS
     --> http://www.karanet.at
     --> telnet://karanet.uni-klu.ac.at
   I am "Fox" on this BBS.

**************************** 
******** WORD-COUNT ******** 
****************************

 25854 Words
241074 Bytes(Uncompressed, DOS format) 

**************************** 
********* DISCLAIMER ******* 
**************************** 

All publications of "The Wordlist Project" are distributed in the hope 
that they will be useful, but WITHOUT ANY WARRANTY; without even the 
implied warrenty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

I DO NOT guarantee any completeness or linguistic correctness of wordlists
distributed by "The Wordlist Project" and so I can't be blamed for any missing
or false words.

This list as it was distributed by "The Wordlist Project" is for personal
use only!
For commercial use of part of this list you MUST obtain written permission
from ALL authors/creators/editors who may have a copyright on parts of the list. 

If you own the copyright on part of this or other publications of "The Wordlist
Project" and you don't allow redistribution under the terms above please tell me!

**************************** 
** ORIGINAL DOCUMENTATION **
**************************** 

From cagri@dolphin1.cc.metu.edu.trFri Oct 24 13:21:18 1997
Date: Fri, 24 Oct 1997 13:13:49 +0300 (USADT)
From: cagri coltekin <cagri@dolphin1.cc.metu.edu.tr>
To: agurkan@newton.physics.metu.edu.tr
Subject: turkce sozluk
