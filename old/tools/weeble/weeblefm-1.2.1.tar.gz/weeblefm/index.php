<?php
/*
  Weeble File Manager (c) Christopher Michaels & Jonathan Manna
  This software is released under the BSD License.  For a copy of
  the complete licensing agreement see the LICENSE file.
*/
?><HTML>
 <HEAD>
  <TITLE>Redirect</TITLE>
  <META HTTP-EQUIV="Refresh" content="0;URL=login.php">
 </HEAD>
 <BODY>
 <P><A HREF="login.php">Click here if your browser does not
automatically redirect you.</A></P>
 </BODY>
</HTML>
