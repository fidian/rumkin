<?PHP
/* Sprint File Uploader
 *
 * Copyright (C) 2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for legal information
 * See http://rumkin.com/tools/sprint/ for more information about these tools
 */

// Maximum file size in bytes
$MaxSize = 500000;
$JadSize = 5000;

$ContentVendor = 'Rumkin.com Upload';
$URLBase = 'http://www.gtoal.com/pcs/';

include 'functions.inc';
include 'utils.inc';
include 'messaging.inc';

if (get_magic_quotes_gpc())
{
    foreach ($_POST as $k => $v)
    {
	$_POST[$k] = stripslashes($v);
    }
}

StandardHeader(array('title' => 'Sprint PCS Vision File Uploader',
		     'topic' => 'sprint',
		     'page' => 'sprint'));

// phone number or email address = sendto
// subject of email = desc
// single file = fn
// otherwise a jar = jar and jad = jad

// Check to make sure the directory exists.
if (! is_dir($GLOBALS['TempDir']))
{
    if (! mkdir($GLOBALS['TempDir']))
    {
	Bail('Can not create temporary directory.  System misconfigured.');
    }
}

// Make sure it is a proper upload
if (! isset($_POST['sendto']) || ! isset($_POST['desc']))
  Bail('Please fill in all fields.');

$sendto = $_POST['sendto'];
if (strpos($sendto, '@') !== false)
{
    // Treat as email address.  Remove stuff that could be bad.  Be strict.
    $sendto = preg_replace('/[^@a-zA-Z0-9\.\-_]/', '', $sendto);
    $type = 'email address';
    if (! preg_match('/[^@]+@[^@]+/', $sendto))
      Bail("The email address \"$sendto\" is invalid.");
    if (isset($GLOBALS['Email Match']) &&
	! preg_match($GLOBALS['Email Match'], $sendto))
      Bail($GLOBALS['Email Match Message']);
}
else
{
    // Treat as phone number.  Remove stuff that could be bad.  Be strict.
    $sendto = preg_replace('/[^0-9]/', '', $sendto);
    $type = 'phone number';
    if (strlen($sendto) != 10)
      Bail('Phone number must be 10 digits long.');
}

// Check folder name
if (isset($_POST['fldr']) && $_POST['fldr'] != 'default')
{
    $folder = $_POST['fldr'];
    if ($folder == 'userdef')
    {
	$folder = $_POST['userdeffldr'];
    }
    if ($folder == '')
      unset($folder);
}

if (! isset($_FILES['fn']) && 
    (! isset($_FILES['jar']) || ! isset($_FILES['jad'])))
  Bail('You need to upload a file to send to your phone.  ' .
       'If uploading a midlet, you need to send both the jar and the ' . 
       'jad file.');

// Check file sizes
if (isset($_FILES['fn']))
{
    if ($_FILES['fn']['size'] > $MaxSize)
      Bail('File is too large.  Please keep it under ' . $MaxSize . 
	   ' bytes.');
    if (isset($GLOBALS['File Match']) &&
	! preg_match($GLOBALS['File Match'], $_FILES['fn']['name']))
      Bail($GLOBALS['File Match Message']);
}
else
{
    if ($_FILES['jar']['size'] > $MaxSize)
      Bail('Java midlet is too large.  Please keep it under ' . $MaxSize .
	   ' bytes.');
    if (isset($GLOBALS['Jar Match']) &&
	! preg_match($GLOBALS['Jar Match'], $_FILES['jar']['name']))
      Bail($GLOBALS['Jar Match Message']);
    if ($_FILES['jad']['size'] > $JadSize)
      Bail('Java midlet descriptor is too big.  Please keep it under ' .
	   $JadSize . ' bytes');
    if (isset($GLOBALS['Jad Match']) &&
	! preg_match($GLOBALS['Jad Match'], $_FILES['jad']['name']))
      Bail($GLOBALS['Jad Match Message']);
}

// RandomName
$RandomName = MakeRandomName();

// Save a proper descriptor file
if (isset($_FILES['fn']))
{
    $Data = array();
    $ext = $_FILES['fn']['name'];
    $ext = substr($ext, strrpos($ext, '.') + 1);
    $Data[] = 'Content-Type: ' . GetMimeType($ext);
    $Data[] = 'Content-Name: ' . $_POST['desc'];
    $Data[] = 'Content-Version: 1.0';
    $Data[] = 'Content-Vendor: ' . $ContentVendor;
    $Data[] = 'Content-URL: ' . $URLBase . 'download.php/' . $RandomName .
      '/' . SafeFilename($_FILES['fn']['name']);
    $Data[] = 'Content-Size: ' . $_FILES['fn']['size'];
    $DescUrl = $URLBase . 'desc.php/gcd' . $RandomName . '/' . 
      SafeFilename($_FILES['fn']['name']);
    $DescUrl = substr($DescUrl, 0, strrpos($DescUrl, '.')) . '.gcd';
}
else
{
    $Data = array();
    $DataSrc = array();
    $fp = fopen($_FILES['jad']['tmp_name'], 'r');
    $m = fread($fp, $JadSize);
    $m = str_replace("\r\n", "\n", $m);
    $m = str_replace("\r", "\n", $m);
    $m = split("\n", $m);
    $did_folder = false;
    $did_url = false;
    $did_size = false;
    $DescUrl = $URLBase . 'desc.php/jad' . $RandomName . '/' . 
      SafeFilename($_FILES['jad']['name']);
    foreach ($m as $d)
    {
	if (isset($folder) && stristr($d, 'content-folder:'))
	{
	    $Data[] = 'Content-Folder: ' . $folder;
	    $did_folder = true;
	}
	else if (stristr($d, 'midlet-jar-size'))
	{
	    // Just in case
	    $Data[] = 'MIDlet-Jar-Size: ' . $_FILES['jar']['size'];
	    $did_size = true;
	}
	else if (stristr($d, 'midlet-jar-url'))
	{
	    $Data[] = 'MIDlet-Jar-URL: ' . $URLBase . 'download.php/' .
	      $RandomName . '/' . SafeFilename($_FILES['jar']['name']);
	    $did_url = true;
	}
	else if (preg_match('/[^ \t]/', $d))
	{
	    $Data[] = $d;
	}
    }
    if (! $did_url || ! $did_size)
      Bail('Bad JAD file.');
    if (! $did_folder && isset($folder))
      $Data[] = 'Content-Folder: ' . $folder;
}

// Write the descriptor
$fp = fopen($GLOBALS['TempDir'] . '/' . $RandomName . '.txt', 'w');
if (! $fp)
  Bail('System error:  Can not write file descriptor.');
fwrite($fp, join("\n", $Data) . "\r\n");
fclose($fp);

if (isset($_FILES['fn']))
{
    if (! move_uploaded_file($_FILES['fn']['tmp_name'],
			     $GLOBALS['TempDir'] . '/' . $RandomName . 
			     '.bin'))
      Bail('System Error:  Unable to copy file to staging area.');
}
else
{
    if (! move_uploaded_file($_FILES['jar']['tmp_name'],
			     $GLOBALS['TempDir'] . '/' . $RandomName . 
			     '.bin'))
      Bail('System Error:  Unable to copy jar file to staging area.');
}
				     
// Send the message to the user
if (strpos($sendto, '@') !== false)
{
    // email
    mail($sendto, $_POST['desc'], $DescUrl);
    $error = '';
}
else
{
    // sms
    $desc = trim($_POST['desc']);
    $message = "\r\n$DescUrl";
    $desclen = 155 - strlen($message);
    if (strlen($desc) <= $desclen)
      $message = $desc . $message;
    else
      $message = substr($desc, 0, $desclen) . '...' . $message;
    $result = SendSprintSMS($sendto, $message);
    switch ($result)
    {
     case 0:
	$error = '';
	break;
     case 1:
	$error = 'Improper information about your phone.';
	break;
     case 2:
	$error = 'Recipient not subscribed to Sprint Vision.';
	break;
     case 3:
	$error = 'Unknown error occurred.';
	break;
     case 4:
	$error = 'Unhandled error message occurred.';
	break;
     case 5:
	$error = 'Can not connect to messaging server.';
	break;
    }
}


if ($error == '')
{
?>
<p>Sent "<b><?= $_POST['desc'] ?></b>" to the <?= $type 
?> of <?= $sendto ?></p>
<?PHP
}
else
{
?>
<p>Error sending "<b><?= $_POST['desc'] ?></b>" to the <?= $type 
?> of <?= $sendto ?> -- <i><?= $error ?></i></p>
<?PHP
}	

?>

<p>Just in case the phone doesn't get the message, you can point your phone's
web browser to this URL:</p>

<p align=center><a href="<?= $DescUrl ?>"><?= $DescUrl ?></a></p>

<?PHP if (0) { ?>
<p><a href="test.php?U=<?= urlencode($DescUrl) ?>"</a></p>
<?PHP } ?>

<p>Back to the <a href="upload.php">Upload Form</a>.</p>

<hr>

<p>If you have problems downloading a file and get an error message such as
"Data Error 905" or "Attribute Mismatched", then it is likely that the file
you wish to send to your phone is either corrupt or your phone doesn't
handle files of the type you sent.</p>


<?PHP
StandardFooter();


function Bail($msg)
{
    echo htmlspecialchars($msg) . "\n";
    StandardFooter();
    exit();
}


function SafeFilename($fn)
{
    // Replace bad letters with _
    return preg_replace('/[^a-z0-9A-Z\-\._]/', '_', $fn);
}
