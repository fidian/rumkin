<?PHP
/* Sprint File Uploader
 *
 * Copyright (C) 2003 - Tyler Akins
 * Licensed under the GNU GPL software license.
 * See the LEGAL file for legal information
 * See http://rumkin.com/tools/sprint/ for more information about these tools
 */

include 'utils.inc';

$RandomName = substr($_SERVER['PATH_INFO'], 1);
$Ext = substr($RandomName, strrpos($RandomName, '.') + 1);
$p = strpos($RandomName, '/');
if ($p === false)
{
    echo "Bad path info\n";
    exit;
}
$RandomName = substr($RandomName, 0, $p);


Header('Content-type: ' . GetMimeType($Ext));
$filename = $GLOBALS['TempDir'] . '/' . $RandomName . '.bin';
Header('Content-Length: ' . filesize($filename));
if (! readfile($filename))
  echo "Error reading data.\n";