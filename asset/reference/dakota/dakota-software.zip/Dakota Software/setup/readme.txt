README file for Single-Use Camera Reader
========================================

If viewing in Notepad, turn Word Wrap on.


What it is
----------

Single-Use Camera Reader, as the name implies, is software that allows you to read picture data from one or more types of "single-use" digital cameras currently on the market. It is known to support the Dakota Digital Camera (PureDigital Technology), and may (but is not guaranteed to) support the Walgreens single-use digital camera. Both are based on the Sunplus (now Grandtech) SPCA504b controller chip.

The program allows you to read picture data, clear the camera (for reuse), view basic status and hardware information (such as firmware version), and dump the raw contents of the camera's internal memory. Future versions may allow you to do additional things such as upload custom firmware or send raw commands to the camera.



Installation
------------

Don't plug in the camera just yet. (If you already did; make sure Windows doesn't try to install any drivers for it yet.)

This program uses S. Meyer's LibUSB-Win32 library to communicate with the USB port. To install it, right-click on libusb_fl.inf and choose "Install", and right-click on the correct .inf file for your camera (dakota.inf or walgreen.inf) and choose "Install". Now REBOOT THE COMPUTER.

Again, it WILL NOT WORK until you REBOOT.

After rebooting, plug in the camera. Windows should detect the following:
* USB Composite Device
* ISO Interface
* Bulk Interface

If Windows did not install the above devices, or is asking for drivers, choose the "Specify a location" or "Have disk..." option for locating drivers, then point Windows to the correct .inf file for your camera (dakota.inf or walgreen.inf). You may need to REBOOT (yes, again) before the camera reader will work.

Note: This program has not been tested with the Walgreens camera.


Basic Usage
-----------

Plug in your single-use camera, then run the Single-Use Camera Reader software. If the camera is detected, all options will be enabled. If no camera was detected, all camera-control operations will be greyed out. Check your connections, make sure USB is configured correctly on your system (plug in the camera, if you have not done so!) and press Re-query to look for it again.

* Press "Get Pictures" to download all pictures from the camera. A Save As dialogue will appear, enter the name that the files should be prefixed with. Files on the camera have names in the form of DSC_####.JPG; if you enter "downloaded-" as the filename, the files will be saved as e.g. "downloaded-DSC_0001.JPG", "downloaded-DSC_0002.JPG", etc. If the target file already exists, you will be asked whether to overwrite it.

* Press "Clear Camera Memory" to delete all pictures from the camera. Once this is done, it will be ready to take pictures again like new. Wait for it to shut off (or the Ready light to come back on) before you unplug it.

Note: Deleting all pictures does NOT securely erase all picture data from the camera. Until it is completely overwritten by new picture data, all or parts of your old pictures are still in the memory.


Advanced Usage
--------------

Single-Use Camera Reader also supports several additional operations, available from the Advanced menu.

* Memory Dumps: 
	The following memory-dump options are available from the Advanced > Memory Dump menu:
Select "RAM" to dump the 6KB block of RAM accessible through the USB interface (0x0000 ~ 0x1800).
Select "Register block" to dump the register space (0x2000-0x2FFF).
Select "Firmware" to dump the entire external program memory (0x0000 ~ 0xFFFF from external chip) to a file.
Select "FLASH" to dump the external picture FLASH memory (16 MB). This will write TWO files: every 512-byte block of FLASH memory is accompanied by 16 out-of-band bytes of ECC data. This is used to determine bad blocks and for the wear-leveling system. The main data will be output to the filename you specify, and the ECC data will be output to the same filename with ".ecc" appended to it. You will be prompted to overwrite if either of these files exist. This process will take a minimum of 10 hours, since it must be read one byte at a time and reading each byte requires multiple USB transfers.

* Device Status: 
	Use this option to display information about the camera and some status registers. The information displayed is as follows:
Firmware revision: displays a sequence of bytes representing the camera's firmware and hardware revision info.
Serial #: Displays the camera's factory-assigned(?) serial number.
Ready Status: reads the Ready Status register (0x0001).
Operation Mode: Mode the camera is in (e.g. idle, upload, etc.) When idle, this should be 0. This will probably be shown as 0 at all times, since you cannot access the status menu while uploading :-)
Enable Status: reads the Enable Status.
Composite Status: reads several status registers; some are unknown. The first is the Ready Status already displayed.
Mapper: reads the value of register 0x2c07, which controls which half of the firmware is mapped to external memory. When '0', the low half is mapped to 0x8000 ~ 0xffff; when '1', the high half is mapped here. This is automatically taken care of when you dump firmware.

* Send Reset: sends a reset sequence to the camera. Single-Use Camera Reader automatically sends the reset and enable sequences after detecting the camera.

* Send Enable: sends the transfer-enable sequence to the camera. This is done by reading the camera's serial number, converting it to BCD(?), shifting it left 2 bits, then writing it (LSB first) back to the camera. The camera compares this with its own calculation and enables if they match.  Single-Use Camera Reader automatically sends the reset and enable sequences after detecting the camera.

* Force Enable: Enables the camera regardless of the comparison above, by writing a 0 to the memory location (0x0ee7) that stores the result of the camera's comparison. The location of this memory location may be subject to change in future firmware revisions of the camera.

* LibUSB version: Displays the version of libusb installed on your system.

Troubleshooting / Known Issues
------------------------------

Windows (All versions): If upgrading from an old release of libusb-win32 (0.1.7.7 or before) to a new version (0.1.7.8 or later), Windows may not detect the camera's interfaces as separate devices (e.g. USB Composite Device, Bulk, ISO).
	* Solution: If your camera is working properly after upgrading and there are no adverse effects, you can continue using it this way. If the camera does not detect, you may have to completely remove the old libusb-win32 drivers before installing the new ones. See the "Uninstalling" section below for instructions on doing this.


Windows (All versions): You receive a "sanity check failed" error while downloading pictures.
	* Solution: This error occurs if you are using mismatched versions of sucr.exe and libusb-win32. It can also occur if a bulk transfer from the camera (such as a picture download) has been previously interrupted. First, try closing sucr.exe, unplugging the camera, then plugging it back in. If you continue to receive this error, check the version numbers of sucr.exe and libusb-win32.exe: Libusb-win32 versions 0.1.7.7 and earlier MUST be used with sucr.exe version 0.02 or earlier. Libusb-win32 versions 0.1.7.8 or later MUST be used with sucr.exe version 0.03 or later. This is necessary due to changes that were made to libusb-win32 starting with version 0.1.7.8.

Windows (All versions): Camera plugged in, but not detected even after installing the drivers and REBOOTING.
	* Solution: Verify that the LibUSB drivers installed correctly by running "testlibusb.exe" from the command line. You should get a long list of information about your USB hub/motherboard and all the devices connected. If it just prints "bus/device  idVendor/idProduct" and exits (or worse, crashes the computer with a bluescreen), LibUSB has NOT installed correctly - see troubleshooting stuff above for possible causes and remedies. If testlibusb is working but Single Use Camera Reader does not detect the camera, check that its Vendor/Product ID is listed in the testlibusb output (you may have to do "testlibusb.exe | more" at the command line to see all the output). The IDs for the Dakota camera are 04FC/FFFF and for the Walgreens camera are 0461/0819. If it is not listed, check the connection between the camera and the USB port, the wiring, etc. Make sure the camera shows "PC" when connected to the computer. If it is listed but sucr.exe won't detect it, e-mail me a bug report.

The following problems are believed to be fixed as of sucr.exe 0.03 and libusb-win32 0.1.7.8, but are retained for reference.


Windows XP: Multiple users have reported bluescreen errors when attempting to use sucr.exe or testlibusb.exe after installing LibUSB-Win32, and/or problems shutting down after installation. See the next paragraph for a possible fix.

Windows (All versions?): When attaching the camera for the first time, Windows may detect your camera as a "Composite USB Device" (such as a USB hub) and automatically install a generic driver, rather than asking you for the LibUSB stub driver. Then, it will detect each of the camera's USB pipes as separate devices, and thus ask for (and install) 2 copies of the stub driver in addition to the "Composite USB Device". If this happens, the camera will not be detected, and you may get a bluescreen when running sucr.exe or testlibusb.exe. 
	* SOLUTION: Open Device Manager and remove both instances of the camera (stub driver). Reboot the computer. If Windows asks for drivers when you reboot or plug the camera in, press 'Skip' or 'Cancel' to skip installation of the stub driver. You should now be able to run testlibusb.exe and sucr.exe without problems if the filter driver is installed. If Windows continues to beg you for drivers when you plug the camera in, try doing "Update driver" on the "Composite USB Device" and specifying the USB stub driver .inf file (dakota.inf or walgreen.inf). The stub driver is not required for LibUSB and sucr.exe to operate; its only purpose is to keep Windows from bothering you for drivers every time you plug the device in, and prevent the device from appearing in Device Mananger with a yellow exclamation mark.


Windows 98: When installing the stub driver, Windows may report that the .inf file could not be copied even though it may have copied correctly. This is a known issue with the .inf file supplied by earlier versions of LibUSB-Win32, and is (hopefully) fixed as of version 0.1.7.7 included with this release. 
	* WORKAROUND: If the error message continues to appear after the .inf file was successfully copied (appears in C:\Windows\inf), press "Skip file" on the error dialog.



Uninstalling
------------

Removal of Single-Use Camera Reader: This program does not use any Registry keys or dig itself into Windows in any way - just delete the file, and it's uninstalled.

Removal of LibUSB-Win32:

 To uninstall libusb-win32 do the following:
 
 a) uninstalling the filter driver:
 - start 'regedit.exe' on XP and W98 systems, on W2K systems use 
 'regedt32.exe'
 - make sure that you have the required rights to modify the registry
 - on NT-style systems delete the key 'LowerFilters' under the path

'HKEY_LOCAL_MACHINE\SYSTEM\CurrentControlSet\Control\Class\{36FC9E60-C465-11CF-8056-444553540000}'
 (it should currently be set to 'libusbfl')
 - on W98 systems this key is located at 
 'System\CurrentControlSet\Services\Class\USB'
 - Under the '001', '002', etc. listed as subkeys of this key, you may wish to remove those that refer to the camera, libusb-win32, or any non-existant device.
 - reboot the system
 
 b) uninstalling the stub driver (if used):
 - go to the control panel
 - open the device manger
 - remove your device entry
 
 After that you can remove the driver and inf files from your system by
 just deleting them.



Credits
-------
Single-Use Camera Reader is based on John Maushammer's (http://www.maushammer.com/systems/dakotadigital/DakotaDigital.html) pureread.c driver for Macintosh. In fact, code for all the most important operations (camera enable, bulk transfer, FLASH-reading routines) is taken more or less directly from this project. Camera command information is also taken from the gPhoto software for Linux.

For a more complete list of people involved in the hacking of the single-use digital camera, see http://cexx.org/dakota/ .


LibUSB-Win32
------------
This program uses, and includes binaries for, the LibUSB-Win32 program. The components of LibUSB-Win32 are distributed under the GNU General Public License and the GNU LGPL. You can obtain updated versions of LibUSB-Win32 and the source code from the LibUSB-Win32 homepage at http://libusb-win32.sourceforge.net .


Version History
---------------
0.03	Updated the program to reflect changes beginning in version 0.1.7.8 of libusb-win32
	Corrected communications with libusb-win32 that were not done correctly, but worked anyway
	Removed error dialogue if no USB interface detected (no good way to correctly check for this)
	Added libusb version dialogue to 'Advanced' options
	Packaged updated .inf files
	Updated LibUSB package to 0.1.7.8.

0.02	Enlarged the program window to correct a cosmetic bug in Windows XP
	Modified the status dialogue to show the camera's full serial number (starting with BA...)

0.01 	Added detection and .inf files for Walgreens single-use camera (pid/vid=0461/0819)
	Added error dialogue if no USB interface detected (indicating a problem with the LibUSB drivers)
	Program now displays USB ID of detected device on the Status line
	Some code cleanup and added better (proper) enable routine
	Updated LibUSB package to 0.1.7.7.

0.00 Initial release. Included LibUSB release 0.1.7.5.

Copyright and License
---------------------
Single-Use Camera Reader (c)2003 T. R. Gipson. Program home page: http://cexx.org/dakota/

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

The full text of the GNU General Public License is included in the file "GPL.txt" included with this software.