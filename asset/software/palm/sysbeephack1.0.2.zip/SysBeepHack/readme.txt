This hack eliminated the click sound from the system sound set.

This makes it useful for people who type regularly on their palmheld
devices.

Needs any one of the hack managers:
	hackmaster http://www.daggerware.com/hackmstr.htm
	xmaster http://linkesoft.com/english/xmaster/
	tealmaster http://www.tealpoint.com/softmstr.htm
	EVplugBase http://www.freewarepalm.com/utilities/evplugbase.shtml

For Palmos 5 you need one of the palm 5 specific hack managers such as
	yahm http://yahm.palmoid.com/

Released under the GNU GPL, Full source is included.

Pete Shanahan 2002, 2004
Tyler Akins 2003.

