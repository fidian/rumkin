Floater 1.0
By Daniel Werner
 
email: dwerner@talismanic.net
web:   http://talismanic.net/codeworld/floater/

1. Description

    This is a little toolbar program I wrote a while back for Windows. It's very simple but
    I find it useful. Since the source code is supplied with it you can add any features you
    need if you have a little knowledge of C and the Win32 API.


2. Quick Start

    Just place shortcuts in the Items folder that is in the same directory as Floater.exe
    and place a shortcut to Floater.exe in the Startup folder in the start menu. Run Floater
    and now you can launch the shortcuts by clicking on them. You can also drag documents on
    to the shortcuts. 

2. License

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.