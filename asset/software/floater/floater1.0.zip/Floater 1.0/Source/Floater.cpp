/*
    Floater 1.0 By Daniel Werner [dwerner@xoasis.com]

    Copyright (C) 2000 Daniel Werner

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include <windows.h>
#include <commctrl.h>
#include <stdio.h>

#include "resource.h"

HWND	Window, Toolbar;
HWND	Tooltip = 0;
char   *WindowClass = "Floating Poo";
short	windowX, windowY, windowWidth, windowHeight;
BOOL	dragging = FALSE;
POINT	dragBase, mousePos;
int		num;
BOOL	shaded = FALSE;
ATOM    Atom;

void DestroyTooltip(HWND, HWND);
HWND CreateTooltip(HWND hwndOwner, char **tips, int numTips, int width, int height);

struct shortcut
{
	char  fileName[256];
	HICON icon;
} *shortcuts = 0;

void LoadShortcuts()
{
	if(shortcuts)
		delete shortcuts;

	// Load Shortcuts

	WIN32_FIND_DATA fdata;
	HANDLE first;
	int x, y;

	first = FindFirstFile("Items\\*.lnk", &fdata);
	
	if(first == INVALID_HANDLE_VALUE)
		throw "Sorry, I was unable to find any files in my Items folder.";

	num = 1;

	while(FindNextFile(first, &fdata))
		num++;

	shortcuts = new shortcut[num];

	first = FindFirstFile("Items\\*.lnk",&fdata);
	strcpy(shortcuts[0].fileName, fdata.cFileName);


	for(x = 1; x < num; x++)
	{
		FindNextFile(first, &fdata);
		strcpy(shortcuts[x].fileName, fdata.cFileName);
	}

	// Sort Shortcuts
	for(x = 0; x < (num - 1); x++)
		for(y = x; y < (num - 1); y++)
		{
			shortcut temp;

			if(_stricmp(shortcuts[x].fileName, shortcuts[x+1].fileName) > 0)
			{
				memcpy(&temp, &shortcuts[x], sizeof(shortcut));
				memcpy(&shortcuts[x], &shortcuts[x+1], sizeof(shortcut));
				memcpy(&shortcuts[x+1], &temp, sizeof(shortcut));
			}
		}

	// Load Icons

	for(x = 0; x < num; x++)
	{
		SHFILEINFO info;
		char file[256];

		strcpy(file, "Items\\");
		strcat(file, shortcuts[x].fileName);

		SHGetFileInfo(file, NULL, &info, sizeof(info), SHGFI_ICON);

		shortcuts[x].icon = info.hIcon;
	}

}

void Shutdown()
{
	GlobalDeleteAtom(Atom);
	UnregisterClass(WindowClass, GetModuleHandle(NULL));
}

void MessageLoop()
{
	MSG msg;
    HACCEL  accel = NULL;

	while(GetMessage(&msg, NULL, 0, 0)) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
}


LRESULT WINAPI ToolbarProc(HWND hwnd, UINT msg, WPARAM wparam, LPARAM lparam)
{
	MSG relayMsg;

	memset(&relayMsg, 0, sizeof(relayMsg));
	relayMsg.hwnd		= hwnd;
	relayMsg.lParam		= lparam;
	relayMsg.message	= msg;
	relayMsg.wParam		= wparam;
	GetCursorPos(&relayMsg.pt);


	SendMessage(Tooltip, TTM_RELAYEVENT, 0, (LPARAM)&relayMsg);

	switch(msg)
	{
		case WM_MOUSEMOVE:
		{
			mousePos.x = LOWORD(lparam);
			mousePos.y = HIWORD(lparam);

			break;
		}
		case WM_PAINT:
		{
			PAINTSTRUCT ps;
			int x;
			HDC hdc;
			RECT rect;
			HANDLE newObject, oldObject;

			rect.top = 0;
			rect.bottom = 40;
			rect.left = 0;
			rect.right = 4000;

			hdc = BeginPaint(hwnd, &ps);

			newObject = CreateSolidBrush(GetSysColor(COLOR_3DFACE));
			FillRect(hdc, &rect, (HBRUSH)newObject);
			DeleteObject(newObject);

			// Draw Highlights

			newObject = CreatePen(PS_SOLID, 0, GetSysColor(COLOR_3DHILIGHT));
			oldObject = SelectObject(hdc, newObject);
			
			// Draw Light Edges

			MoveToEx(hdc, 0, windowHeight - 1, NULL);
			LineTo(hdc, 0, 0);
			LineTo(hdc, windowWidth - 1, 0);
			
			// Draw Light Bars

			MoveToEx(hdc, 2, 2, NULL);
			LineTo(hdc, 2, windowHeight - 3);
			MoveToEx(hdc, 6, 2, NULL);
			LineTo(hdc, 6, windowHeight - 3);

			// Draw Close Cross

			MoveToEx(hdc, windowWidth - 3, 2, NULL);
			LineTo(hdc, windowWidth - 9, 8);
			MoveToEx(hdc, windowWidth - 8, 2, NULL);
			LineTo(hdc, windowWidth - 2, 8); 

			SelectObject(hdc, oldObject);
			DeleteObject(newObject);

			// Draw Shadows

			newObject = CreatePen(PS_SOLID, 0, GetSysColor(COLOR_3DSHADOW));

			oldObject = SelectObject(hdc, newObject);

			// Draw Dark Edges

			MoveToEx(hdc, windowWidth - 1, 0, NULL);
			LineTo(hdc, windowWidth - 1, windowHeight - 1);
			LineTo(hdc, 0, windowHeight - 1);

			// Draw Dark Bars

			MoveToEx(hdc, 4, 2, NULL);
			LineTo(hdc, 4, windowWidth - 3);
			MoveToEx(hdc, 8, 2, NULL);
			LineTo(hdc, 8, windowWidth - 3);

			// Draw Close Cross

			MoveToEx(hdc, windowWidth - 3, 3, NULL);
			LineTo(hdc, windowWidth - 9, 9);
			MoveToEx(hdc, windowWidth - 8, 3, NULL);
			LineTo(hdc, windowWidth - 2, 9); 

			SelectObject(hdc, oldObject);
			DeleteObject(newObject);

			for(x = 0; x < num; x++)
			{
				DrawIconEx(hdc, (x * 40) + 16, 4, shortcuts[x].icon, 32, 32, NULL, NULL, DI_NORMAL);
			}

			EndPaint(hwnd, &ps);
	
			return TRUE;
		}
		case WM_LBUTTONDOWN:
		{
			if(LOWORD(lparam) < 12)
			{
				shaded = !shaded;

				if(shaded)
					MoveWindow(hwnd, windowX, windowY, windowWidth, windowHeight, TRUE);
				else
	  				MoveWindow(hwnd, windowX, windowY, 11, windowHeight, TRUE);
			}
			else
			{
				if(LOWORD(lparam) > (windowWidth - 10))
					if((HIWORD(lparam) < 10))
						PostQuitMessage(NULL);

				int item;

				item = (int)((LOWORD(lparam) - 16) / 40);
				char program[256];

				strcpy(program, "Items\\");
				strcat(program, shortcuts[item].fileName);

				if(strcmp(program + strlen(program) - 3, ".exe") != 0)
					Beep(0, 0);

				ShellExecute(Window, "open", program, NULL, NULL, SW_SHOWNORMAL);
			}

			return TRUE;
		}
		case WM_DROPFILES:
		{
			char file[256], file2[256], program[256];
 			int item;

			DragQueryFile((HDROP)wparam, 0, file, 256);

			item = (int)((mousePos.x - 16) / 40);

			strcpy(program, "Items\\");
			strcat(program, shortcuts[item].fileName);
			
			sprintf(file2, "\"%s\"", file);

			ShellExecute(NULL, "open", program, file2, NULL, SW_SHOW);

			return 0;
		}
	}
	return DefWindowProc(hwnd, msg, wparam, lparam);
}
 
void DestroyTooltip(HWND hwndTooltip, HWND hwndOwner)
{
	DestroyWindow(hwndTooltip);
}

HWND CreateTooltip(HWND hwndOwner, char **tips, int numTips, int width, int height) 
{ 
    HWND hwndTT;    // handle of tooltip 
    int row, col;   // rows and columns 
    TOOLINFO ti;    // tool information 
    int id = 0;     // offset to string identifiers 
 
    // Ensure that the common control DLL is loaded, and create 
    // a tooltip control. 
    InitCommonControls(); 
 
    hwndTT = CreateWindowEx(WS_EX_TOPMOST, TOOLTIPS_CLASS, (char*)NULL, WS_POPUP | TTS_ALWAYSTIP, 
        0, 0, (width * numTips) + 19, height, 
        hwndOwner, (HMENU) NULL, GetModuleHandle(NULL), NULL); 
 
    if (hwndTT == (HWND) NULL) 
        return (HWND) NULL; 
 
    // Divide the client area into a grid of rectangles, and add each 
    // rectangle to the tooltip. 
    for (row = 0; row < 1 ; row++ ) 
        for (col = 0; col < numTips; col++) { 
            ti.cbSize = sizeof(TOOLINFO); 
            ti.uFlags = 0; 
            ti.hwnd = hwndOwner; 
            ti.hinst = GetModuleHandle(NULL); 
            ti.uId = (UINT) id; 
            ti.lpszText = (LPSTR) tips[id++]; 
            ti.rect.left = (col * width) + 10; 
            ti.rect.top = row * height; 
            ti.rect.right = ti.rect.left + width; 
            ti.rect.bottom = ti.rect.top + height; 
 
            if (!SendMessage(hwndTT, TTM_ADDTOOL, 0, 
                    (LPARAM) (LPTOOLINFO) &ti)) 
                return NULL; 
        } 
 
    return hwndTT; 
} 
 

void Startup()
{
	char **tips;

	if(GlobalFindAtom("Floater"))
		_exit(0);

	LoadShortcuts();

	WNDCLASS wc;
	
	wc.style			= NULL;
	wc.lpfnWndProc		= ToolbarProc;
	wc.cbClsExtra		= NULL;
	wc.cbWndExtra		= NULL;
	wc.hInstance		= GetModuleHandle(NULL);
	wc.hIcon			= NULL;
	wc.hCursor			= NULL;
	wc.hbrBackground	= (HBRUSH)COLOR_WINDOW;
	wc.lpszMenuName		= NULL;
	wc.lpszClassName	= WindowClass;

	if(!RegisterClass(&wc))
		throw "Error Registering Window Class";

	windowX = 0;

	windowY = GetSystemMetrics(SM_CYMAXIMIZED) - 48; // 700
	
	windowWidth = (int)(num * 40) + 19;
	windowHeight = 40;

	Window = CreateWindowEx(WS_EX_TOOLWINDOW | WS_EX_TOPMOST | WS_EX_ACCEPTFILES, WindowClass, "Floater", 
		WS_POPUP, windowX, windowY, windowWidth, windowHeight, NULL, NULL, GetModuleHandle(NULL), NULL);	

	DragAcceptFiles(Window, TRUE);

	// Create Tooltips

	tips = new char*[num];
	int x, y;
	for(x = 0; x < num; x++)
	{
		tips[x] = new char[256];
		strcpy(tips[x], shortcuts[x].fileName);
		for(y = 0; tips[x][y] != 0; y++)
			if(tips[x][y] == '.')
				tips[x][y] = 0;
	}

	if(Tooltip)
		DestroyTooltip(Toolbar, Window);
	Tooltip = CreateTooltip(Window, tips, num, 40, 40);
	delete tips;


	Atom = GlobalAddAtom("Floater");

	// Show Window

	ShowWindow(Window, SW_SHOW);
	ShowWindow(Tooltip, SW_SHOW);
	SetCursor(LoadCursor(NULL, IDC_ARROW));

	UpdateWindow(Window);

}

int WINAPI WinMain(HINSTANCE  hInstance, HINSTANCE  hPrevInstance, LPSTR  lpCmdLine, int nShowCmd)
{
	try
	{
		Startup();
		MessageLoop();
		Shutdown();
	}
	catch(char* theError)
	{
		MessageBox(NULL, theError, "Floater - Error", MB_OK);
	}
	return 0L;
}
