#include <stdio.h>
#include <stdlib.h>


int main(int argc, char **argv)
{
	 int a, b, c, d;
	 unsigned int seed = 0;

	 if (argc < 5)
	 {
		  printf("Syntax:\n");
		  printf("    findpad  <a> <b> <c> <d>\n");
		  printf("a-d are decimal representations of the first four\n");
		  printf("numbers in the key file.\n");
	 }

	 a = atoi(argv[1]);
	 b = atoi(argv[2]);
	 c = atoi(argv[3]);
	 d = atoi(argv[4]);

	 printf("Finding %u %u %u %u (%02x %02x %02x %02x)\n",
			  a, b, c, d, a, b, c, d);

	 srand(seed);
	 seed ++;
	 while (seed != 0)
	 {
		  if (a == (rand() & 0xFF))
		  {
				if (b == (rand() & 0xFF))
				{
					 if (c == (rand() & 0xFF))
					 {
						  if (d == (rand() & 0xFF))
						  {
								printf("Potential seed:  %u\n", seed);
						  }
					 }
				}
		  }
		  if (seed & 0x00FF == 0xFF)
		  {
				printf("%u\r", seed);
		  }
		  srand(++ seed);
	 }

	 printf("Done.\n");

	 return 0;
}