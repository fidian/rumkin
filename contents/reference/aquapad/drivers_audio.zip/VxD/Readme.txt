
  ALi Audio and Joystick Driver for Windows 95/98/98SE
 =================================================

 ------------
 INTRODUCTION
 ------------

  This driver supports ALi M5451 PCI audio accelerator under Windows 95/98/98SE

 -------------------------
 CONTENTS OF THIS DOCUMENT
 -------------------------
  1. Installation Instructions
  2. Uninstallation Instructions
  3. Change List

  ----------------------------
  1. Installation Instructions
  ----------------------------
  **********************************NOTE**************************************
  If you are working in Win95, please install DirectX 5.0 (or later) before 
  install ALi audio VxD driver, or system might be hang.
  ****************************************************************************
   The procedures below presumes that Win95/98/98SE have already been installed 
  successfully and the audio and joystick driver has never been installed
  in your computer system :
  1.  Start the Windows system.
  2.  Click mouse right button on "My Computer" icon, then select "Property" option.  
  3.  Click "Device Manager" tab.
  4.  Double click on the "PCI Multimedia Audio Device" under "Other Devices".
  5.  Select "Driver" tab and click on "Reinstall" button.
  6.  The hardware install wizard dialog box will appear. Follow the wizard's
      instructions and give the correct dirver path to wizard. 
      The hardware install wizard will copy the necessary files and install 
      it to your hard drive.  This completes the setup.

 ------------------------------
 2. Uninstallation Instructions
 ------------------------------
  1.  Click mouse right button on "My Computer" icon, select "Property" option and
      then select "Device Manager" tab.
  2.  Click "Device Manager" button.
  3.  Select "ALi PCI Audio Accelerator" device in device manager.
  4.  Click mouse right button and remove it.
    
 ------------------------------
 3. Change List
 ------------------------------
  v 4.05.1109
  1. Fix BIOStar restart issue.
  2. Fix WinDVD long run issue.
  3. Fix fishing game audio issue.

  v 4.05.1108
  1. Fix play PowrDVD delay issue.
  2. Fix Win95 long run issue.
  3. Fix modem enumeration issue in Falcon project.
  4. Implement 1535Plus codec access HAL function in driver.

  v 4.05.1107
  1. Implement volume MAX and MIN function in volume control

  v 4.05.1106
  1. Add Codec ready flag check function in driver.

  v 4.05.1105
  1.  Fixed software modem enumeration issue.
  2.  Fixed wake on ring issue for PCTel software modem.
  3.  Implement Lucent software modem enumeration function.

  v 4.05.1104
  1.  Modify global volume control for software modem function.

  v 4.05.1103
  1.  Implement PCTel software modem HAL function.

  v 4.05.1101
  1.  Implement four 4 speak function and got PC99 logo.


  v 4.05.1007
  1.  Implement I2SIN recording function.

  v 4.05.1005
  1.  Change volume gain default setting for Fujitsu.
  2.  Add optional key in INF file to disable legacy function.

  v 4.05.1004
  1.  Enable I2SIN function.

  v 4.05.1003
  1.  Fixed volume would be auto-increased while wave file is playing.

  v 4.05.1002 
  1.  It fixed power manager issue in this driver. It can resume from S3 successfully.

  v 4.05.1001
  1.  First released.  
