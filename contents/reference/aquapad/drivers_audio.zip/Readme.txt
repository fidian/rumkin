 ALi Audio Accelerator Driver Setup Program(V1.41.001)
 ==========================================
 
 ------------
 INTRODUCTION
 ------------

  This program can install ALi M5451 PCI audio accelerator driver in Win95/98 WinNT4.0
  Win2000.

 ------------------------
 CONTENTS OF THIS Program
 ------------------------
 1.Setup Program
 2.ALi audio WDM Logo'd driver(ver 5.12.01.5117, support Win98, Win2000)
 3.ALi audio NT4 driver(ver 1.5)
 4.ALi audio VxD driver(ver 4.05.1109, support Win95)
 5.ALi WaveTable


 ---------------------
 Execution Instruction
 ---------------------
 1.Install ALi audio VxD driver in Win95. 
   a.)You should intall DirectX(5.0 or later) before installing ALi audio VxD driver in Win95.
   b.)Run Setup.exe
   c.)Then setup program will prompt you to reboot system.
   d.)After system reboot, ALi audio VxD driver will be installed properly.
   
 2.Install ALi audio NT4 driver in Win NT4.0.
   a.)Run Setup.exe
   b.)Then setup program will prompt you to choose wave table. Just click OK button.
   c.)Then setup program will prompt you to reboot system.
   d.)After system reboot, ALi audio NT4 driver will be installed properly.

 3.Install ALi audio WDM driver in Win98.
   a.)Run Setup.exe
   b.)Then setup program will prompt you to reboot system.
   c.)After system reboot, ALi audio WDM driver will be installed properly.
 
 4.Install ALi audio WDM driver in Win2000.
   a.)Run Setup.exe
   b.)Then setup program will install WDM driver automatically. You don't have to reboot system.
 
 5.Remove ALi audio driver
   You can remove audio driver in Windows "Add and Remove Program" panel.

 --------------------
 Software Change Note
 --------------------
 *  v1.41.001
    Update VxD driver from 4.05.1108 to 4.05.1109
    Included Driver version:
    ALi audio WDM Logo'd driver(ver 5.12.01.5117, support Win98, Win2000)
    ALi audio NT4 driver(ver 1.5)
    ALi audio VxD driver(ver 4.05.1109, support Win95)
    

 