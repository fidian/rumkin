
  ALi Audio WDM Driver for Win98/Win98 SE/Win2000
 =================================================

 ------------
 INTRODUCTION
 ------------

  This driver supports ALi M5451 PCI audio accelerator

 -------------------------
 CONTENTS OF THIS DOCUMENT
 -------------------------
  1. Installation Instructions
  2. Uninstallation Instructions
  3. Control Panel
  4. Change List

 ----------------------------
 1. Installation Instructions
 ----------------------------


  The procedures below presumes that Win2000 have already been installed 
  successfully and the audio and joystick driver has never been installed
  in your computer system :

  1.  Start the Windows operating system.
  2.  Click mouse right button on "My Computer" icon, then select "Hardware" tab  
  3.  Click "Device Manager" button.
  4.  Double click on the "PCI Multimedia Audio Device" under "Other Devices".
  5.  Click on "Reinstall" button.
  6.  The hardware install wizard dialog box will appear. Follow the wizard's
      instructions and give the correct dirver path to wizard. 
      The hardware install wizard will copy the necessary files and install 
      it to your hard drive.  This completes the setup.


 ------------------------------
 2. Uninstallation Instructions
 ------------------------------
  1.  Click mouse right button on "My Computer" icon, then select "Hardware" tab  
  2.  Click "Device Manager" button.
  3.  Remove it.
    

 ------------------------------
 3. Control Panel
 ------------------------------
  1. Sample: You can select a wavetble to play a midi file.
  2. Power Management:
	     Audio driver will shutdown codec power (PR0:ADC, PR1:DAC)
	     (or even (PR2:Mixer, PR7:EAPD) if "Enable EAPD" is checked)
	     about N seconds after no sound played.
	     N is your choice in the control panel.


 ------------------------------
 4. Change List
 ------------------------------
  5.12.01.5117
     1. Fix multitask long run issue in CUA.
     2. Fix resume issue when MPU401 is enable.
	
  5.12.01.5116
     1. Support GamePort (enable port 220h).
     2. Set MUSIC and WAVE global gain volume to 0x0000
     3. Support 4 speaker in Win 2000
     4. More efficient in Win 2000


  5.12.01.5115
     1. Modify codec accessing for M1535+
     2. Fix the bug which no modem driver can be installed when modem
        codec can't be read (return 0)
     3. Do DC reset if no M5453 (Conaxent modem) exist.
     4. Use I/O space command instead of MMIO to fix MIDI hang problem 
        in Transmeta board.
     5. Change modem I/O resource (101h to 3FFh).
     6. Fix the bug which audio driver can't "Disable/Enable" with 
        software modem driver.
     7. Shorter time interval to polling DMA buffer.
     8. Add codec accessing synchronization between audio and modem 
	driver (NOT Conaxent modem driver)
     9. Fix the recording issue in Millennien
     10. It needn't reboot when you change setting in control panel.
     11. Provide a option to shutdown EAPD when system suspend
     12. More Power Saving:
	 D0: Powerdown AD/DA if no sound playing about n sec
	 D1/D1/D3:  Powerdown AD/DA
     13. Add Timer Object in Win2000 to help resume procedure.
     14. Set Global Volume to 0dB.
     15. Reserve modem(Line1) IN/OUT channels.
     16. Solve the problem which AP will stop after it run a long time (about 3 days).
     17. It has got WHQL PC99 logo


  5.12.01.5114
     1. Because the requested by Microsoft, the version is changed from
	 4.10.XXXX to 5.12.01.XXXX
     2. System can suspend by HCT9.5 test program in Win2000
     3. It can pass driver verifier test in HCT 9.5
     4. It can pass disabler test in HCT 9.5 (Win98).
     5. Remove 2 seconds timer object to maintain codec register values.


  4.10.5112
     1. It doesn't release the drity bit (the bit will prevent from next
        AC Cold Reset if the bit is set.)
     2. The Software modem HW key is generated according to Modem 
        Codec VID
     3. PCtel and Lucent software modem can work in Win2000
     4. It can pass "2 Machines\PC99 Audio test" in HCT9.5
     5. It remove MPU401 component.
     6. It support PCtel and Lucent software modem.
     7. It support GamePort device.

  
 