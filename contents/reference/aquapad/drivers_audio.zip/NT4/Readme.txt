
  ALi Audio and Joystick Driver for Windows NT 4.0
 =================================================

 ------------
 INTRODUCTION
 ------------

  This driver supports ALi M5451 PCI audio accelerator under Windows NT 4.0

 -------------------------
 CONTENTS OF THIS DOCUMENT
 -------------------------
  1. Installation Instructions
  2. Uninstallation Instructions
  3. Change List

  ----------------------------
  1. Installation Instructions
  ----------------------------

  1.  Start the Windows NT 4.0 system.
  2.  Open "Control Panel" following Start\Settings\Control Panel.
  3.  Double click on "Multimedia" icon.
  4.  Select the "Devices" tab.
  5.  Click on the "Add" button.
  6.  After the "Add" dialog box appears, double click on 
      "Unlisted or Updated Driver".
  7.  An "Install Driver" dialog box appears. Select the correct path
      of driver.  
      (For example if the audio and joystick driver are located in  
      \nt4 subdirectory on CD-ROM, and the CD-ROM drive is D:, then select
      "D:\nt4" in the "Install Driver" dialog box)

      Then click on "OK" button to continue.

  8.  When "Add Unlisted or Undated Driver" dialog box appears, double click 
      "ALi PCI Audio Accelerator" to continue the installation.

  9.  If the "Drier Exists" dialog box appears, click on "New" to update
      the driver.

  10. After the driver is installed, "Sample Setup" dialog box appears.
      Click on "OK" if you don't want to change any setting.
  
  11. If a "System Setting Change" dialog box appears, you can click on 
      "Don't Restart Now" to avoid the system from restarting and continue 
      with the installation for the Joystick driver.

  12. In the "Devices" tab, Click on the "Add" button.
  13. After the "Add" dialog box appears, double click on 
      "Unlisted or Updated Driver".
  14. An "Install Driver" dialog box appears. Select the correct directory
      of driver.  

      Then click on "OK" button to continue.

  15. When "Add Unlisted or Undated Driver" dialog box appears, double click 
      "ALi Gameport" to continue the installation.

  16. If the "Driver Exists" dialog box appears, click on "New" to update
      the driver.

  17. When a "System Setting Change" dialog box appears, you can click on 
      "Restart Now" to restart system.
 

  Note: After completing the installation of the audio or joystick driver, 
        you need to restart your system.


 ------------------------------
 2. Uninstallation Instructions
 ------------------------------

  1.  Open "Control Panel" following Start\Settings\Control Panel.
  2.  Double click on "Multimedia" icon.
  3.  Select the "Devices" tab.
  4.  Select the "Audio for ALi PCI Audio Accelerator" under 
      "Audio Devices".
  5.  Click on "Remove" button. Then a confirm remove dialog box will appear.
      Click on "Yes" if you really want to uninstall audio driver.

  6.  When a "System Setting Change" dialog box appears, you can click on 
      "Don't Restart Now" to avoid the system from restarting and to continue 
      to uninstall Joystick driver.

  7.  In the "Devices" tab, Select the "ALi Gameport" under "Joystick Devices".
  8.  Click on "Remove" button. Then a confirm remove dialog box will appear.
      Click on "Yes" if you really want to uninstall joystick driver.
  9.  When a "System Setting Change" dialog box appears, you can click on 
      "Restart Now" restart your system.  

  Note: After completing uninstalling the audio or joystick driver, restart 
        your computer.
    
 ------------------------------
 3. Change List
 ------------------------------
  V1.50
     1. Support multilanguage configuration UI

  V1.41
     1. Fixed the issue that there is noise when play VCD for a while
     2. Support mixer line minimum volume setting 

  V1.4
     1. Rename the volume default setting file ALIDFSET.INI to ALIDFSET.DAT

  V1.35
     1. Set "ALi Audio Wavetable MIDI" as the defuatl MIDI device when use SETUP.EXE 
	to install audio driver
     2. Modify R/W CODEC routine to support M1535+

  V1.34
     1. Can adjust and mute volume in Windows Media Player
     2. Useing I/O-mapped  I/O

  V1.33
     1. Disable analog CODEC power management in hardware initialize
     2. Change the volume default setting file name from Default.INI to ALiDfSet.INI.

  V1.32
     1. Support GPIO volume control
     2. Add default volume setting and maximum volume range limited in Default.INI

  V1.31
     1. Implement software SRC     
     2. Support I2S recording and 4 speakers
     3. Dynamically determine whether there surport 4-speaker or 3D control 
        in CODEC

  V1.27
     1. Support PCTel Software Modem
     2. Fixed the procedure for R/W CODEC (reference STimer)
  
  V1.26
     1. Reserve channel 20 and 21 for Modem to use (support Lucent Modem)
     2. Fixed the issue of the recording noise 

  V1.25
     1. Pass the ACT99 V5.1 (HotFix).

  V1.20
     1. Can share the same IRQ with other device
     2. Pass WHQL ACT4.3

  V1.11
     1. change string 'MUP401' to 'MPU401'
     2. set "ALi WaveTable" as default MIDIOUT device
     3. set the recording line "I2S" as stereo channel.
     4. add "Phone", "Video", "MonoMix" Lines in Playback
     5. set all volume setting at half position.
     6. Can set "24K" in Sample setting panel
     7. Can change Sample Table from "1MB" to "4MB"
     8. 3D-Control setting (only depth)
     9. MicroPhone was muted in default setting
    10.Fix the bug which detect whether master volume support Bit5.
